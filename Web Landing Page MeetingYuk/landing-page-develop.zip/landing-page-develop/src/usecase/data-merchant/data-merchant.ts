import { DataMerchantDomain } from "../../domain/data-merhcant/data-merhcant";
import { FindMerchantFilter, DataMerchantType } from "../../domain/data-merhcant/types";
import { MerchantServiceDomain } from "../../domain/merchant-service/merchant-service";
import { MerchantServiceCategory } from "./const";

export class DataMerchantUsecase {
  private dataMerchantDomain: DataMerchantDomain
  private merchantServiceDomain: MerchantServiceDomain

  constructor(dataMerchantDomain: DataMerchantDomain, merchantServiceDomain: MerchantServiceDomain) {
    this.dataMerchantDomain = dataMerchantDomain
    this.merchantServiceDomain = merchantServiceDomain
  }

  async findMerchant(query: string) {
    let filter: FindMerchantFilter = {
      name: query,
      startFrom: true
    }

    const merchants: DataMerchantType[] = []
    const merchantMap: Map<string, string> = new Map()

    try {
      var result = await this.dataMerchantDomain.findMerhchantWithFilter(filter)
    } catch (error) {
      return Promise.reject(error)
    }

    result.map(item => {
      if(!item.url_foto.includes('https')) {
        item.url_foto = `https://${item.url_foto}`
      }

      merchants.push(item)
      merchantMap.set(item.id, item.id)
    })

    filter = {
      strLocation: query,
      startFrom: true
    }

    try {
      var nextResult = await this.dataMerchantDomain.findMerhchantWithFilter(filter)
    } catch (error) {
      return Promise.reject(error)
    }

    nextResult.map(item => {
      if(!merchantMap.get(item.id)) {
        if(!item.url_foto.includes('https')) {
          item.url_foto = `https://${item.url_foto}`
        }
        
        merchants.push(item)
        merchantMap.set(item.id, item.id)
      }
    })

    return merchants
  }

  async getMerchantDetail(idMerchant: string) {
    try {
      var dataMerchant = await this.dataMerchantDomain.getMerchantById(idMerchant)
      var merchantServices = await this.merchantServiceDomain.getMerchantService(idMerchant)
    } catch (error) {
      return Promise.reject(error)
    }

    const merchantPhotos: string[] = []
    const iconMap: Map<string,string> = new Map()
    merchantServices.map(item => {
      iconMap.set(item.icon.id, item.icon.url)
      item.photos.map(photo => {
        merchantPhotos.push(photo.url)
      })
    })

    const serviceIcon: any[] = []
    iconMap.forEach((val, key) => {
      serviceIcon.push(MerchantServiceCategory.find(item => item.id == key))
    })

    return { merchant: dataMerchant, services: merchantServices, photos: merchantPhotos, serviceIcon }
  }
}