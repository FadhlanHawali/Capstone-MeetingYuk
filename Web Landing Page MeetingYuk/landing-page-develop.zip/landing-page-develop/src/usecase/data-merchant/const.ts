export const MerchantServiceCategory = [
  {
    id: 'balroom',
    text: 'Balroom',
    url: 'api.meetingyuk.com/file/meeting-merchant/1588752607076.png'
  },
  {
    id: 'conference',
    text: 'Meeting Room',
    url: 'api.meetingyuk.com/file/meeting-merchant/1588752634187.png'
  },
  {
    id: 'food',
    text: 'Restaurant',
    url: 'api.meetingyuk.com/file/meeting-merchant/1588752680048.png'
  },
  {
    id: 'music',
    text: 'Music',
    url: 'api.meetingyuk.com/file/meeting-merchant/1588752706830.png'
  },
  {
    id: 'room',
    text: 'Room',
    url: 'api.meetingyuk.com/file/meeting-merchant/1588752731458.png'
  },
  {
    id: 'wedding',
    text: 'Wedding Venue',
    url: 'api.meetingyuk.com/file/meeting-merchant/1588752750028.png'
  }
]