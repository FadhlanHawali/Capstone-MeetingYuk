import http from './server/http/http';
import { DataMerchantUsecase } from './usecase/data-merchant/data-merchant';
import { DataMerchantHttpResource } from './domain/data-merhcant/http';
import { LandingPageConfig } from './config/config';
import { DataMerchantDomain } from './domain/data-merhcant/data-merhcant';
import { MerchantServiceHttpResource } from './domain/merchant-service/http';
import { MerchantServiceDomain } from './domain/merchant-service/merchant-service';

type Usecase = {
   dataMerchant: DataMerchantUsecase
}

export var LandingPageUsecase: Usecase

function initLandingPage(){
   const config: LandingPageConfig = require(`../config/${process.env.ENV}.config.json`)
   const dataMerchantResource = new DataMerchantHttpResource(config.MerchantEngine.host)
   const serviceMerchantResource = new MerchantServiceHttpResource(config.MerchantEngine.host)

   const dataMerchantDomain = new DataMerchantDomain(dataMerchantResource)
   const serviceMerchantDomain = new MerchantServiceDomain(serviceMerchantResource)

   LandingPageUsecase = {
      dataMerchant: new DataMerchantUsecase(dataMerchantDomain, serviceMerchantDomain)
   }
}

function startLandingPage(){
   http.initHttpServer();

   http.startHttpServer();
}

export default {
   initLandingPage,
   startLandingPage
}