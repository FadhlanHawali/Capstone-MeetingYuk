import dotenv from 'dotenv'
import initial from './initial';

dotenv.config()
initial.initLandingPage();
initial.startLandingPage();