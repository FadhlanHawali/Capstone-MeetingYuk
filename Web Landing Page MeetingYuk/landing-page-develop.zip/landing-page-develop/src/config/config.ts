export type LandingPageConfig = {
  MerchantEngine: {
    host: string
  }
}