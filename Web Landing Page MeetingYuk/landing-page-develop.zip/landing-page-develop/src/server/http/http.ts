import express from 'express'
import path from 'path'
import morgan from 'morgan'
import { searchMerchantHandler } from './handler/search-result';
import { MeetingYukError } from '../../error/error';
import { profileMerchantHandler } from './handler/profile-merchant';

const app = express();

function initHttpServer(){
   app.use(morgan('dev'))
   app.set('views', path.join(__dirname, '../../../file/views'));
   app.set('view engine', 'ejs');
   app.use('/public', express.static(path.join(__dirname, '../../../file/public')));

   app.get('/', function(req, res, next) {
      res.redirect('/user')
   })

   app.get('/mitra', function(req, res, next){
      res.render('index-mitra');
   });

   app.get('/mitra/faq', function(req, res, next){
      res.render('help-mitra');
   })

   app.get('/user', function(req, res, next){
      res.render('index-user');
   })

   app.get('/user/faq', function(req, res, next){
      res.render('help-user');
   })

   app.get('/merchant/search', searchMerchantHandler)

   app.get('/merchant/profile/:idMerchant', profileMerchantHandler)

   app.get('/merchant/privacy-policy', function(req, res, next) {
      res.render('privacy-policy-mitra')
   })

   app.use(function(err: MeetingYukError, req: express.Request, res: express.Response, next: express.NextFunction){
      console.log(err)
      res.send(JSON.stringify(err))
   })

   // app.use(function(req, res, next){
   //    res.redirect('/user');
   // });
}

function startHttpServer(){
   const port = process.env.PORT || 5007;

   app.listen(port, function(){
      console.log(`App ready di port ${port}`);
   })
}

export default {
   initHttpServer,
   startHttpServer
}