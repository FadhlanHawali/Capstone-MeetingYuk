import { Request, Response, NextFunction } from 'express'
import { LandingPageUsecase } from '../../../initial'

export async function searchMerchantHandler(req: Request, res: Response, next: NextFunction) {
  const query = req.query.q

  try {
    var result = await LandingPageUsecase.dataMerchant.findMerchant(query)
  } catch (error) {
    return next(error)
  }

  return res.render('search-result', { query: query, merchant: result })
}