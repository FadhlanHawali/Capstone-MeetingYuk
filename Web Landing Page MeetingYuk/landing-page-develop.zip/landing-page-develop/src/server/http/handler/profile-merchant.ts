import { Request, Response, NextFunction } from 'express'
import { LandingPageUsecase } from '../../../initial'

export async function profileMerchantHandler(req: Request, res: Response, next: NextFunction) {
  const idMerchant = req.params.idMerchant

  try {
    var result = await LandingPageUsecase.dataMerchant.getMerchantDetail(idMerchant)
  } catch (error) {
    return next(error)
  }

  return res.render('profile-merchant', result)
}