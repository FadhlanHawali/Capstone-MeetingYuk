import axios from 'axios'

import { DataMerchantResource } from "./data-merhcant";
import { FindMerchantFilter, DataMerchantType } from "./types";
import { commonError } from '../../error/error';

export class DataMerchantHttpResource implements DataMerchantResource {
  private host: string
  private serviceName = 'MerchantEngine'

  constructor(merchantEngineHost: string) {
    this.host = merchantEngineHost
  }

  async findMerhchantWithFilter(filter: FindMerchantFilter): Promise<DataMerchantType[]> {
    try {
      var response = await axios.post(`${this.host}/client-engine/findMerchant`, filter)
    } catch (error) {
      return Promise.reject(commonError.thirdPartyError(this.serviceName, error.message))
    }

    return response.data.data
  }

  async getMerchantById(idMerchant: string): Promise<DataMerchantType> {
    try {
      var response = await axios.get(`${this.host}/user/merchant/get-detail?id=${idMerchant}`)
    } catch (error) {
      return Promise.reject(commonError.thirdPartyError(this.serviceName, error.message))
    }

    return response.data.data
  }
}