import { FindMerchantFilter, DataMerchantType } from "./types";

export interface DataMerchantResource {
  findMerhchantWithFilter(filter: FindMerchantFilter): Promise<DataMerchantType[]>
  getMerchantById(idMerchant: string): Promise<DataMerchantType>
}

export class DataMerchantDomain {
  private http: DataMerchantResource

  constructor(dataMerchantHttpResource: DataMerchantResource) {
    this.http = dataMerchantHttpResource
  }

  findMerhchantWithFilter(filter: FindMerchantFilter): Promise<DataMerchantType[]> {
    return this.http.findMerhchantWithFilter(filter)
  }

  getMerchantById(idMerchant: string): Promise<DataMerchantType> {
    return this.http.getMerchantById(idMerchant)
  }
}