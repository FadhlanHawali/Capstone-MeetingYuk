export type DataMerchantType = {
	id: string,
	nama_tempat: string,
	nama_pemilik: string,
	url_foto: string,
	no_telepon: string,
	email: string,
	alamat: {
		type: 'Point',
		coordinates: number[]
	},
	str_alamat: string,
	rating?: {
		average: number | null,
		count: number | null
	},
	fcm?: string
}

export type FindMerchantFilter = {
	name?: string
	strLocation?: string
	roomCapacity?: number
	nearLocation?: {
		lat: number
		lng: number
		radius?: number
	}
	startFrom?: boolean
}