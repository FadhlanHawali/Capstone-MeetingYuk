import { MerchantServiceType } from "./types";

export interface MerchantServiceResource {
  getMerchantService(idMerchant: string): Promise<MerchantServiceType[]>
}

export class MerchantServiceDomain {
  private http: MerchantServiceResource

  constructor(merchantServiceHttpResource: MerchantServiceResource) {
    this.http = merchantServiceHttpResource
  }

  getMerchantService(idMerchant: string): Promise<MerchantServiceType[]> {
    return this.http.getMerchantService(idMerchant)
  }
}