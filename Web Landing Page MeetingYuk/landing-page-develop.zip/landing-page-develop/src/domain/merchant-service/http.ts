import axios from 'axios'
import { MerchantServiceResource } from "./merchant-service";
import { commonError } from '../../error/error';
import { MerchantServiceType } from './types';

export class MerchantServiceHttpResource implements MerchantServiceResource {
  private serviceName = 'MerchantEngine'
  private host: string

  constructor(merchantEngineHost: string) {
    this.host = merchantEngineHost
  }
  
  async getMerchantService(idMerchant: string): Promise<MerchantServiceType[]> {
    try {
      var response = await axios.get(`${this.host}/user/merchant/list-service?id_merchant=${idMerchant}`)
    } catch (error) {
      return Promise.reject(commonError.thirdPartyError(this.serviceName, error.message))
    }

    return response.data.data
  }
}