export type MerchantServiceType = {
	id?: string,
	id_merchant: string,
	name: string,
	price: number,
	description: number,
	photos: MerchantServiceImage[],
	icon: {
		id: ServiceType,
		url: string
	},
	quantity: number,
	available?: boolean,
	unit: MerchantServiceUnitType
}

type MerchantServiceImage = {
	url: string
}

export type MerchantServiceUnitType = 'hour' | 'packet';

export type ServiceType = 'balroom' | 'conference' | 'food' | 'music' | 'room' | 'wedding'