export interface MeetingYukError {
   code: string
   httpStatus: number
   title: string
   detailEn: string
   detailId: string
   message: string
}

interface CommonError {
   validationError(message: string): MeetingYukError
   databaseError(message: string): MeetingYukError
   fileServiceError(message: string): MeetingYukError
   messageServiceError(message: string): MeetingYukError
   thirdPartyError(service: string, message: string): MeetingYukError
   libraryError(message: string): MeetingYukError
   dataNotFound(notFoundEntity: string): MeetingYukError
}

export const commonError: CommonError = {
   validationError: function (message: string) {
       const err: MeetingYukError = {
           code: '00001',
           httpStatus: 404,
           title: 'Validation Error',
           detailEn: message,
           detailId: message,
           message: message
       }

       return err;
   },
   databaseError: function (message: string) {
       const err: MeetingYukError = {
           code: '00002',
           httpStatus: 500,
           title: 'Database Error',
           detailEn: message,
           detailId: message,
           message: message
       }

       return err;
   },
   fileServiceError: function (message: string) {
       const err: MeetingYukError = {
           code: '00003',
           httpStatus: 500,
           title: 'File Service Error',
           detailEn: message,
           detailId: message,
           message: message
       }

       return err;
   },
   messageServiceError: function (message: string) {
       const err: MeetingYukError = {
           code: '00004',
           httpStatus: 500,
           title: 'Message Service Error',
           detailEn: message,
           detailId: message,
           message: message
       }

       return err;
   },
   thirdPartyError: function (service: string, message: string) {
       const err: MeetingYukError = {
           code: '00005',
           httpStatus: 500,
           title: `${service} error`,
           detailEn: message,
           detailId: message,
           message: message
       }

       return err;
   },
   libraryError: function (message: string) {
       const err: MeetingYukError = {
           code: '00006',
           httpStatus: 500,
           title: 'Library Error',
           detailEn: message,
           detailId: message,
           message: message
       }

       return err;
   },
   dataNotFound: function(notFoundEntity: string){
        const err: MeetingYukError = {
            code: '00007',
            httpStatus: 404,
            title: 'Data not found',
            detailEn: `${notFoundEntity} not found`,
            detailId: `Data ${notFoundEntity} tidak ditemukan`,
            message: `Data ${notFoundEntity} tidak ditemukan`
        }

        return err;
    }
}