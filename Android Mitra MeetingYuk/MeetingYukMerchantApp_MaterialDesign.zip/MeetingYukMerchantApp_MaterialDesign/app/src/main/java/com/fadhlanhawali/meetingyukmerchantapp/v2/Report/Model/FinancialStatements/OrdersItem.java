package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class OrdersItem{

	@SerializedName("item")
	private List<ItemItem> item;

	@SerializedName("order")
	private Order order;

	public void setItem(List<ItemItem> item){
		this.item = item;
	}

	public List<ItemItem> getItem(){
		return item;
	}

	public void setOrder(Order order){
		this.order = order;
	}

	public Order getOrder(){
		return order;
	}

	@Override
 	public String toString(){
		return 
			"OrdersItem{" + 
			"item = '" + item + '\'' + 
			",order = '" + order + '\'' + 
			"}";
		}
}