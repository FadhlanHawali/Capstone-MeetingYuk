package com.fadhlanhawali.meetingyukmerchantapp.v2.API;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.RetrofitClient;

public class ChatAPIUtils {

    public ChatAPIUtils(){

    }

    public static ChatInterfaceAPI getChatService(){
        return RetrofitClient.getChatClient(BuildConfig.API_CHAT_URL).create(ChatInterfaceAPI.class);
    }

}
