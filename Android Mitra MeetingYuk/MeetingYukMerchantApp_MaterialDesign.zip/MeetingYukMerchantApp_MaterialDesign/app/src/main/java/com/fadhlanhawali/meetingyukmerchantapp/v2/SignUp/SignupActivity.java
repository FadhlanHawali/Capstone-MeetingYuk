package com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.UploadFileServiceModel.UploadFileServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.Model.Alamat;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.Model.SignUpRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Camera.CameraContract;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Camera.CameraPresenter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewDialog;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class SignupActivity extends AppCompatActivity implements SignupContract.vSignUp, CameraContract.View{

    private SignupContract.pSignUp mPresenter;

    SessionManager sessionManager;
    private CameraPresenter cameraPresenter;
    static final int REQUEST_TAKE_PHOTO = 101;
    static final int REQUEST_GALLERY_PHOTO = 102;
    private static final int PLACE_PICKER_REQUEST = 1000;
    private Double latitude, longitude;
    static String[] permissions = new String[]{
            Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    Uri photoURI;
    EditText namaTempat, namaPemilik, nomorTelepon, email, password, confirmPassword, alamat;
    ImageView imgMerchant,setMap, ivNavigateBack;
    Button btnSimpan, btnDecline;
    RelativeLayout btnPhoto;
    ViewDialog viewDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up2);
        mPresenter = new SignupPresenter(this,this);
        cameraPresenter = new CameraPresenter(this);
        mPresenter.initP();
    }

    @Override
    public void initV() {
        cameraPresenter.setUri("");
        viewDialog = new ViewDialog(this);
        ivNavigateBack = findViewById(R.id.ivNavigateBack);
        namaTempat = findViewById(R.id.edittextNamaTempat);
        namaPemilik = findViewById(R.id.edittextNamaPemilik);
        nomorTelepon = findViewById(R.id.edittextNomorTelepon);
        email = findViewById(R.id.edittextEmail);
        password = findViewById(R.id.edittextPassword);
        confirmPassword = findViewById(R.id.edittextConfirmationPassword);
        alamat = findViewById(R.id.edittextAlamat);
        btnSimpan = findViewById(R.id.btnSimpan);
        btnDecline = findViewById(R.id.btnDecline);
        setMap = findViewById(R.id.setMap);
        imgMerchant = findViewById(R.id.photo);
        btnPhoto = findViewById(R.id.btnPhoto);

        sessionManager = new SessionManager(this);

        btnSimpan.setOnClickListener(v -> {

            if (validate(new EditText[]{namaTempat,namaPemilik,nomorTelepon,email,password,confirmPassword,alamat}) && latitude != null && longitude != null){
                if (!cameraPresenter.getUri().equals("")) {
                    String uriPath = cameraPresenter.getUri();
                    File mFile = new File(uriPath);
                    RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"), mFile);
                    MultipartBody.Part body = MultipartBody.Part.createFormData("file",mFile.getName(),requestBody);
                    mPresenter.doUploadFile(body);
                    viewDialog.showDialog();
                }else if(!photoURI.getPath().equals("")){
                    File mFile = new File(getFilePathForN(photoURI,this));
                    RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"), mFile);
                    MultipartBody.Part body = MultipartBody.Part.createFormData("file",mFile.getName(),requestBody);
                    viewDialog.showDialog();
                    mPresenter.doUploadFile(body);
                }else {
                    Toast.makeText(this, "Data Belum Lengkap !", Toast.LENGTH_SHORT).show();
                }
            }else {
                Toast.makeText(this, "Data Belum Lengkap !", Toast.LENGTH_SHORT).show();
            }
        });

        ivNavigateBack.setOnClickListener(v ->{
            finish();
        });

        btnDecline.setOnClickListener(v -> {
            finish();
        });

        setMap.setOnClickListener(v -> {
            placePicker();
        });

        btnPhoto.setOnClickListener(v -> {
            selectImage();
        });
    }

    @Override
    public void onSignUpResult(Boolean result, int code) {
        if (result){
            viewDialog.hideDialog();
            Toast.makeText(this, "Sukses dalam membuat akun merchant baru !", Toast.LENGTH_SHORT).show();
            finish();
        }else {
            viewDialog.hideDialog();
            Toast.makeText(this, "Terjadi kesalahan dalam membuat akun, silahkan coba lagi !" + code, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onUploadFileResult(Boolean result, int code, UploadFileServiceResponseModel uploadFileServiceResponseModel) {
        if (result){
            SignUpRequestModel signUpRequestModel = new SignUpRequestModel(
                    namaPemilik.getText().toString(),
                    uploadFileServiceResponseModel.getData().getUrl(),
                    password.getText().toString(),
                    alamat.getText().toString(),
                    namaTempat.getText().toString(),
                    email.getText().toString(),
                    nomorTelepon.getText().toString(),
                    new Alamat(
                        longitude,latitude
                    ),confirmPassword.getText().toString()
            );
//            Toast.makeText(this, signUpRequestModel.toString(), Toast.LENGTH_SHORT).show();
            mPresenter.doSignUp(signUpRequestModel, sessionManager.getUserDetails().get(SessionManager.KEY_TOKEN));
        }else if(code != 0){
            viewDialog.hideDialog();
            Toast.makeText(getApplicationContext(), "Terjadi sebuah kesalahan, silahkan coba lagi !", Toast.LENGTH_SHORT).show();
        }else {
            viewDialog.hideDialog();
            Toast.makeText(getApplicationContext(),"Terjadi sebuah kesalahan, silahkan coba lagi !",Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public boolean checkPermission() {
        for (String mPermission : permissions) {
            int result = ActivityCompat.checkSelfPermission(this, mPermission);
            if (result == PackageManager.PERMISSION_DENIED) return false;
        }
        return true;
    }
    @Override
    public void showPermissionDialog() {
        Dexter.withActivity(this).withPermissions(permissions)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                        }
                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            showSettingsDialog();
                        }
                    }
                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).withErrorListener(error -> showErrorDialog())
                .onSameThread()
                .check();
    }

    @Override
    public File getFilePath() {
        return getExternalFilesDir(Environment.DIRECTORY_PICTURES);
    }

    @Override
    public void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    @Override
    public void startCamera(File file) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            if (file != null) {
                photoURI = FileProvider.getUriForFile(this,
                        BuildConfig.APPLICATION_ID + ".provider", file);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);

            }
        }
    }

    @Override
    public void chooseGallery() {
        Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickPhoto.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(pickPhoto, REQUEST_GALLERY_PHOTO);
    }

    @Override
    public void showNoSpaceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.error_message_no_more_space));
        builder.setMessage(getString(R.string.error_message_insufficient_space));
        builder.setPositiveButton(getString(R.string.ok), (dialog, which) -> dialog.cancel());
        builder.show();
    }

    @Override
    public int availableDisk() {
        File mFilePath = getFilePath();
        long freeSpace = mFilePath.getFreeSpace();
        return Math.round(freeSpace / 1048576);
    }

    @Override
    public File newFile() {
        Calendar cal = Calendar.getInstance();
        long timeInMillis = cal.getTimeInMillis();
        String mFileName = timeInMillis + ".jpeg";
        File mFilePath = getFilePath();
        try {
            File newFile = new File(mFilePath.getAbsolutePath(), mFileName);
            newFile.createNewFile();
            return newFile;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void showErrorDialog() {
        Toast.makeText(getApplicationContext(), getString(R.string.error_message), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void displayImagePreview(String mFilePath) {
        Glide.with(SignupActivity.this).load(mFilePath).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imgMerchant);
    }

    @Override
    public void displayImagePreview(Uri mFileUri) {
        Glide.with(SignupActivity.this).load(mFileUri).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imgMerchant);
    }

    @Override
    public String getRealPathFromUri(Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Images.Media.DATA};
            cursor = getContentResolver().query(contentUri, proj, null, null, null);
            assert cursor != null;
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(columnIndex);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_TAKE_PHOTO) {
                cameraPresenter.showPreview(photoURI);

            } else if (requestCode == REQUEST_GALLERY_PHOTO) {
                Uri selectedImage = data.getData();
                String mPhotoPath = getRealPathFromUri(selectedImage);

                Log.d("URI IMAGE :", selectedImage.toString());
                Log.d("mPhotoPath : ", mPhotoPath);

                cameraPresenter.setUri(mPhotoPath);
                cameraPresenter.showPreview(mPhotoPath);
            }
        }
        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                Place place = PlacePicker.getPlace(this,data);
//                String toastMsg = String.format("Place: %s", place.getLatLng());
//                Toast.makeText(this, toastMsg, Toast.LENGTH_LONG).show();
                alamat.setText(place.getAddress());
                latitude = place.getLatLng().latitude;
                longitude = place.getLatLng().longitude;
            }
        }
    }

    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.message_need_permission));
        builder.setMessage(getString(R.string.message_grant_permission));
        builder.setPositiveButton(getString(R.string.label_setting), (dialog, which) -> {
            dialog.cancel();
            openSettings();
        });
        builder.setNegativeButton(getString(R.string.cancel), (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void selectImage() {
        final CharSequence[] items = {getString(R.string.take_photo), getString(R.string.choose_gallery),
                getString(R.string.cancel)};
        AlertDialog.Builder builder = new AlertDialog.Builder(SignupActivity.this);
        builder.setItems(items, (dialog, item) -> {
            if (items[item].equals("Take Photo")) {
                cameraPresenter.cameraClick();
            } else if (items[item].equals("Choose from Gallery")) {
                cameraPresenter.ChooseGalleryClick();
            } else if (items[item].equals("Cancel")) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    public void placePicker()
    {
        PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
        try {
            startActivityForResult(builder.build(SignupActivity.this), PLACE_PICKER_REQUEST);
        } catch (GooglePlayServicesRepairableException e) {
            e.printStackTrace();
        } catch (GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }

    }

    private static String getFilePathForN(Uri uri, Context context) {
        Uri returnUri = uri;
        Cursor returnCursor = context.getContentResolver().query(returnUri, null, null, null, null);
        /*
         * Get the column indexes of the data in the Cursor,
         *     * move to the first row in the Cursor, get the data,
         *     * and display it.
         * */
        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
        returnCursor.moveToFirst();
        String name = (returnCursor.getString(nameIndex));
        String size = (Long.toString(returnCursor.getLong(sizeIndex)));
        File file = new File(context.getFilesDir(), name);
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            FileOutputStream outputStream = new FileOutputStream(file);
            int read = 0;
            int maxBufferSize = 1 * 1024 * 1024;
            int bytesAvailable = inputStream.available();

            //int bufferSize = 1024;
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);

            final byte[] buffers = new byte[bufferSize];
            while ((read = inputStream.read(buffers)) != -1) {
                outputStream.write(buffers, 0, read);
            }
            Log.e("File Size", "Size " + file.length());
            inputStream.close();
            outputStream.close();
            Log.e("File Path", "Path " + file.getPath());
            Log.e("File Size", "Size " + file.length());
        } catch (Exception e) {
            Log.e("Exception", e.getMessage());
        }
        return file.getPath();
    }

    private boolean validate(EditText[] fields){
        for(int i = 0; i < fields.length; i++){
            EditText currentField = fields[i];
            if(currentField.getText().toString().length() <= 0){
                return false;
            }
        }
        return true;
    }


}
