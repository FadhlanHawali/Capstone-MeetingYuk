package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ConvertDate;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem;
import com.vanniktech.emoji.EmojiTextView;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatAdapter extends RecyclerView.Adapter {
    private Context mContext;
    private List<DataItem> mChatList;
    private String idMerchant;

    private static final int VIEW_TYPE_MESSAGE_SENT = 1;
    private static final int VIEW_TYPE_MESSAGE_RECEIVED = 2;
    private static final int VIEW_TYPE_IMAGE_SENT = 3;
    private static final int VIEW_TYPE_IMAGE_RECEIVED = 4;
    private static final int VIEW_TYPE_FILE_SENT = 5;
    private static final int VIEW_TYPE_FILE_RECEIVED = 6;

    private static final String CHAT_TYPE_TEXT = "text";
    private static final String CHAT_TYPE_IMAGE = "image";
    private static final String CHAT_TYPE_FILE = "file";

    public ChatAdapter(Context context, List<DataItem> chatList, String idMerchant){
        mContext = context;
        mChatList = chatList;
        this.idMerchant = idMerchant;
    }

    private class ReceivedMessageHolder extends RecyclerView.ViewHolder{

        TextView tvMessageTextBodyLeft,tvMessageTextTimeLeft;
        CircleImageView imageView;
        ConvertDate convertDate = new ConvertDate();

        ReceivedMessageHolder(View itemView){
            super(itemView);

            tvMessageTextBodyLeft = itemView.findViewById(R.id.tvMessageTextBodyLeft);
            tvMessageTextTimeLeft = itemView.findViewById(R.id.tvMessageTextTimeLeft);
            imageView = itemView.findViewById(R.id.ivMessageTextProfileLeft);
        }

        void bind(DataItem mChatList){
            tvMessageTextBodyLeft.setText(mChatList.getText());
            tvMessageTextTimeLeft.setText(convertDate.convertTime(mChatList.getTimestamp()));
            Glide.with(mContext).load("https://" + mChatList.getFromUserAvatarUrl())
                    .apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera))
                    .into(imageView);
        }

    }

    private class SentMessageHolder extends RecyclerView.ViewHolder{
        LinearLayout llMessageTextBatchTimestampRight, bubble, llMessageRepliedRight;

        TextView tvMessageTextUnreadRight,
                tvMessageTextBatchTimestampRight,
                tvTextForwardRight,
                tvMessageRepliedNameRight,
                tvMessageTextTimeRight,
                tvMessageTextSendStatusRight;

        EmojiTextView tvMessageRepliedBodyRight,tvMessageTextBodyRignt;

        ImageView ivMessageRepliedImageRight;

        View separatorRight;

        ConvertDate convertDate = new ConvertDate();

        SentMessageHolder(View itemView){
            super(itemView);

            llMessageRepliedRight = itemView.findViewById(R.id.llMessageRepliedRight);
            llMessageTextBatchTimestampRight = itemView.findViewById(R.id.llMessageTextBatchTimestampRight);
            bubble = itemView.findViewById(R.id.bubble);
            tvMessageTextUnreadRight = itemView.findViewById(R.id.tvMessageTextUnreadRight);
            tvMessageTextBatchTimestampRight = itemView.findViewById(R.id.tvMessageTextBatchTimestampRight);
            tvTextForwardRight = itemView.findViewById(R.id.tvTextForwardRight);
            tvMessageRepliedNameRight = itemView.findViewById(R.id.tvMessageRepliedNameRight);
            tvMessageRepliedBodyRight = itemView.findViewById(R.id.tvMessageRepliedBodyRight);
            tvMessageTextBodyRignt = itemView.findViewById(R.id.tvMessageTextBodyRight);
            tvMessageTextTimeRight = itemView.findViewById(R.id.tvMessageTextTimeRight);
            tvMessageTextSendStatusRight = itemView.findViewById(R.id.tvMessageTextSendStatusRight);

            ivMessageRepliedImageRight = itemView.findViewById(R.id.ivMessageRepliedImageRight);

            separatorRight = itemView.findViewById(R.id.separatorRight);
        }

        void bind(DataItem mChatList){

            tvMessageTextBodyRignt.setText(mChatList.getText());
            tvMessageTextTimeRight.setText(convertDate.convertTime(mChatList.getTimestamp()));
        }
    }

    private class SentImageHolder extends RecyclerView.ViewHolder{
        SentImageHolder(View itemView){
            super(itemView);
        }

        void bind(){

        }
    }


    private class ReceivedImageHolder extends RecyclerView.ViewHolder{
        ReceivedImageHolder(View itemView){
            super (itemView);
        }
    }

    private class SentFileHolder extends RecyclerView.ViewHolder{
        SentFileHolder(View itemView){
            super (itemView);

        }
    }

    private class ReceivedFileHolder extends RecyclerView.ViewHolder{
        ReceivedFileHolder(View itemView){
            super(itemView);

        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;

        if (viewType == VIEW_TYPE_MESSAGE_SENT) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_text_right, parent, false);
            return new SentMessageHolder(view);
        } else if (viewType == VIEW_TYPE_MESSAGE_RECEIVED) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_text_left, parent, false);
            return new ReceivedMessageHolder(view);
        } else if (viewType == VIEW_TYPE_IMAGE_SENT) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_image_right, parent, false);
            return new ReceivedMessageHolder(view);
        } else if (viewType == VIEW_TYPE_IMAGE_RECEIVED) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_image_left, parent, false);
            return new ReceivedMessageHolder(view);
        } else if (viewType == VIEW_TYPE_FILE_SENT) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_file_right, parent, false);
            return new ReceivedMessageHolder(view);
        } else if (viewType == VIEW_TYPE_FILE_RECEIVED) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_file_left, parent, false);
            return new ReceivedMessageHolder(view);
        }

        return null;
    }

    // Determines the appropriate ViewType according to the sender of the message.
    @Override
    public int getItemViewType(int position) {

        String type = mChatList.get(position).getType();
        String fromUserId = mChatList.get(position).getFromUserId().toString();

        if(isMyMessage(idMerchant,fromUserId)){
            switch (type) {
                case CHAT_TYPE_TEXT:
                    return VIEW_TYPE_MESSAGE_SENT;
                case CHAT_TYPE_FILE:
                    return VIEW_TYPE_FILE_SENT;
                case CHAT_TYPE_IMAGE:
                    return VIEW_TYPE_IMAGE_SENT;
            }
        }else {
            switch (type) {
                case CHAT_TYPE_TEXT:
                    return VIEW_TYPE_MESSAGE_RECEIVED;
                case CHAT_TYPE_FILE:
                    return VIEW_TYPE_FILE_RECEIVED;
                case CHAT_TYPE_IMAGE:
                    return VIEW_TYPE_IMAGE_RECEIVED;
            }
        }

        return 0;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()){
            case VIEW_TYPE_MESSAGE_SENT:
                ((SentMessageHolder) holder).bind(mChatList.get(position));
            case VIEW_TYPE_MESSAGE_RECEIVED:
                ((ReceivedMessageHolder) holder).bind(mChatList.get(position));
        }
    }

    @Override
    public int getItemCount() {
        return mChatList.size();
    }

    boolean isMyMessage(String idMerchant, String fromUserId){
        return idMerchant.equals(fromUserId);
    }
}

