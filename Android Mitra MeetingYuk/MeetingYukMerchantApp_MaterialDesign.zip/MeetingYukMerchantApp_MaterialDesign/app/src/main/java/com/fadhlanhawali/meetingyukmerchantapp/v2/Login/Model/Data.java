package com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Data{

	@SerializedName("access")
	private String access;

	@SerializedName("profile")
	private Profile profile;

	@SerializedName("token")
	private String token;

	public void setAccess(String access){
		this.access = access;
	}

	public String getAccess(){
		return access;
	}

	public void setProfile(Profile profile){
		this.profile = profile;
	}

	public Profile getProfile(){
		return profile;
	}

	public void setToken(String token){
		this.token = token;
	}

	public String getToken(){
		return token;
	}

	@Override
 	public String toString(){
		return 
			"Data{" + 
			"access = '" + access + '\'' + 
			",profile = '" + profile + '\'' + 
			",token = '" + token + '\'' + 
			"}";
		}
}