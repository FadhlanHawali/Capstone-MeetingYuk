package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class TopServicesItem{

	@SerializedName("order_count")
	private int orderCount;

	@SerializedName("service")
	private Service service;

	public void setOrderCount(int orderCount){
		this.orderCount = orderCount;
	}

	public int getOrderCount(){
		return orderCount;
	}

	public void setService(Service service){
		this.service = service;
	}

	public Service getService(){
		return service;
	}

	@Override
 	public String toString(){
		return 
			"TopServicesItem{" + 
			"order_count = '" + orderCount + '\'' + 
			",service = '" + service + '\'' + 
			"}";
		}
}