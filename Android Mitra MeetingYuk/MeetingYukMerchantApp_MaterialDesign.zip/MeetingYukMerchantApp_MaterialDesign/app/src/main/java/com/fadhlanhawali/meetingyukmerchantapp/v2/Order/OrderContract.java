package com.fadhlanhawali.meetingyukmerchantapp.v2.Order;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.GetListRoomChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Order.Model.OrderDetailResponse;

import java.util.ArrayList;

public interface OrderContract {

    interface vStatusOrder{
        void initV();
        void onDetailOrderResult (Boolean result, int code, OrderDetailResponse orderDetailResponse);
        void onAcceptOrderResult(Boolean result, int code);
        void onDeclineOrderResult(Boolean result, int code);
        void onGetListRoomChatResult(Boolean result, int code, GetListRoomChatResponseModel getListRoomChatResponseModel);
        void onGetServiceListResult(Boolean result, int code, ListServiceResponse listServiceResponse);
        void onInitChatRoom (Boolean result, int code, InitChatRoomResponseModel initChatRoomResponseModel);
    }

    interface pStatusOrder{
        void initP();
        void doGetDetailOrder(String token, String idMeeting);
        void doAcceptOrder(String token, String idMeeting);
        void doDeclineOrder(String toke , String idMeeting);
        void getListRoomChat(String idMerchant);
        void dbInsertListRoomChat(GetListRoomChatResponseModel listRoomChat);
        void getServiceList(String token);
        void initChatRoom(InitChatRoomRequestModel initChatRoomRequestModel);
    }


    interface vWaitingOrder{
        void initV();
        void onResult(Boolean result, int code, OrderResponseModel orderResponseModel);
    }

    interface pWaitingOrder{
        void initP();
        void getWaitingOrder(String token);
    }

    interface vAcceptedOrder{
        void initV();
        void onResult(Boolean result, int code, OrderResponseModel orderResponseModel);
    }

    interface pAcceptedOrder{
        void initP();
        void getOrderAccepted (String token);
    }
}
