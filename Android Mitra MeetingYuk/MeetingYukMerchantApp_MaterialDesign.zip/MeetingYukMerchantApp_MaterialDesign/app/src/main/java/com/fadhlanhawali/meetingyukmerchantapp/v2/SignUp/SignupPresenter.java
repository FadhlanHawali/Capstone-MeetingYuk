package com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.v2.API.APIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.InterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.UploadFileServiceModel.UploadFileServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.Model.SignUpRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.Model.SignUpResponseModel;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.ui.PlacePicker;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupPresenter implements SignupContract.pSignUp {

    Context mContext;
    SignupContract.vSignUp mView;
    private InterfaceAPI serviceAPI;


    public SignupPresenter (Context mContext, SignupContract.vSignUp mView){
        this.mContext = mContext;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void doSignUp(SignUpRequestModel signUpRequestModel, String token) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.signUp(token, signUpRequestModel).enqueue(new Callback<SignUpResponseModel>() {
            @Override
            public void onResponse(Call<SignUpResponseModel> call, Response<SignUpResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onSignUpResult(true, response.code());
                }else {
                    mView.onSignUpResult(false, response.code());
                }
            }

            @Override
            public void onFailure(Call<SignUpResponseModel> call, Throwable t) {

            }
        });
    }

    //TODO HOTFIX UPLOAD FILE
    @Override
    public void doUploadFile(MultipartBody.Part body) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.uploadFileService(body).enqueue(new Callback<UploadFileServiceResponseModel>() {
            @Override
            public void onResponse(Call<UploadFileServiceResponseModel> call, Response<UploadFileServiceResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onUploadFileResult(true, response.code(), response.body());
                }else {
                    mView.onUploadFileResult(false, response.code(), response.body());
                }
            }

            @Override
            public void onFailure(Call<UploadFileServiceResponseModel> call, Throwable t) {
                Toast.makeText(mContext,"ERROR : " + t.getMessage(),Toast.LENGTH_SHORT).show();
                mView.onUploadFileResult(false,0,null);
            }
        });
    }

    @Override
    public void doPlacePicker(Activity activity, int RequestCode) {
        PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
        try {
            activity.startActivityForResult(builder.build(activity), RequestCode);
        } catch (GooglePlayServicesRepairableException e) {
            e.printStackTrace();
        } catch (GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }
    }


}
