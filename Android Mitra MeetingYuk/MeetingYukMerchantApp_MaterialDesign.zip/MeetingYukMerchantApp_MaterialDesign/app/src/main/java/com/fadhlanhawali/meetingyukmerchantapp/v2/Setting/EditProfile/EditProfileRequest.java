package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.EditProfile;

import com.google.gson.annotations.SerializedName;

public class EditProfileRequest{

	@SerializedName("nama_pemilik")
	private String namaPemilik;

	@SerializedName("url_foto")
	private String urlFoto;

	@SerializedName("str_alamat")
	private String strAlamat;

	@SerializedName("nama_tempat")
	private String namaTempat;

	@SerializedName("email")
	private String email;

	@SerializedName("no_telepon")
	private String noTelepon;

	@SerializedName("alamat")
	private Alamat alamat;

	public void setNamaPemilik(String namaPemilik){
		this.namaPemilik = namaPemilik;
	}

	public String getNamaPemilik(){
		return namaPemilik;
	}

	public void setUrlFoto(String urlFoto){
		this.urlFoto = urlFoto;
	}

	public String getUrlFoto(){
		return urlFoto;
	}

	public void setStrAlamat(String strAlamat){
		this.strAlamat = strAlamat;
	}

	public String getStrAlamat(){
		return strAlamat;
	}

	public void setNamaTempat(String namaTempat){
		this.namaTempat = namaTempat;
	}

	public String getNamaTempat(){
		return namaTempat;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

	public void setNoTelepon(String noTelepon){
		this.noTelepon = noTelepon;
	}

	public String getNoTelepon(){
		return noTelepon;
	}

	public void setAlamat(Alamat alamat){
		this.alamat = alamat;
	}

	public Alamat getAlamat(){
		return alamat;
	}

	public EditProfileRequest(String namaPemilik, String urlFoto, String strAlamat, String namaTempat, String email, String noTelepon, Alamat alamat) {
		this.namaPemilik = namaPemilik;
		this.urlFoto = urlFoto;
		this.strAlamat = strAlamat;
		this.namaTempat = namaTempat;
		this.email = email;
		this.noTelepon = noTelepon;
		this.alamat = alamat;
	}

	@Override
 	public String toString(){
		return 
			"EditProfileRequest{" + 
			"nama_pemilik = '" + namaPemilik + '\'' + 
			",url_foto = '" + urlFoto + '\'' + 
			",str_alamat = '" + strAlamat + '\'' + 
			",nama_tempat = '" + namaTempat + '\'' + 
			",email = '" + email + '\'' + 
			",no_telepon = '" + noTelepon + '\'' + 
			",alamat = '" + alamat + '\'' + 
			"}";
		}
}