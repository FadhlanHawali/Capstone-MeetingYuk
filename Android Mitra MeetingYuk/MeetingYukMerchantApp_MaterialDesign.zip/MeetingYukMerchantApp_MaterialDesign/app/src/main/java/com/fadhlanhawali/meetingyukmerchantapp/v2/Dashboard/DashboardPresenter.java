package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard;

import android.content.Context;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.APIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.InterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.IDashboardAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterRequestModel.OrderFilterRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterResponseModel.OrderFilterResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.Utils.DashboardAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardPresenter implements DashboardContract.pOrderAccepted{
    Context mContext;
    DashboardContract.vOrderAccepted mView;
    private IDashboardAPI serviceAPI;
    private InterfaceAPI interfaceAPI;
    SessionManager sessionManager;

    public DashboardPresenter(Context mContext, DashboardContract.vOrderAccepted mView) {
        this.mContext = mContext;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void getOrderFilter(String token, OrderFilterRequestModel orderFilterRequestModel) {
        serviceAPI = DashboardAPIUtils.getAPIService();
        serviceAPI.getOrderFilter(token,orderFilterRequestModel).enqueue(new Callback<OrderFilterResponseModel>() {
            @Override
            public void onResponse(Call<OrderFilterResponseModel> call, Response<OrderFilterResponseModel> response) {
                if (response.isSuccessful()) {
                    mView.onOrderFilter(true,response.code(),response.body());
                }else {
                    mView.onOrderFilter(false,response.code(),response.body());
                }
            }

            @Override
            public void onFailure(Call<OrderFilterResponseModel> call, Throwable t) {
                Toast.makeText(mContext, "Error : " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void sendToken(String token, String firebaseToken) {
        interfaceAPI = APIUtils.getAPIService();
        interfaceAPI.pushToken(token,firebaseToken).enqueue(new Callback<GeneralResponseModel>() {
            @Override
            public void onResponse(Call<GeneralResponseModel> call, Response<GeneralResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onSendToken(true, response.code(),call.request().url().toString());
                }else {
                    mView.onSendToken(false, response.code(),call.request().url().toString());
                }
            }

            @Override
            public void onFailure(Call<GeneralResponseModel> call, Throwable t) {

            }
        });

    }
}
