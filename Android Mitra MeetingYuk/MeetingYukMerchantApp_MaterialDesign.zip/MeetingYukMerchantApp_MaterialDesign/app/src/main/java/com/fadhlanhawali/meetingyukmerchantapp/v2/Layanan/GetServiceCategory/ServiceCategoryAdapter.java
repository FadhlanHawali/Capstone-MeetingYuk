package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.GetServiceCategory;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.R;

import java.util.List;

public class ServiceCategoryAdapter extends RecyclerView.Adapter<ServiceCategoryAdapter.MyViewHolder> {

    private Context mContext;
    private List<com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.CategoryServiceModel.DataItem> categoryList;

    int row_index = -1;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        CardView cardViewCategory;
        TextView txtServiceCategory;
        ImageView imageServiceCategory;
        public MyViewHolder(final View view) {
            super(view);
            txtServiceCategory = view.findViewById(R.id.txtServiceCategory);
            imageServiceCategory = view.findViewById(R.id.imageCategory);
            cardViewCategory = view.findViewById(R.id.cardViewCategory);
        }

    }


    public ServiceCategoryAdapter(Context mContext, List<com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.CategoryServiceModel.DataItem> categoryList ) {
        this.mContext = mContext;
        this.categoryList = categoryList;
    }

    @Override
    public ServiceCategoryAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_list_service_category, parent, false);

        return new ServiceCategoryAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ServiceCategoryAdapter.MyViewHolder holder, final int position) {
        final com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.CategoryServiceModel.DataItem category = categoryList.get(position);

        holder.txtServiceCategory.setText(category.getText());
        Glide.with(mContext).load("https://"+category.getUrl()).apply(new RequestOptions().fitCenter().placeholder(R.drawable.camera)).into(holder.imageServiceCategory);

        holder.cardViewCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                row_index = position;
                notifyDataSetChanged();
            }
        });

        if(row_index==position){
            Intent intent = new Intent("service");
            //            intent.putExtra("quantity",Integer.parseInt(quantity.getText().toString()));
            intent.putExtra("serviceCategoryId",category.getId());
            intent.putExtra("serviceCategoryUrl",category.getUrl());
            intent.putExtra("serviceCategoryText",category.getText());
            LocalBroadcastManager.getInstance(mContext).sendBroadcast(intent);

            Glide.with(mContext).load("https://"+category.getUrl()).apply(new RequestOptions().fitCenter().placeholder(R.drawable.camera)).into(holder.imageServiceCategory);
            holder.cardViewCategory.setBackground(mContext.getDrawable(R.drawable.color_gradient_1));
        }
        else
        {
            Glide.with(mContext).load("https://"+category.getUrl()).apply(new RequestOptions().fitCenter().placeholder(R.drawable.camera)).into(holder.imageServiceCategory);
            holder.cardViewCategory.setBackgroundColor(Color.parseColor("#ffffff"));
        }
    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }
}