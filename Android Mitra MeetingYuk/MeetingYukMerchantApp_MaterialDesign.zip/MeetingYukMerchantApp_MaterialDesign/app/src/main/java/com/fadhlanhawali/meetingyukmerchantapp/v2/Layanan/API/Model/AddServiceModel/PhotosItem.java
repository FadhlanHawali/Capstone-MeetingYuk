package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class PhotosItem{

	@SerializedName("url")
	private String url;

	public void setUrl(String url){
		this.url = url;
	}

	public String getUrl(){
		return url;
	}

	@Override
 	public String toString(){
		return 
			"PhotosItem{" + 
			"url = '" + url + '\'' + 
			"}";
		}
}