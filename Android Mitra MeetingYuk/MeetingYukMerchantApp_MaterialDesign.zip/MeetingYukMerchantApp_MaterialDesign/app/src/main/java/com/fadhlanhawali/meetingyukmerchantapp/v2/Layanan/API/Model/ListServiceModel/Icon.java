package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel;

import android.os.Parcel;
import android.os.Parcelable;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Generated("com.robohorse.robopojogenerator")
public class Icon implements Serializable, Parcelable {

	@SerializedName("id")
	private String id;

	@SerializedName("url")
	private String url;

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setUrl(String url){
		this.url = url;
	}

	public String getUrl(){
		return url;
	}

	@Override
 	public String toString(){
		return 
			"Icon{" + 
			"id = '" + id + '\'' + 
			",url = '" + url + '\'' + 
			"}";
		}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.id);
		dest.writeString(this.url);
	}

	public Icon() {
	}

	protected Icon(Parcel in) {
		this.id = in.readString();
		this.url = in.readString();
	}

	public static final Creator<Icon> CREATOR = new Creator<Icon>() {
		@Override
		public Icon createFromParcel(Parcel source) {
			return new Icon(source);
		}

		@Override
		public Icon[] newArray(int size) {
			return new Icon[size];
		}
	};
}