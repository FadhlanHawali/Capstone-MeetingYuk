package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class DataItem{

	@SerializedName("notification")
	private Notification notification;

	@SerializedName("data")
	private Data data;

	@SerializedName("is_clicked")
	private boolean isClicked;

	@SerializedName("_id")
	private String _id;

	@SerializedName("id_user")
	private String idUser;

	@SerializedName("id")
	private String id;

	@SerializedName("email")
	private String email;

	@SerializedName("timestamp")
	private long timestamp;

	public void setNotification(Notification notification){
		this.notification = notification;
	}

	public Notification getNotification(){
		return notification;
	}

	public void setData(Data data){
		this.data = data;
	}

	public Data getData(){
		return data;
	}

	public void setIsClicked(boolean isClicked){
		this.isClicked = isClicked;
	}

	public boolean isIsClicked(){
		return isClicked;
	}

	public void set_Id(String _id){
		this._id = _id;
	}

	public String get_Id(){
		return _id;
	}

	public void setIdUser(String idUser){
		this.idUser = idUser;
	}

	public String getIdUser(){
		return idUser;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

	public void setTimestamp(long timestamp){
		this.timestamp = timestamp;
	}

	public long getTimestamp(){
		return timestamp;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"notification = '" + notification + '\'' + 
			",data = '" + data + '\'' + 
			",is_clicked = '" + isClicked + '\'' + 
			",_id = '" + id + '\'' + 
			",id_user = '" + idUser + '\'' + 
			",id = '" + id + '\'' + 
			",email = '" + email + '\'' + 
			",timestamp = '" + timestamp + '\'' + 
			"}";
		}
}