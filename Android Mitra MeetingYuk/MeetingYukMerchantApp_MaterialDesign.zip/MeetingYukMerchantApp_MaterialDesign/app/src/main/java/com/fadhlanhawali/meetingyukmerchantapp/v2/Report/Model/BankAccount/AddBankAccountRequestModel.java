package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class AddBankAccountRequestModel{

	@SerializedName("account_number")
	private String accountNumber;

	@SerializedName("account_name")
	private String accountName;

	@SerializedName("bank_name")
	private String bankName;

	public void setAccountNumber(String accountNumber){
		this.accountNumber = accountNumber;
	}

	public String getAccountNumber(){
		return accountNumber;
	}

	public void setAccountName(String accountName){
		this.accountName = accountName;
	}

	public String getAccountName(){
		return accountName;
	}

	public void setBankName(String bankName){
		this.bankName = bankName;
	}

	public String getBankName(){
		return bankName;
	}

	public AddBankAccountRequestModel(String accountNumber, String accountName, String bankName) {
		this.accountNumber = accountNumber;
		this.accountName = accountName;
		this.bankName = bankName;
	}

	@Override
 	public String toString(){
		return 
			"AddBankAccountRequestModel{" + 
			"account_number = '" + accountNumber + '\'' + 
			",account_name = '" + accountName + '\'' + 
			",bank_name = '" + bankName + '\'' + 
			"}";
		}
}