package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.ServiceOrderModel;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class ServiceOrderModel{

	@SerializedName("unit")
	private String unit;

	@SerializedName("quantity")
	private int quantity;

	@SerializedName("price")
	private int price;

	@SerializedName("available")
	private boolean available;

	@SerializedName("name")
	private String name;

	@SerializedName("icon")
	private Icon icon;

	@SerializedName("id_merchant")
	private String idMerchant;

	@SerializedName("description")
	private String description;

	@SerializedName("id")
	private String id;

	@SerializedName("photos")
	private List<PhotosItem> photos;


	public String getUnit(){
		return unit;
	}

	public int getQuantity(){
		return quantity;
	}

	public int getPrice(){
		return price;
	}

	public boolean isAvailable(){
		return available;
	}

	public String getName(){
		return name;
	}

	public Icon getIcon(){
		return icon;
	}

	public String getIdMerchant(){
		return idMerchant;
	}

	public String getDescription(){
		return description;
	}

	public String getId(){
		return id;
	}

	public List<PhotosItem> getPhotos(){
		return photos;
	}
}