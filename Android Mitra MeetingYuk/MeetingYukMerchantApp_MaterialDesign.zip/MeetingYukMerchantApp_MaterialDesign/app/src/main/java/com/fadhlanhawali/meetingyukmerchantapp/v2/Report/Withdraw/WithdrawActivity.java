package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Withdraw;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.BankAccount.BankActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.GetBankAccountResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoResponseModel;

import java.util.ArrayList;
import java.util.HashMap;

public class WithdrawActivity extends AppCompatActivity implements WithdrawContract.vWtihdraw {

    WithdrawPresenter mPresenter;
    SessionManager sessionManager;
    HashMap<String, String> user;
    Button btnAddBankAccount, btnWithdraw;
    EditText etWithdrawAmount;
    String bankNumberWithdrawId = "";
    private ArrayList<DataItem> bankAccountList = new ArrayList<>();
    BankAccountAdapter bankAccountAdapter;
    RecyclerView recyclerView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_withdraw);
        mPresenter = new WithdrawPresenter(this,this);
        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver,
                new IntentFilter("withdrawService"));
        mPresenter.initP();
    }

    @Override
    public void initV() {
        sessionManager = new SessionManager(this);
        user = sessionManager.getUserDetails();
        btnAddBankAccount = findViewById(R.id.btnAddBankAccount);
        btnWithdraw = findViewById(R.id.btnWithdraw);
        etWithdrawAmount = findViewById(R.id.etWithdrawAmount);
        recyclerView = findViewById(R.id.recyclerView);
        mPresenter.getBankAccountList(user.get(SessionManager.KEY_TOKEN));

        btnAddBankAccount.setOnClickListener(view -> {
            Intent i = new Intent(this, BankActivity.class);
            startActivity(i);
        });

        btnWithdraw.setOnClickListener(view -> {
            if (!etWithdrawAmount.getText().toString().equals("")){
                WithdrawSaldoRequestModel withdrawSaldoRequestModel = new WithdrawSaldoRequestModel(bankNumberWithdrawId,Integer.valueOf(etWithdrawAmount.getText().toString()));
                mPresenter.doWithdraw(user.get(SessionManager.KEY_TOKEN), withdrawSaldoRequestModel);
            } else if(bankNumberWithdrawId.equals("")){
                Toast.makeText(this, "Select Bank Account First !", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "Enter Amount First !", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onWithdrawResult(Boolean result, int code, WithdrawSaldoResponseModel withdrawSaldoResponseModel) {
        if (result){
            Toast.makeText(this, "Succes Menarik Saldo !", Toast.LENGTH_SHORT).show();
            finish();
        }else {
            Toast.makeText(this, "Jumlah yang Anda Masukkan Tidak Sesuai !", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    @Override
    public void onBankAccountListResult(Boolean result, int code, GetBankAccountResponseModel getBankAccountResponseModel) {
        bankAccountList.addAll(getBankAccountResponseModel.getData());
        bankAccountAdapter = new BankAccountAdapter(this, bankAccountList);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(bankAccountAdapter);
    }

    public BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String bankNumberWithdrawId = intent.getStringExtra("bankNumberWithdrawId");
            setBankWithdraw(bankNumberWithdrawId);
        }
    };
    private void setBankWithdraw(String bankNumberWithdrawId){
        this.bankNumberWithdrawId = bankNumberWithdrawId;
    }
}
