package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.AddOrderRequest.AddOrderRequest;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterRequestModel.OrderFilterRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterResponseModel.OrderFilterResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Url;

public interface IDashboardAPI {

    @GET(BuildConfig.GET_ORDER_ACCEPTED)
    Call<OrderResponseModel> getOrderAccepted(@Header("x-meeting-token") String token);

    @GET(BuildConfig.GET_ORDER_WAITING)
    Call<OrderResponseModel> getOrderWaiting(@Header("x-meeting-token") String token);

    @POST(BuildConfig.GET_ORDER_FILTER)
    Call<OrderFilterResponseModel> getOrderFilter(@Header("x-meeting-token") String token,@Body OrderFilterRequestModel orderFilterRequestModel);

    @GET(BuildConfig.ACCEPT_ORDER)
    Call<OrderResponseModel> acceptOrder(@Header("x-meeting-token") String token, @Url String url, String orderId);

    @GET(BuildConfig.DECLINE_ORDER)
    Call<OrderResponseModel> declineOrder(@Header("x-meeting-token") String token, @Url String url, String orderId);

    @POST(BuildConfig.ADD_ORDER_MANUAL)
    Call<GeneralResponseModel> addOrder(@Header("x-meeting-token") String token, @Body AddOrderRequest addOrderRequest);

}
