package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class GetSaldoMitraResponse{

	@SerializedName("data")
	private int data;

	@SerializedName("success")
	private boolean success;

	public void setData(int data){
		this.data = data;
	}

	public int getData(){
		return data;
	}

	public void setSuccess(boolean success){
		this.success = success;
	}

	public boolean isSuccess(){
		return success;
	}

	@Override
 	public String toString(){
		return 
			"GetSaldoMitraResponse{" + 
			"data = '" + data + '\'' + 
			",success = '" + success + '\'' + 
			"}";
		}
}