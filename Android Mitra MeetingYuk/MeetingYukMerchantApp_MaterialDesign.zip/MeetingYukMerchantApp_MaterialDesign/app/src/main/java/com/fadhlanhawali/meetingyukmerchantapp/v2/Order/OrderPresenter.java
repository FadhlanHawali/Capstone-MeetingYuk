package com.fadhlanhawali.meetingyukmerchantapp.v2.Order;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.v2.API.APIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.ChatAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.ChatInterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.InterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.GetListRoomChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ListRoomChatDao;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Order.Model.OrderDetailResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrderPresenter implements OrderContract.pStatusOrder {

    private final Context mContext;
    OrderContract.vStatusOrder mView;
    private InterfaceAPI serviceAPI;
    private ChatInterfaceAPI chatInterfaceAPI;
    private ListRoomChatDao listRoomChatDao;

    public OrderPresenter(Context context, OrderContract.vStatusOrder mView, ListRoomChatDao listRoomChatDao) {
        this.mContext = context;
        this.mView = mView;
        this.listRoomChatDao = listRoomChatDao;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void doAcceptOrder(String token, String idMeeting) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.acceptOrder(token,idMeeting).enqueue(new Callback<OrderResponseModel>() {
            @Override
            public void onResponse(Call<OrderResponseModel> call, Response<OrderResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onAcceptOrderResult(true,response.code());
                }else {
                    mView.onAcceptOrderResult(false, response.code());
                }
            }

            @Override
            public void onFailure(Call<OrderResponseModel> call, Throwable t) {
                Toast.makeText(mContext, "Error " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void doGetDetailOrder(String token, String idMeeting) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.detailOrder(token, idMeeting).enqueue(new Callback<OrderDetailResponse>() {
            @Override
            public void onResponse(Call<OrderDetailResponse> call, Response<OrderDetailResponse> response) {
                if (response.isSuccessful()){
                    mView.onDetailOrderResult(true, response.code(),response.body());
                }else {
                    mView.onDetailOrderResult(false, response.code(), null);
                }
            }

            @Override
            public void onFailure(Call<OrderDetailResponse> call, Throwable t) {
                Log.d("URL ORDER :",call.request().url().toString());
                Log.d("Error :",t.getMessage());
                mView.onDetailOrderResult(false,0,null);
            }
        });
    }

    @Override
    public void doDeclineOrder(String token, String idMeeting) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.declineOrder(token, idMeeting).enqueue(new Callback<OrderResponseModel>() {
            @Override
            public void onResponse(Call<OrderResponseModel> call, Response<OrderResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onDeclineOrderResult(true,response.code());
                }else {
                    mView.onDeclineOrderResult(false, response.code());
                }
            }

            @Override
            public void onFailure(Call<OrderResponseModel> call, Throwable t) {
                Toast.makeText(mContext, "Error " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void initChatRoom(InitChatRoomRequestModel initChatRoomRequestModel) {
        chatInterfaceAPI = ChatAPIUtils.getChatService();
        chatInterfaceAPI.initChatRoom(initChatRoomRequestModel).enqueue(new Callback<InitChatRoomResponseModel>() {
            @Override
            public void onResponse(Call<InitChatRoomResponseModel> call, Response<InitChatRoomResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onInitChatRoom(true,response.code(),response.body());
                }else {
                    mView.onInitChatRoom(false,response.code(),null);
                }
            }

            @Override
            public void onFailure(Call<InitChatRoomResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void getListRoomChat(String idMerchant) {
        chatInterfaceAPI = ChatAPIUtils.getChatService();
        chatInterfaceAPI.getListRoomChat(idMerchant).enqueue(new Callback<GetListRoomChatResponseModel>() {
            @Override
            public void onResponse(Call<GetListRoomChatResponseModel> call, Response<GetListRoomChatResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onGetListRoomChatResult(true,response.code(),response.body());
                }else {
                    mView.onGetListRoomChatResult(false,response.code(),null);
                }
            }

            @Override
            public void onFailure(Call<GetListRoomChatResponseModel> call, Throwable t) {
                mView.onGetListRoomChatResult(false,0,null);
            }
        });
    }

    @Override
    public void dbInsertListRoomChat(GetListRoomChatResponseModel listRoomChat) {
        List<DataItem> RoomChat = listRoomChat.getData();
        for (int i = 0;i<RoomChat.size();i++){
//            this.listRoomChatDao.insertRoomChat(listRoomChat.get(i));
            this.listRoomChatDao.insertRoomChat(RoomChat.get(i));
        }
    }

    @Override
    public void getServiceList(String token) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.getServiceList(token).enqueue(new Callback<ListServiceResponse>() {
            @Override
            public void onResponse(Call<ListServiceResponse> call, Response<ListServiceResponse> response) {
                if(response.isSuccessful()){
                    mView.onGetServiceListResult(true,response.code(),response.body());
                }else {
                    mView.onGetServiceListResult(false,response.code(),null);
                }
            }

            @Override
            public void onFailure(Call<ListServiceResponse> call, Throwable t) {

            }
        });
    }
}
