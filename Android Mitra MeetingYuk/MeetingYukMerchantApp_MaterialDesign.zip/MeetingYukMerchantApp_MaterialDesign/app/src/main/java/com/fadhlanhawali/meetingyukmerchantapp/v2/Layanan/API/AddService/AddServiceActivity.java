package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.AddService;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel.AddServiceRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel.Icon;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel.PhotosItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.EditServiceModel.EditServiceRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.ServiceContract;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Camera.CameraContract;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Camera.CameraPresenter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.FileUpload.UploadFileResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewDialog;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewTools;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class AddServiceActivity extends AppCompatActivity implements ServiceContract.vAddService, CameraContract.View, PopupMenu.OnMenuItemClickListener {

    private ServiceContract.pAddService mPresenter;
    private CameraPresenter cameraPresenter;
    private AddServiceRequestModel addServiceRequestModel;
    SessionManager sessionManager;
    static final int REQUEST_TAKE_PHOTO = 101;
    static final int REQUEST_GALLERY_PHOTO = 102;
    private static final String FLAG_ADD_SERVICE = "ADD_SERVICE";
    private static final String FLAG_EDIT_SERVICE = "EDIT_SERVICE";
    private EditServiceRequestModel editServiceRequestModel;
    private String mode = "";
    private String urlPhoto = "";
    private String idService = "";
    private boolean isPhotoChanged = false;
    String unit ="";
    static String[] permissions = new String[]{
            Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    Uri photoURI;
    ImageView photo, ivNavigateBack, ivMenu;
    Button btnSimpan, btnBatal;
    EditText name, price, description, quantity;
    LinearLayout llQty;
    View vlineQty;
    HashMap<String, String> user;
    Intent i;
    ViewDialog viewDialog;
    TextView tvTitlePrice, tvUnit, tvTitleQty;
    DataItem item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_service);
        i = getIntent();
        mPresenter = new AddServicePresenter(this,this);
        mPresenter.initP();
    }

    @Override
    protected void onStart() {
        super.onStart();
        viewDialog = new ViewDialog(this);
    }

    @Override
    public void initV() {
        photo = findViewById(R.id.photo);
        btnSimpan = findViewById(R.id.btnSimpan);
        name = findViewById(R.id.edittextNamaLayanan);
        price = findViewById(R.id.edittextHarga);
        description = findViewById(R.id.edittextDeskripsi);
        quantity = findViewById(R.id.edittextJumlah);
        ivNavigateBack = findViewById(R.id.ivNavigateBack);
        ivMenu = findViewById(R.id.ivMenu);
        btnBatal = findViewById(R.id.btnBatal);
        tvTitlePrice = findViewById(R.id.tvTitlePrice);
        tvTitleQty = findViewById(R.id.tvTitleQty);
        tvUnit = findViewById(R.id.tvUnit);
        vlineQty = findViewById(R.id.vlineQty);
        llQty = findViewById(R.id.llQty);

        mPresenter = new AddServicePresenter(this,this);
        cameraPresenter = new CameraPresenter(this);
        addServiceRequestModel = new AddServiceRequestModel();
        editServiceRequestModel = new EditServiceRequestModel();
        sessionManager = new SessionManager(getApplicationContext());
        user = sessionManager.getUserDetails();
        photo.setOnClickListener(v -> {
            selectImage();
        });
        if(i.getStringExtra("flag").equals(FLAG_EDIT_SERVICE)){
            mode = FLAG_EDIT_SERVICE;
            ArrayList<DataItem> dataItems = i.getParcelableArrayListExtra("service");
            item = dataItems.get(i.getIntExtra("index",0));
            urlPhoto = item.getPhotos().get(0).getUrl();
            idService = item.getId();
            Glide.with(getApplicationContext()).load(urlPhoto).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(photo);
            name.setText(item.getName());
            price.setText(String.valueOf(item.getPrice()));
            description.setText(item.getDescription());
            quantity.setText(String.valueOf(item.getQuantity()));
            checkType();
        }else if(i.getStringExtra("flag").equals(FLAG_ADD_SERVICE)){
            mode = FLAG_ADD_SERVICE;
            checkType();
        }

        cameraPresenter.setUri("");

        btnSimpan.setOnClickListener(v -> {
            if(validate(new EditText[]{name,price,description,quantity})){
                if(mode.equals(FLAG_ADD_SERVICE)){
                    checkPhotoSource();
                }else if(mode.equals(FLAG_EDIT_SERVICE)){
                    if(isPhotoChanged){
                        checkPhotoSource();
                    }else {
                        viewDialog.showDialog();
                        setServiceData(urlPhoto);
                        mPresenter.doEditService(addServiceRequestModel,user.get(SessionManager.KEY_TOKEN),idService);
                    }
                }
                
            }else {
                Toast.makeText(this, "Data Belum Lengkap !", Toast.LENGTH_SHORT).show();
            }
        });

        ivNavigateBack.setOnClickListener(v -> {
            finish();
        });

        btnBatal.setOnClickListener(v -> {
            finish();
        });

        ivMenu.setOnClickListener(v ->{
            PopupMenu popup = new PopupMenu(AddServiceActivity.this, v);
            popup.setOnMenuItemClickListener(AddServiceActivity.this);
            popup.inflate(R.menu.layanan);
            popup.show();
        });
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.delete_service:
                viewDialog.showDialog();
                mPresenter.doDeleteServiceResult(user.get(SessionManager.KEY_TOKEN),idService);
                return true;
            default:
                return false;
        }
    }

    private void checkPhotoSource(){
        if (!cameraPresenter.getUri().equals("")) {
            String uriPath = cameraPresenter.getUri();
            File mFile = new File(uriPath);
            RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"), mFile);
            MultipartBody.Part body = MultipartBody.Part.createFormData("file",mFile.getName(),requestBody);
            mPresenter.doUploadFile(body);
            viewDialog.showDialog();
        }else if(!photoURI.getPath().equals("")){
            File mFile = new File(getFilePathForN(photoURI,this));
            RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"), mFile);
            MultipartBody.Part body = MultipartBody.Part.createFormData("file",mFile.getName(),requestBody);
            viewDialog.showDialog();
            mPresenter.doUploadFile(body);
        }else {
            Toast.makeText(this, "Data yang anda masukkan belum lengkap !", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onAddServiceResult(Boolean result, int code) {
        if (result){
            viewDialog.hideDialog();
            Toast.makeText(this, "Sukses menambahkan service !", Toast.LENGTH_SHORT).show();
            finish();
        }else {
            viewDialog.hideDialog();
            Toast.makeText(getApplicationContext(),"Error : "+code, Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onEditServiceResult(Boolean result, int code) {
        if (result){
            viewDialog.hideDialog();
            Toast.makeText(this, "Sukses memperbarui service !", Toast.LENGTH_SHORT).show();
            finish();
        }else {
            viewDialog.hideDialog();
            Toast.makeText(getApplicationContext(),"Error : "+code, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDeleteServiceResult(Boolean result, int code) {
        if(result){
            viewDialog.hideDialog();
            Toast.makeText(this, "Sukses menghapus service !", Toast.LENGTH_SHORT).show();
            finish();
        }else {
            viewDialog.hideDialog();
            Toast.makeText(this, "Terjadi sebuah kesalahan dalam menghapus service", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onUploadFileResult(Boolean result, int code, UploadFileResponseModel uploadFileResponseModel) {
        if (result){
//            Toast.makeText(this, "HASIL : " + uploadFileResponseModel.toString(), Toast.LENGTH_SHORT).show();
            Log.d("URL GAMBAR UPLOAD  : ", uploadFileResponseModel.getData().getUrl());
            if(mode.equals(FLAG_ADD_SERVICE)){
                setServiceData("https://"+uploadFileResponseModel.getData().getUrl());
                mPresenter.doAddService(addServiceRequestModel,user.get(SessionManager.KEY_TOKEN));
            }else {
                setServiceData("https://"+uploadFileResponseModel.getData().getUrl());
                mPresenter.doEditService(addServiceRequestModel,user.get(SessionManager.KEY_TOKEN),idService);
            }


//            Toast.makeText(this, "doAddService Jalan", Toast.LENGTH_SHORT).show();
        }else {
//            Toast.makeText(getApplicationContext(), "BODY : " + uploadFileResponseModel.toString() + " " + result, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean checkPermission() {
        for (String mPermission : permissions) {
            int result = ActivityCompat.checkSelfPermission(this, mPermission);
            if (result == PackageManager.PERMISSION_DENIED) return false;
        }
        return true;
    }

    @Override
    public void showPermissionDialog() {
        Dexter.withActivity(this).withPermissions(permissions)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                        }
                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            showSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).withErrorListener(error -> showErrorDialog())
                .onSameThread()
                .check();
    }

    @Override
    public File getFilePath() {
        return getExternalFilesDir(Environment.DIRECTORY_PICTURES);
    }

    @Override
    public void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    @Override
    public void startCamera(File file) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            if (file != null) {
                photoURI = FileProvider.getUriForFile(this,
                        BuildConfig.APPLICATION_ID + ".provider", file);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);

            }
        }
    }

    @Override
    public void chooseGallery() {
        Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickPhoto.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(pickPhoto, REQUEST_GALLERY_PHOTO);
    }

    @Override
    public void showNoSpaceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.error_message_no_more_space));
        builder.setMessage(getString(R.string.error_message_insufficient_space));
        builder.setPositiveButton(getString(R.string.ok), (dialog, which) -> dialog.cancel());
        builder.show();
    }

    @Override
    public int availableDisk() {
        File mFilePath = getFilePath();
        long freeSpace = mFilePath.getFreeSpace();
        return Math.round(freeSpace / 1048576);
    }

    @Override
    public File newFile() {
        Calendar cal = Calendar.getInstance();
        long timeInMillis = cal.getTimeInMillis();
        String mFileName = String.valueOf(timeInMillis) + ".jpeg";
        File mFilePath = getFilePath();
        try {
            File newFile = new File(mFilePath.getAbsolutePath(), mFileName);
            newFile.createNewFile();
            return newFile;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void showErrorDialog() {
        Toast.makeText(getApplicationContext(), getString(R.string.error_message), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void displayImagePreview(String mFilePath) {
        Log.d("mFilePathGlide : ", mFilePath);
        Glide.with(AddServiceActivity.this).load(mFilePath).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(photo);
    }

    @Override
    public void displayImagePreview(Uri mFileUri) {
        Glide.with(AddServiceActivity.this).load(mFileUri).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(photo);
    }

    @Override
    public String getRealPathFromUri(Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Images.Media.DATA};
            cursor = getContentResolver().query(contentUri, proj, null, null, null);
            assert cursor != null;
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(columnIndex);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_TAKE_PHOTO) {
                cameraPresenter.showPreview(photoURI);
                if(mode.equals(FLAG_EDIT_SERVICE)){
                    isPhotoChanged = true;
                }

            } else if (requestCode == REQUEST_GALLERY_PHOTO) {
                Uri selectedImage = data.getData();
                String mPhotoPath = getRealPathFromUri(selectedImage);
                if(mode.equals(FLAG_EDIT_SERVICE)){
                    isPhotoChanged = true;
                }
                Log.d("URI IMAGE :", selectedImage.toString());
                Log.d("mPhotoPath : ", mPhotoPath);

                cameraPresenter.setUri(mPhotoPath);
                cameraPresenter.showPreview(mPhotoPath);
            }
        }
    }

    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.message_need_permission));
        builder.setMessage(getString(R.string.message_grant_permission));
        builder.setPositiveButton(getString(R.string.label_setting), (dialog, which) -> {
            dialog.cancel();
            openSettings();
        });
        builder.setNegativeButton(getString(R.string.cancel), (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void selectImage() {
        final CharSequence[] items = {getString(R.string.take_photo), getString(R.string.choose_gallery),
                getString(R.string.cancel)};
        AlertDialog.Builder builder = new AlertDialog.Builder(AddServiceActivity.this);
        builder.setItems(items, (dialog, item) -> {
            if (items[item].equals("Take Photo")) {
                cameraPresenter.cameraClick();
            } else if (items[item].equals("Choose from Gallery")) {
                cameraPresenter.ChooseGalleryClick();
            } else if (items[item].equals("Cancel")) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private void setServiceData(String url){

        PhotosItem photosItem = new PhotosItem();
        Icon icon = new Icon();
        icon.setId(i.getStringExtra("serviceCategoryId"));
        icon.setUrl(i.getStringExtra("serviceCategoryUrl"));
        photosItem.setUrl(url);
        List<PhotosItem> photosItemList = new ArrayList<>();

        photosItemList.add(photosItem);

        addServiceRequestModel.setName(name.getText().toString());
        addServiceRequestModel.setPrice(Integer.valueOf(price.getText().toString()));
        addServiceRequestModel.setDescription(description.getText().toString());
        addServiceRequestModel.setPhotos(photosItemList);
        addServiceRequestModel.setIcon(icon);
        if(i.getStringExtra("serviceCategoryId").equals("music")){
            addServiceRequestModel.setQuantity(1);
        }else {
            addServiceRequestModel.setQuantity(Integer.valueOf(quantity.getText().toString()));
        }

        addServiceRequestModel.setUnit(unit);


    }

    private void checkType(){
        String category = i.getStringExtra("serviceCategoryId");

        if (category.equals("balroom") || category.equals("conference") || category.equals("room") || category.equals("wedding")){
            tvTitlePrice.setText("Harga (per jam)");
            tvTitleQty.setText("Kapasitas");
            tvUnit.setText("orang");
            unit = "hour";
        }else if(category.equals("food")){
            tvTitlePrice.setText("Harga (dari jumlah porsi yang ditentukan)");
            tvTitleQty.setText("Jumlah Porsi");
            tvUnit.setText("porsi");
            unit = "packet";
        } else if(category.equals("music")){
            tvTitlePrice.setText("Harga (per jam)");
            tvTitleQty.setVisibility(View.GONE);
            vlineQty.setVisibility(View.GONE);
            llQty.setVisibility(View.GONE);
            unit = "hour";
        }
    }

    private static String getFilePathForN(Uri uri, Context context) {
        Uri returnUri = uri;
        Cursor returnCursor = context.getContentResolver().query(returnUri, null, null, null, null);
        /*
         * Get the column indexes of the data in the Cursor,
         *     * move to the first row in the Cursor, get the data,
         *     * and display it.
         * */
        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
        returnCursor.moveToFirst();
        String name = (returnCursor.getString(nameIndex));
        String size = (Long.toString(returnCursor.getLong(sizeIndex)));
        File file = new File(context.getFilesDir(), name);
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            FileOutputStream outputStream = new FileOutputStream(file);
            int read = 0;
            int maxBufferSize = 1 * 1024 * 1024;
            int bytesAvailable = inputStream.available();

            //int bufferSize = 1024;
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);

            final byte[] buffers = new byte[bufferSize];
            while ((read = inputStream.read(buffers)) != -1) {
                outputStream.write(buffers, 0, read);
            }
            Log.e("File Size", "Size " + file.length());
            inputStream.close();
            outputStream.close();
            Log.e("File Path", "Path " + file.getPath());
            Log.e("File Size", "Size " + file.length());
        } catch (Exception e) {
            Log.e("Exception", e.getMessage());
        }
        return file.getPath();
    }

    private boolean validate(EditText[] fields){
        for(int i = 0; i < fields.length; i++){
            EditText currentField = fields[i];
            if(currentField.getText().toString().length() <= 0){
                return false;
            }
        }
        return true;
    }

}

