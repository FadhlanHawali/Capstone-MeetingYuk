package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.Chat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.GetListRoomChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetUnreadChatCount.GetUnreadChatCountResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.AppDatabase;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ListRoomChatDao;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationContract;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class NotificationFragmentChat extends Fragment implements NotificationContract.vChat {

    private NotificationContract.pChat mPresenter;
    private SessionManager sessionManager;
    private HashMap<String,String> user;
    private RecyclerView recyclerView;
    NotificationChatAdapter chatAdapter;
    private List<GetListRoomChatResponseModel> getListRoomChatResponseModels;
    private List<GetUnreadChatCountResponse> unreadChatCount;
    private ListRoomChatDao listRoomChatDao;
    private AppDatabase mdB;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_notification_a, container, false);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);

        mdB = AppDatabase.getDatabase(getActivity().getApplication());
        listRoomChatDao = mdB.listRoomChatDao();

        mPresenter = new NotificationFragmentChatPresenter(getContext(),this,listRoomChatDao);
        sessionManager = new SessionManager(getContext());
        recyclerView = v.findViewById(R.id.recyclerView);

        return v;
    }

    @Override
    public void initV() {
        unreadChatCount = new ArrayList<>();
        getListRoomChatResponseModels = new ArrayList<>();
        user = sessionManager.getUserDetails();
        LocalBroadcastManager.getInstance(getContext()).registerReceiver(mMessageReceiver,
                new IntentFilter("chat"));

        chatAdapter = new NotificationChatAdapter(getContext(),user.get(SessionManager.KEY_IDMERCHANT));
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getContext(), 1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(chatAdapter);

    }

    @Override
    public void onStart() {
        super.onStart();
        mPresenter.checkConnectivity();
    }

    @Override
    public void onGetListRoomChatResult(Boolean result, int code, GetListRoomChatResponseModel getListRoomChatResponseModel) {
        if(result){
            List<DataItem> listRoomChat = getListRoomChatResponseModel.getData();
            Log.d("Respon List Room : ", listRoomChat.toString());
            chatAdapter.setChatRoomList(listRoomChat);
            mPresenter.dbInsertListRoomChat(getListRoomChatResponseModel);
        } else {
            Toast.makeText(getContext(), "Error : " + code, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDBInsertListRoomChatResult() {
        Log.d("Insert List Room DB : ", "success");
    }

    @Override
    public void onDBGetListRoomChatResult(List<DataItem> listRoomChat) {
//        Toast.makeText(getContext(), "SIZE DB LIST ROOMCHAT : " + listRoomChat.size(), Toast.LENGTH_SHORT).show();
        Log.d("Chat Room:",listRoomChat.toString());
//        Toast.makeText(getContext(), "ISI : " + listRoomChat.toString(), Toast.LENGTH_SHORT).show();
        if(listRoomChat.size() == 0){
            Toast.makeText(getContext(), "RUNNING TEROS", Toast.LENGTH_SHORT).show();
            mPresenter.getListRoomChat(user.get(SessionManager.KEY_IDMERCHANT));
        }else {
            chatAdapter.setChatRoomList(listRoomChat);
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mPresenter.initP();
        mPresenter.checkConnectivity();
    }

    @Override
    public void onCheckConnectivity(Boolean isConnected){
        if(!isConnected){
            Snackbar snackbar = Snackbar
                    .make(getView(),"Tidak ada koneksi", Snackbar.LENGTH_LONG);
            snackbar.show();
            mPresenter.dbGetListRoomChat();
        }else {
            mPresenter.getListRoomChat(user.get(SessionManager.KEY_IDMERCHANT));
//            mPresenter.dbGetListRoomChat();
        }
    }

    public BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            mPresenter.getListRoomChat(user.get(SessionManager.KEY_IDMERCHANT));
        }
    };


}

