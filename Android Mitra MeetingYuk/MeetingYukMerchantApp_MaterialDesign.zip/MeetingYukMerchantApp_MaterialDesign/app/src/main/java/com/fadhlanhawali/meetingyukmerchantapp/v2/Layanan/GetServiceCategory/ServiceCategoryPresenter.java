package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.GetServiceCategory;

import android.content.Context;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.IServiceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.CategoryServiceModel.CategoryServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.ServiceContract;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.Utils.ServiceAPIUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ServiceCategoryPresenter implements ServiceContract.pGetServiceCategory {
    private final Context mContext;
    ServiceContract.vGetServiceCategory mView;
    private IServiceAPI serviceAPI;

    public ServiceCategoryPresenter(Context mContext, ServiceContract.vGetServiceCategory mView) {
        this.mContext = mContext;
        this.mView = mView;
    }


    @Override
    public void initP() {

        mView.initV();
    }

    @Override
    public void getServiceCategory(String token) {
        serviceAPI = ServiceAPIUtils.getAPIService();
        serviceAPI.getServiceCategory(token).enqueue(new Callback<CategoryServiceResponseModel>() {
            @Override
            public void onResponse(Call<CategoryServiceResponseModel> call, Response<CategoryServiceResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onResult(true, response.code(), response.body());
                }else {
                    mView.onResult(false, response.code(), response.body());
                }
            }

            @Override
            public void onFailure(Call<CategoryServiceResponseModel> call, Throwable t) {

            }
        });

    }

    @Override
    public void getCountService(String token) {
        serviceAPI = ServiceAPIUtils.getAPIService();
        serviceAPI.getServiceList(token).enqueue(new Callback<ListServiceResponse>() {
            @Override
            public void onResponse(Call<ListServiceResponse> call, Response<ListServiceResponse> response) {
                if (response.isSuccessful()){
                    mView.onResultCount(true, response.code(), response.body().getData().size());
                }else {
                    mView.onResultCount(false, response.code(), 0);
                }
            }

            @Override
            public void onFailure(Call<ListServiceResponse> call, Throwable t) {

            }
        });
    }
}
