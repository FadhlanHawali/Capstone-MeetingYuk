package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterRequestModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class TimeEnd{

	@SerializedName("gte")
	private long gte;

	@SerializedName("lte")
	private long lte;

	public void setGte(long gte){
		this.gte = gte;
	}

	public long getGte(){
		return gte;
	}

	public void setLte(long lte){
		this.lte = lte;
	}

	public long getLte(){
		return lte;
	}

	public TimeEnd(long gte, long lte) {
		this.gte = gte;
		this.lte = lte;
	}

	@Override
 	public String toString(){
		return 
			"TimeEnd{" + 
			"gte = '" + gte + '\'' + 
			",lte = '" + lte + '\'' + 
			"}";
		}
}