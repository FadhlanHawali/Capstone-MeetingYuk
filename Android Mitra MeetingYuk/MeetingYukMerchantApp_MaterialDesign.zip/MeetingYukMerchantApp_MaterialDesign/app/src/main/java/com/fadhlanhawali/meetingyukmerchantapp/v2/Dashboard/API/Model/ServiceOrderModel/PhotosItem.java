package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.ServiceOrderModel;

import com.google.gson.annotations.SerializedName;

public class PhotosItem{

	@SerializedName("_id")
	private String id;

	@SerializedName("url")
	private String url;

	public String getId(){
		return id;
	}

	public String getUrl(){
		return url;
	}
}