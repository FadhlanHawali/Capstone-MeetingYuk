package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.BankAccount;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.AddBankAccountRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.AddBankAccountResponseModel;

public interface BankContract {

    interface vBankAccount{
        void initV();
        void onResultAddBankAccount(Boolean result, int code, AddBankAccountResponseModel addBankAccountResponseModel);
    }

    interface pBankAccount{
        void initP();
        void addBankAccount(String token, AddBankAccountRequestModel addBankAccountRequestModel);
    }
}
