package com.fadhlanhawali.meetingyukmerchantapp.v2.API;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.RetrofitClient;

public class APIUtils {
    public APIUtils() {
    }

    public static InterfaceAPI getAPIService() {
        return RetrofitClient.getClient(BuildConfig.API_BASE_URL).create(InterfaceAPI.class);
    }

}
