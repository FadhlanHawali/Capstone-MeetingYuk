package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.ServiceOrderModel;

import com.google.gson.annotations.SerializedName;

public class Icon{

	@SerializedName("id")
	private String id;

	@SerializedName("url")
	private String url;

	public String getId(){
		return id;
	}

	public String getUrl(){
		return url;
	}
}