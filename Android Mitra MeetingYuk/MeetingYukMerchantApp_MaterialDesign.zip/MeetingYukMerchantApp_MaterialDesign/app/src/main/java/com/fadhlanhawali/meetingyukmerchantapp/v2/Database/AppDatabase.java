package com.fadhlanhawali.meetingyukmerchantapp.v2.Database;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.Converter.TargetProfileConverter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ChatDao;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ListRoomChatDao;

@Database(entities = {DataItem.class, com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem.class}, version = 1, exportSchema = false)
@TypeConverters({TargetProfileConverter.class})
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase INSTANCE;

    public abstract ListRoomChatDao listRoomChatDao();

    public abstract ChatDao chatDao();

    public static AppDatabase getDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, "meetingyukmerchant.db")
                    .allowMainThreadQueries()
                    .addMigrations()
                    .build();
        }
        return INSTANCE;
    }

    public static AppDatabase getMemoryDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.inMemoryDatabaseBuilder(context.getApplicationContext(), AppDatabase.class)
                    .allowMainThreadQueries()
                    .build();
        }
        return INSTANCE;
    }

    public static void destroyInstance() {
        INSTANCE = null;
    }

}
