package com.fadhlanhawali.meetingyukmerchantapp.v2.Report;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements.TopServicesItem;

import java.util.ArrayList;
import java.util.List;

public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.MyViewHolder> {

    private Context mContext;
    private List<TopServicesItem> topServicesItemList;
    public TextView txtOrderCount,tvOrderDescription;
    public ImageView imgIconService;
    public class MyViewHolder extends RecyclerView.ViewHolder {

        public MyViewHolder(final View view) {
            super(view);
            txtOrderCount = view.findViewById(R.id.txtOrderCount);
            tvOrderDescription = view.findViewById(R.id.tvOrderDescription);
            imgIconService = view.findViewById(R.id.imgIconService);
        }

    }

    public ReportAdapter(Context mContext) {
        this.mContext = mContext;
        topServicesItemList = new ArrayList<>();
    }

    public void setTopServicesItemList(List<TopServicesItem> topServicesItemList) {
        this.topServicesItemList = topServicesItemList;
        notifyDataSetChanged();
    }

    @Override
    public ReportAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_financial_statements, parent, false);

        return new ReportAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ReportAdapter.MyViewHolder holder, final int position) {
        txtOrderCount.setText(String.valueOf(topServicesItemList.get(position).getOrderCount()));
        tvOrderDescription.setText("Pesanan Memesan Service "+topServicesItemList.get(position).getService().getName()+" !");
        Glide.with(mContext).load(topServicesItemList.get(position).getService().getPhotos().get(0).getUrl()).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imgIconService);

    }

    @Override
    public int getItemCount() {
        return topServicesItemList.size();
    }

}



