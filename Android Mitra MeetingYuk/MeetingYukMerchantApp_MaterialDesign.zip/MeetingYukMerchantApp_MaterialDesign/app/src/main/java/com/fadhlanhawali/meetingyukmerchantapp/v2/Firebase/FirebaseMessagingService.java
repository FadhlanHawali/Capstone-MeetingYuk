package com.fadhlanhawali.meetingyukmerchantapp.v2.Firebase;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.bumptech.glide.Glide;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.APIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.InterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.ChatActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.GetChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;
import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {

    InterfaceAPI interfaceAPI;
    HashMap<String,String> user;
//    SessionManager sessionManager = new SessionManager(getApplicationContext());
    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onNewToken(String token) {
        sendToken(token);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Map<String,String > data = remoteMessage.getData();
        Log.d("REMOTE MESSAGE : ", remoteMessage.toString());
//        Toast.makeText(this, "MASHOKKK", Toast.LENGTH_SHORT).show();
        if(data.get("event").equals("chat")){
            if(remoteMessage.getNotification() != null){
                sendNotification(remoteMessage.getNotification(), remoteMessage.getData());
            }
        }
    }

    private void sendNotification(RemoteMessage.Notification notification, Map<String, String> data) {
        Bitmap icon = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
        Gson gson = new Gson();
        DataItem chat = gson.fromJson(data.get("data"), DataItem.class);
        List<DataItem> listChat = new ArrayList<>();
        listChat.add(chat);
        Intent intent = new Intent("chat");
        intent.putExtra("chat_data", (Serializable) listChat);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
//        Log.d("REMOTE MESSAGE : ", chat.toString());
//        Intent intent = new Intent(this, ChatActivity.class);
//        intent.putExtra("idRoom",chat.getId());
//        intent.putExtra("idUser", chat.getFromUserId());
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
//
//        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, "channel_id")
//                .setContentTitle(notification.getTitle())
//                .setContentText(notification.getBody())
//                .setAutoCancel(true)
//                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
//                .setContentIntent(pendingIntent)
//                .setContentInfo(notification.getTitle())
//                .setLargeIcon(icon)
//                .setColor(Color.RED)
//                .setLights(Color.RED, 1000, 300)
//                .setDefaults(Notification.DEFAULT_VIBRATE)
//                .setSmallIcon(R.mipmap.ic_launcher);
//
//        try {
//            String picture_url = chat.getFromUserAvatarUrl();
//            if (picture_url != null && !"".equals(picture_url)) {
//                URL url = new URL(picture_url);
//                Bitmap bigPicture = BitmapFactory.decodeStream(url.openConnection().getInputStream());
//                notificationBuilder.setStyle(
//                        new NotificationCompat.BigPictureStyle().bigPicture(bigPicture).setSummaryText(notification.getBody())
//                );
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//
//         Notification Channel is required for Android O and above
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            NotificationChannel channel = new NotificationChannel(
//                    "channel_id", "channel_name", NotificationManager.IMPORTANCE_DEFAULT
//            );
//            channel.setDescription("channel description");
//            channel.setShowBadge(true);
//            channel.canShowBadge();
//            channel.enableLights(true);
//            channel.setLightColor(Color.RED);
//            channel.enableVibration(true);
//            channel.setVibrationPattern(new long[]{100, 200, 300, 400, 500});
//            notificationManager.createNotificationChannel(channel);
//        }
//
//        if (notificationManager != null) {
//            notificationManager.notify(0, notificationBuilder.build());
//        }

    }

    private void sendToken(String firebaseToken){
//        user = sessionManager.getUserDetails();
//        interfaceAPI = APIUtils.getAPIService();
//        interfaceAPI.pushToken(user.get(SessionManager.KEY_TOKEN), firebaseToken).enqueue(new Callback<GeneralResponseModel>() {
//            @Override
//            public void onResponse(Call<GeneralResponseModel> call, Response<GeneralResponseModel> response) {
//                if (response.isSuccessful()){
//                    Log.d("PUSH TOKEN STATUS : ", "Succes");
//                }
//            }
//
//            @Override
//            public void onFailure(Call<GeneralResponseModel> call, Throwable t) {
//
//            }
//        });
    }
}
