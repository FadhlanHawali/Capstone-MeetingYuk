package com.fadhlanhawali.meetingyukmerchantapp.v2.API;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.GetListRoomChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.GetChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat.SendChatRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat.SendChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ChatInterfaceAPI {

    @POST(BuildConfig.INIT_CHAT_ROOM)
    Call<InitChatRoomResponseModel> initChatRoom (@Body InitChatRoomRequestModel initChatRoomRequestModel);

    @GET(BuildConfig.GET_LIST_ROOM_CHAT)
    Call<GetListRoomChatResponseModel> getListRoomChat (@Query("idUser") String idUser);

    @GET(BuildConfig.GET_CHAT_LATEST)
    Call<GetChatResponseModel> getChatLatest (@Query("idRoom") String idRoom, @Query("idUser") String idUser);

    @GET(BuildConfig.GET_CHAT_BEFORE)
    Call<GetChatResponseModel> getChatBeforeTimestamp (@Query("timestamp") String timestamp, @Query("idRoom") String idRoom);

    @POST(BuildConfig.SEND_CHAT)
    Call<SendChatResponseModel> sendChat (@Body SendChatRequestModel sendChatRequestModel);

    @GET(BuildConfig.READ_CHAT)
    Call<GeneralResponseModel> readChat (@Query("idMessage") String idMessage, @Query("idUser") String idUser);
}
