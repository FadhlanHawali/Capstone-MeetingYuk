package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements.Data;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.GetAdmin.DataItem;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class SettingAdapter extends RecyclerView.Adapter<SettingAdapter.MyViewHolder> {

    private Context mContext;
    private List<DataItem> adminList = new ArrayList<>();
    private int flagEdit = 0;
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtEmail;

        public MyViewHolder(final View view) {
            super(view);
            txtEmail = view.findViewById(R.id.txtEmail);

        }

    }

    public SettingAdapter(Context mContext) {
        this.mContext = mContext;
    }

    @Override
    public SettingAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_setting_admin, parent, false);

        return new SettingAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final SettingAdapter.MyViewHolder holder, final int position) {
        DataItem admin = adminList.get(position);
        holder.txtEmail.setText(adminList.get(position).getEmail());
        if(flagEdit == 1 ){
            holder.itemView.setOnClickListener(v -> {
                if (admin.getFlagDelete() == 0){
                    holder.itemView.setBackgroundResource(R.drawable.fasilitas_background);
                    admin.setFlagDelete(1);
                } else if (admin.getFlagDelete() == 1){
                    holder.itemView.setBackgroundColor(Color.TRANSPARENT);
                    admin.setFlagDelete(0);
                }
            });
        }else if (flagEdit == 0){
            holder.itemView.setBackgroundColor(Color.TRANSPARENT);
            admin.setFlagDelete(0);
        }
    }

    public List<DataItem> getDeleteAdmin (){
        List<DataItem> admins = new ArrayList<>();
        for (int i = 0; i<adminList.size();i++){
            if(adminList.get(i).getFlagDelete() == 1){
                admins.add(adminList.get(i));
            }
        }
        return admins;
    }

    public void setAdminList(List<DataItem> adminList) {
        this.adminList = adminList;
        notifyDataSetChanged();
    }

    public void setFlagEdit(int flagEdit){
        this.flagEdit = flagEdit;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return adminList.size();
    }
}
