package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import javax.annotation.Generated;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.Converter.TargetProfileConverter;
import com.google.gson.annotations.SerializedName;

@Entity(tableName = "list_room_chat")
@Generated("com.robohorse.robopojogenerator")
public class DataItem{

	@SerializedName("target_profile")
	@TypeConverters(TargetProfileConverter.class)
	private TargetProfile targetProfile;

	@SerializedName("lastMessageTimestamp")
	private long lastMessageTimestamp;

	@SerializedName("member")
	private String member;

	@SerializedName("lastMessageText")
	private String lastMessageText;

	@SerializedName("_id")
	@PrimaryKey @NonNull
	private String id;

	@SerializedName("lastMessageId")
	private String lastMessageId;

	@SerializedName("roomType")
	private String roomType;

	@SerializedName("unread_message")
	private int unreadMessage;

	public DataItem(TargetProfile targetProfile, long lastMessageTimestamp, String member, String lastMessageText, @NonNull String id, String lastMessageId, String roomType, int unreadMessage) {
		this.targetProfile = targetProfile;
		this.lastMessageTimestamp = lastMessageTimestamp;
		this.member = member;
		this.lastMessageText = lastMessageText;
		this.id = id;
		this.lastMessageId = lastMessageId;
		this.roomType = roomType;
		this.unreadMessage = unreadMessage;
	}

	@Ignore
	public DataItem() {

	}

	public void setTargetProfile(TargetProfile targetProfile){
		this.targetProfile = targetProfile;
	}

	public TargetProfile getTargetProfile(){
		return targetProfile;
	}

	public void setLastMessageTimestamp(long lastMessageTimestamp){
		this.lastMessageTimestamp = lastMessageTimestamp;
	}

	public long getLastMessageTimestamp(){
		return lastMessageTimestamp;
	}

	public void setMember(String member){
		this.member = member;
	}

	public String getMember(){
		return member;
	}

	public void setLastMessageText(String lastMessageText){
		this.lastMessageText = lastMessageText;
	}

	public String getLastMessageText(){
		return lastMessageText;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setLastMessageId(String lastMessageId){
		this.lastMessageId = lastMessageId;
	}

	public String getLastMessageId(){
		return lastMessageId;
	}

	public void setRoomType(String roomType){
		this.roomType = roomType;
	}

	public String getRoomType(){
		return roomType;
	}

	public int getUnreadMessage() {
		return unreadMessage;
	}

	public void setUnreadMessage(int unreadMessage) {
		this.unreadMessage = unreadMessage;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"target_profile = '" + targetProfile + '\'' + 
			",lastMessageTimestamp = '" + lastMessageTimestamp + '\'' + 
			",member = '" + member + '\'' + 
			",lastMessageText = '" + lastMessageText + '\'' + 
			",_id = '" + id + '\'' + 
			",lastMessageId = '" + lastMessageId + '\'' + 
			",roomType = '" + roomType + '\'' + 
			"}";
		}
}