package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class SendChatResponseModel {

	@SerializedName("succes")
	private boolean succes;

	public void setSucces(boolean succes){
		this.succes = succes;
	}

	public boolean isSucces(){
		return succes;
	}

	@Override
 	public String toString(){
		return 
			"SendChatResponseModel{" +
			"succes = '" + succes + '\'' + 
			"}";
		}
}