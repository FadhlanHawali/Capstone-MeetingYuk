package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel;

public class AddServiceResponseModel{
	private Object data;
	private boolean success;

	public void setData(Object data){
		this.data = data;
	}

	public Object getData(){
		return data;
	}

	public void setSuccess(boolean success){
		this.success = success;
	}

	public boolean isSuccess(){
		return success;
	}

	@Override
 	public String toString(){
		return 
			"AddServiceResponseModel{" + 
			"data = '" + data + '\'' + 
			",success = '" + success + '\'' + 
			"}";
		}
}
