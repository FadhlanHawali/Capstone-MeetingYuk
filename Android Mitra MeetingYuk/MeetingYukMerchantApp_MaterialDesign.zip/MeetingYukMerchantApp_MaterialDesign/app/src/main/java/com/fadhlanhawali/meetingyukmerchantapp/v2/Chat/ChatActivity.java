package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.RecyclerView;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.GetChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat.SendChatRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat.SendChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.AppDatabase;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ChatDao;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class ChatActivity extends AppCompatActivity implements ChatContract.vChat{

    private static final String CHAT_MODE_PRIVATE = "private";
    private static final String CHAT_TYPE_TEXT = "text";

    ChatContract.pChat mPresenter;
    RecyclerView recyclerView;
    EditText etChatBox;
    Button btnChatBoxSend;
    ChatAdapterv2 chatAdapter;
    SessionManager sessionManager;
    HashMap<String,String> user;
    TextView tvSenderName;
    Intent i;
    RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 1);

    CardView cvLoadMoreMessage;
    RecyclerView.SmoothScroller smoothScroller;
    AppDatabase mDb;
    ChatDao chatDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatv2);
        mDb = AppDatabase.getDatabase(this);
        chatDao = mDb.chatDao();
        mPresenter = new ChatPresenter(this,this, chatDao);
        mPresenter.initP();
    }

    @Override
    public void initV() {
        i = getIntent();
        sessionManager = new SessionManager(this);
        user = sessionManager.getUserDetails();
        recyclerView = findViewById(R.id.recyclerView);
        tvSenderName = findViewById(R.id.tvSenderName);
        etChatBox = findViewById(R.id.etChatBox);
        btnChatBoxSend = findViewById(R.id.btnChatBoxSend);
        cvLoadMoreMessage = findViewById(R.id.cvLoadMoreMessage);

        chatAdapter = new ChatAdapterv2(this, user.get(SessionManager.KEY_IDMERCHANT));
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(chatAdapter);

        tvSenderName.setText(i.getStringExtra("senderName"));
        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver,
                new IntentFilter("chat"));

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            int i = 0;
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                if (!recyclerView.canScrollVertically(-1) && newState ==recyclerView.SCROLL_STATE_IDLE && chatAdapter.getItemCount()!=0) {
                    Log.d("Count : " , String.valueOf(i));
                    i++;
//                    Toast.makeText(ChatActivity.this, "Last", Toast.LENGTH_LONG).show();
                    String timestamp = String.valueOf(chatAdapter.getmMessageList().get(0).getTimestamp());
                    String idRoom = chatAdapter.getmMessageList().get(0).getIdRoom();
                    Log.d("SUSPECT 1",timestamp);
                    mPresenter.getChatBefore(timestamp,idRoom);
                }
            }

        });

        btnChatBoxSend.setOnClickListener(view -> {
            SendChatRequestModel sendChatRequestModel = new SendChatRequestModel(
                    CHAT_MODE_PRIVATE,
                    i.getStringExtra("idRoom"),
                    user.get(SessionManager.KEY_IDMERCHANT),
                    "none",
                    "",
                    false,
                    etChatBox.getText().toString(),
                    CHAT_TYPE_TEXT,
                    ""
            );
            mPresenter.sendChat(sendChatRequestModel);
            mPresenter.dbInsertChat(sendChatRequestModel);

        });

        smoothScroller = new LinearSmoothScroller(this) {
            @Override protected int getVerticalSnapPreference() {
                return LinearSmoothScroller.SNAP_TO_START;
            }
        };

//        mPresenter.getChatBefore(String.valueOf(System.currentTimeMillis()),i.getStringExtra("idRoom"));

        mPresenter.checkConnectivity();

    }

    @Override
    public void onInitChatRoom(Boolean result, int code, InitChatRoomResponseModel initChatRoomResponseModel) {
        if(result){
            Log.d("Init Chat Room : ","Success");
        }
    }

    @Override
    public void onGetChatLatest(Boolean result, int code, GetChatResponseModel getChatResponseModel) {
        Collections.reverse(getChatResponseModel.getData());
        chatAdapter.setmMessageList(getChatResponseModel.getData());
        readChat(chatAdapter.getmMessageList());
    }


    @Override
    public void onSendChatResponse(Boolean result, int code, SendChatResponseModel sendChatResponseModel) {
        if(result){
            etChatBox.getText().clear();
        }
    }

    @Override
    public void onGetChatBefore(Boolean result, int code, GetChatResponseModel getChatResponseModel) {
//        Toast.makeText(this, "Get Chat Before jalan : " + result, Toast.LENGTH_SHORT).show();
//        Toast.makeText(this, "Current time milis : " + System.currentTimeMillis(), Toast.LENGTH_SHORT).show();

        if (result){
            if(getChatResponseModel.getData().size()>0){
//                Toast.makeText(this, "MASOK SINI BOS :" + getChatResponseModel.getData().size(), Toast.LENGTH_SHORT).show();
                cvLoadMoreMessage.setVisibility(View.VISIBLE);
                cvLoadMoreMessage.setOnClickListener(view -> {
                    for(int i = 0; i<getChatResponseModel.getData().size();i++){
                        chatAdapter.getmMessageList().add(0,getChatResponseModel.getData().get(i));
                        chatAdapter.notifyItemInserted(0);
                    }
                    mPresenter.dbInsertChatAll(getChatResponseModel);
                    recyclerView.scrollToPosition(getChatResponseModel.getData().size()-1);
                    Parcelable recyclerViewState = mLayoutManager.onSaveInstanceState();
                    mLayoutManager.onRestoreInstanceState(recyclerViewState);
                    cvLoadMoreMessage.setVisibility(View.GONE);
                });
            }

        }

    }

    @Override
    public void onReadChatResponse(Boolean result, int code, GeneralResponseModel generalResponseModel) {

    }

    public BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            List<DataItem> chat = intent.getParcelableArrayListExtra("chat_data");
            mPresenter.dbInsertChatAll(new GetChatResponseModel(chat,true));
            chatAdapter.getmMessageList().add(chatAdapter.getItemCount(),chat.get(0));
            chatAdapter.notifyItemInserted(chatAdapter.getItemCount());
            recyclerView.scrollToPosition(chatAdapter.getItemCount()-1);
        }
    };

    void readChat(List<DataItem> chatList){
        for(int i = 0; i < chatList.size();i++){
            if(!chatList.get(i).getFromUserId().equals(user.get(SessionManager.KEY_IDMERCHANT)) && !chatList.get(i).getReadBy().contains(user.get(SessionManager.KEY_IDMERCHANT))){
                mPresenter.readChat(
                        chatList.get(i).getId(),
                        user.get(SessionManager.KEY_IDMERCHANT)
                );
            }
        }
    }

    @Override
    public void onDBGetChat(List<DataItem> listChatResponse) {
        String timestamp;
        String idRoom;

//        Toast.makeText(this, "LIST CHAT : " + listChatResponse.toString(), Toast.LENGTH_SHORT).show();
        if(listChatResponse.size() == 0){
            timestamp = String.valueOf(System.currentTimeMillis());
            idRoom = i.getStringExtra("idRoom");
        }else {
            chatAdapter.setmMessageList(listChatResponse);
            timestamp = String.valueOf(chatAdapter.getmMessageList().get(0).getTimestamp());
            idRoom = chatAdapter.getmMessageList().get(0).getIdRoom();

        }
        Log.d("GET CHAT BEFORE : ",timestamp);
        mPresenter.getChatBefore(timestamp,idRoom);
        recyclerView.scrollToPosition(chatAdapter.getItemCount()-1);
    }

    @Override
    public void onCheckConnectivity(Boolean isConnected) {
        if(!isConnected){
            Snackbar snackbar = Snackbar
                    .make(findViewById(android.R.id.content),"Tidak ada koneksi", Snackbar.LENGTH_LONG);
            snackbar.show();
            mPresenter.dbGetChat(i.getStringExtra("idRoom"));
        }else {
//            mPresenter.dbDeleteChatAll();
            mPresenter.initChatRoom(new InitChatRoomRequestModel(
                    user.get(SessionManager.KEY_IDMERCHANT),
                    i.getStringExtra("toUserId")

            ));
            mPresenter.dbGetChat(i.getStringExtra("idRoom"));

//            Log.d("To User Id : ", i.getStringExtra("toUserId"));
//            mPresenter.getChatLatest(i.getStringExtra("idRoom"),user.get(SessionManager.KEY_IDMERCHANT));
        }
    }


}
