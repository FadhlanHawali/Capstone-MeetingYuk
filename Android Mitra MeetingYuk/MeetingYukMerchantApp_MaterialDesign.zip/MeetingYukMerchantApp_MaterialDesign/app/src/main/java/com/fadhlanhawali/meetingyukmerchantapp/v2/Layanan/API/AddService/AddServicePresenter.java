package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.AddService;

import android.content.Context;
import android.util.Log;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel.AddServiceRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel.AddServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.IServiceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.EditServiceModel.EditServiceRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.EditServiceModel.EditServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.ServiceContract;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.Utils.ServiceAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.FileUpload.UploadFileResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddServicePresenter implements ServiceContract.pAddService {

    private final Context mContext;
    ServiceContract.vAddService mView;
    private IServiceAPI serviceAPI;

    public AddServicePresenter(Context mContext, ServiceContract.vAddService mView) {
        this.mContext = mContext;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void doAddService(AddServiceRequestModel addServiceRequestModel, String token) {
        serviceAPI = ServiceAPIUtils.getAPIService();
        serviceAPI.addService(token,addServiceRequestModel).enqueue(new Callback<AddServiceResponseModel>() {
            @Override
            public void onResponse(Call<AddServiceResponseModel> call, Response<AddServiceResponseModel> response) {
                if (response.isSuccessful()) {
                    mView.onAddServiceResult(true,response.code());
                }else {
                    mView.onAddServiceResult(false,response.code());
                }
            }

            @Override
            public void onFailure(Call<AddServiceResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void doUploadFile(MultipartBody.Part uriString) {
        serviceAPI = ServiceAPIUtils.getAPIService();
        serviceAPI.uploadFileService(uriString).enqueue(new Callback<UploadFileResponseModel>() {
            @Override
            public void onResponse(Call<UploadFileResponseModel> call, Response<UploadFileResponseModel> response) {
                if (response.isSuccessful()) {
                    mView.onUploadFileResult(true, response.code(), response.body());
                } else {
                    mView.onUploadFileResult(false, response.code(), response.body());
                }
            }

            @Override
            public void onFailure(Call<UploadFileResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void doEditService(AddServiceRequestModel addServiceRequestModel, String token, String idService) {
        serviceAPI = ServiceAPIUtils.getAPIService();
        serviceAPI.editService(token, addServiceRequestModel, idService).enqueue(new Callback<EditServiceResponseModel>() {
            @Override
            public void onResponse(Call<EditServiceResponseModel> call, Response<EditServiceResponseModel> response) {
                Log.d("EDIT BODY : ", addServiceRequestModel.toString());
                Log.d("EDIT URL : ",call.request().url().toString());
                Log.d("BODY : ",response.message());
                if (response.isSuccessful()) {
                    mView.onEditServiceResult(true,response.code());
                }else {
                    mView.onEditServiceResult(false,response.code());
                }
            }

            @Override
            public void onFailure(Call<EditServiceResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void doDeleteServiceResult(String token, String idService) {
        serviceAPI = ServiceAPIUtils.getAPIService();
        serviceAPI.deleteService(token, idService).enqueue(new Callback<GeneralResponseModel>() {
            @Override
            public void onResponse(Call<GeneralResponseModel> call, Response<GeneralResponseModel> response) {
                Log.d("EDIT URL : ",call.request().url().toString());
                if(response.isSuccessful()){
                    mView.onDeleteServiceResult(true, response.code());
                }else {
                    mView.onDeleteServiceResult(false,response.code());
                }
            }

            @Override
            public void onFailure(Call<GeneralResponseModel> call, Throwable t) {
                Log.d("EDIT URL : ",call.request().url().toString());
                mView.onDeleteServiceResult(false,0);
            }
        });
    }
}
