package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class InitChatRoomRequestModel{

	@SerializedName("fromUserid")
	private String fromUserid;

	@SerializedName("toUserId")
	private String toUserId;

	public InitChatRoomRequestModel(String fromUserid, String toUserId) {
		this.fromUserid = fromUserid;
		this.toUserId = toUserId;
	}

	public void setFromUserid(String fromUserid){
		this.fromUserid = fromUserid;
	}

	public String getFromUserid(){
		return fromUserid;
	}

	public void setToUserId(String toUserId){
		this.toUserId = toUserId;
	}

	public String getToUserId(){
		return toUserId;
	}

	@Override
 	public String toString(){
		return 
			"InitChatRoomRequestModel{" + 
			"fromUserid = '" + fromUserid + '\'' + 
			",toUserId = '" + toUserId + '\'' + 
			"}";
		}
}