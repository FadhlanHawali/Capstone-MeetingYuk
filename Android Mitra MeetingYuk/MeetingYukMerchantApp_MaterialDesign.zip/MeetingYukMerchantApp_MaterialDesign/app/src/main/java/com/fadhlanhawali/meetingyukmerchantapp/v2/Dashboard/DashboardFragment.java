package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard;

import android.graphics.Color;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ConvertDate;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterRequestModel.OrderFilterRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterRequestModel.TimeEnd;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterRequestModel.TimeStart;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterResponseModel.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterResponseModel.OrderFilterResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewTools;
import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.github.sundeepk.compactcalendarview.domain.Event;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


public class DashboardFragment extends Fragment  implements DashboardContract.vOrderAccepted{

    private String TAG = DashboardFragment.class.getSimpleName();
    private DashboardAdapter dashboardAdapter;
    private RecyclerView recyclerView;
    private ConvertDate convertDate;
    FirebaseInstanceId id;
    private TextView txtAlamat,txtNamaResto, txtKosong,txtDateMonth;
    private ImageView ivProfilePicture;
    private HashMap<String,String> user;
    private OrderFilterRequestModel orderFilterRequestModel;
    Event orderAll;
    private CompactCalendarView compactCalendarView;
    private List<Event> events;
    ArrayList<DataItem> dataItemList = new ArrayList<>();
    private Event event;
    private SessionManager sessionManager;
    private DashboardContract.pOrderAccepted mPresenter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_dashboardv2, container, false);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        recyclerView = v.findViewById(R.id.requestRuanganView);
        txtAlamat = v.findViewById(R.id.txtAlamat);
        txtNamaResto = v.findViewById(R.id.txtNamaResto);
        txtKosong = v.findViewById(R.id.txtDataKosong);
        ivProfilePicture = v.findViewById(R.id.ivProfilePicture);
        txtDateMonth = v.findViewById(R.id.txtDateMonth);
        compactCalendarView = v.findViewById(R.id.compactcalendar_view);
        convertDate = new ConvertDate();
        mPresenter = new DashboardPresenter(getContext(),this);
        sessionManager = new SessionManager(getContext());
        user = sessionManager.getUserDetails();

//        getActivity().getWindow().setStatusBarColor(getResources().getColor(R.color.dashboard));
        initToolbar();
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Log.w(TAG, "getInstanceId failed", task.getException());
                        return;
                    }
                    mPresenter.sendToken(user.get(SessionManager.KEY_TOKEN), task.getResult().getToken());
                    // Get new Instance ID token
                    String token = task.getResult().getToken();
//                    System.out.println("TOKEN : " + token);
                });
        mPresenter.initP();

        return v;
    }

    private void initToolbar() {
        ViewTools.setSystemBarColor(getActivity(), android.R.color.white);
        ViewTools.setSystemBarLight(getActivity());
    }


    @Override
    public void initV() {
        dashboardAdapter = new DashboardAdapter(getContext());
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getContext(),1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(dashboardAdapter);

        Glide.with(this)
                .load(sessionManager.getUserDetails().get(SessionManager.KEY_URLFOTO))
                .apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera))
                .into(ivProfilePicture);

        txtNamaResto.setText(user.get(SessionManager.KEY_NAMATEMPAT));
        txtAlamat.setText(user.get(SessionManager.KEY_ALAMAT));
        txtDateMonth.setText(convertDate.convertBulanComplete(compactCalendarView.getFirstDayOfCurrentMonth().getTime()));
        orderFilterRequestModel = new OrderFilterRequestModel(
                new TimeEnd(0,0),
                new TimeStart(0,0),
                "",
                "",
                "");
        mPresenter.getOrderFilter(user.get(SessionManager.KEY_TOKEN),orderFilterRequestModel);
        compactCalendarView.setListener(new CompactCalendarView.CompactCalendarViewListener() {
            @Override
            public void onDayClick(Date dateClicked) {

                events = compactCalendarView.getEvents(dateClicked.getTime());
                DataItem order;

                List<DataItem> orderList = new ArrayList<>();
                for(int i = 0;i<events.size();i++){
                    order = (DataItem) events.get(i).getData();
                    orderList.add(order);
                }

                if(orderList.size() == 0){
                    txtKosong.setVisibility(View.VISIBLE);
                }else {
                    txtKosong.setVisibility(View.GONE);
                }
                Log.d("ORDER LIST ",orderList.toString());

                dashboardAdapter.setOrderList(orderList);

            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
                txtDateMonth.setText(convertDate.convertBulanComplete(firstDayOfNewMonth.getTime()));

            }
        });
    }

    @Override
    public void onOrderFilter(Boolean result, int code, OrderFilterResponseModel orderFilterResponseModel) {
        if(result){

            DataItem order;
            List<DataItem> orderList = new ArrayList<>();

            for(int i = 0;i<orderFilterResponseModel.getData().size();i++){
                event = new Event(Color.GRAY,orderFilterResponseModel.getData().get(i).getTimeStart(),orderFilterResponseModel.getData().get(i));
                compactCalendarView.addEvent(event);
            }

            events = compactCalendarView.getEvents(System.currentTimeMillis());
//            Toast.makeText(getContext(), "SIZE : " + events, Toast.LENGTH_SHORT).show();
            for(int i = 0;i<events.size();i++) {
                order = (DataItem) events.get(i).getData();
                orderList.add(order);
            }

            if(orderList.size() == 0){
                txtKosong.setVisibility(View.VISIBLE);
            }else {
                txtKosong.setVisibility(View.GONE);
            }
            dashboardAdapter.setOrderList(orderList);



        }
    }

    @Override
    public void onSendToken(Boolean result, int code, String URL) {
        if (result){
            Log.d("Firebase Token : ", "success");
        }else {
            Log.d("Firebase Token : ",  URL);
        }
    }
}
