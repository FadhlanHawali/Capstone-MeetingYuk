package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.History;

import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.BankAccount.BankPresenter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoHistoryResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Withdraw.BankAccountAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class HistoryActivity extends AppCompatActivity implements HistoryContract.vHistoryWithdraw{

    SessionManager sessionManager;
    HistoryPresenter mPresenter;
    HashMap<String, String> user;
    Button btnSimpan;
    RecyclerView recyclerView;
    private ArrayList<DataItem> historyWithdrawList = new ArrayList<>();
    HistoryAdapter historyAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_history);
        mPresenter = new HistoryPresenter(this,this);
        mPresenter.initP();
    }

    @Override
    public void initV() {
        recyclerView = findViewById(R.id.recyclerView);
        sessionManager = new SessionManager(this);
        user = sessionManager.getUserDetails();
        mPresenter.getWithdrawHistory(user.get(SessionManager.KEY_TOKEN));
    }

    @Override
    public void onWithdrawHistoryResult(Boolean result, int code, WithdrawSaldoHistoryResponseModel withdrawSaldoHistoryResponseModel) {
        if (result){
            historyWithdrawList.addAll(withdrawSaldoHistoryResponseModel.getData());
            historyAdapter = new HistoryAdapter(this, historyWithdrawList);
            RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 1);
            recyclerView.setLayoutManager(mLayoutManager);
            recyclerView.setItemAnimator(new DefaultItemAnimator());
            recyclerView.setAdapter(historyAdapter);
        }
    }
}
