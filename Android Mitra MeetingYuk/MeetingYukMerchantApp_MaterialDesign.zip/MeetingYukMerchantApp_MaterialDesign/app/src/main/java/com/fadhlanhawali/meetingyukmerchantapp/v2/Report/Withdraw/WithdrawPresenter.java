package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Withdraw;

import android.content.Context;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.IReportAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Utils.ReportAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.GetBankAccountResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoResponseModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WithdrawPresenter implements WithdrawContract.pWithdraw {

    private final Context mContext;
    private WithdrawContract.vWtihdraw mView;
    private IReportAPI reportAPI;

    public WithdrawPresenter(Context context, WithdrawContract.vWtihdraw mView) {
        this.mContext = context;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void doWithdraw(String token, WithdrawSaldoRequestModel withdrawSaldoRequestModel) {
        reportAPI = ReportAPIUtils.getAPIService();
        reportAPI.withdrawSaldoMitra(token, withdrawSaldoRequestModel).enqueue(new Callback<WithdrawSaldoResponseModel>() {
            @Override
            public void onResponse(Call<WithdrawSaldoResponseModel> call, Response<WithdrawSaldoResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onWithdrawResult(true, response.code(),response.body());
                } else {
                    mView.onWithdrawResult(false, response.code(), response.body());
                }
            }
            @Override
            public void onFailure(Call<WithdrawSaldoResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void getBankAccountList(String token) {
        reportAPI = ReportAPIUtils.getAPIService();
        reportAPI.getBankAccount(token).enqueue(new Callback<GetBankAccountResponseModel>() {
            @Override
            public void onResponse(Call<GetBankAccountResponseModel> call, Response<GetBankAccountResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onBankAccountListResult(true, response.code(), response.body());
                }else {
                    mView.onBankAccountListResult(false, response.code(), response.body());
                }
            }

            @Override
            public void onFailure(Call<GetBankAccountResponseModel> call, Throwable t) {

            }
        });
    }
}
