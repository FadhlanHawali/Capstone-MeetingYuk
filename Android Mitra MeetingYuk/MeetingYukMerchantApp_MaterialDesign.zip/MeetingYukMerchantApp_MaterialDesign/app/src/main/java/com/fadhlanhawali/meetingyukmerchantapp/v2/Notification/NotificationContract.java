package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification;

import com.fadhlanhawali.meetingyukmerchantapp.v2.BasePresenter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.BaseView;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.GetListRoomChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetUnreadChatCount.GetUnreadChatCountResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderResponseModel;

import java.util.List;

public interface NotificationContract {
    interface vNotification{
        void initV();
        void onResult(Boolean result, int code, OrderResponseModel orderResponseModel);

    }

    interface pNotification{
        void initP();
        void getWaitingOrder(String token);
    }

    interface vChat extends BaseView {
        void initV();

        void onGetListRoomChatResult(Boolean result, int code, GetListRoomChatResponseModel getListRoomChatResponseModel);

        void onDBInsertListRoomChatResult();

        void onDBGetListRoomChatResult(List<DataItem> listRoomChat);


    }

    interface pChat extends BasePresenter {
        void initP();

        void getListRoomChat(String idMerchant);

        void dbGetListRoomChat();

        void dbInsertListRoomChat(GetListRoomChatResponseModel listRoomChat);
    }
}
