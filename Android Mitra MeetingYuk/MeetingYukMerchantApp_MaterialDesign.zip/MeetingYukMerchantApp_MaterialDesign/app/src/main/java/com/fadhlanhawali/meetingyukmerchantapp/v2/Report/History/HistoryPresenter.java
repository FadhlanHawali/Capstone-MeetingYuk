package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.History;

import android.content.Context;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.IReportAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoHistoryResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Utils.ReportAPIUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HistoryPresenter implements HistoryContract.pHistoryWithdraw{

    private final Context mContext;
    private HistoryContract.vHistoryWithdraw mView;
    private IReportAPI reportAPI;

    public HistoryPresenter(Context mContext, HistoryContract.vHistoryWithdraw mView) {
        this.mContext = mContext;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void getWithdrawHistory(String token) {
        reportAPI = ReportAPIUtils.getAPIService();
        reportAPI.getWithdrawSaldoHistoryMitra(token).enqueue(new Callback<WithdrawSaldoHistoryResponseModel>() {
            @Override
            public void onResponse(Call<WithdrawSaldoHistoryResponseModel> call, Response<WithdrawSaldoHistoryResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onWithdrawHistoryResult(true,response.code(),response.body());
                }else {
                    mView.onWithdrawHistoryResult(false, response.code(),response.body());
                }
            }

            @Override
            public void onFailure(Call<WithdrawSaldoHistoryResponseModel> call, Throwable t) {

            }
        });
    }
}
