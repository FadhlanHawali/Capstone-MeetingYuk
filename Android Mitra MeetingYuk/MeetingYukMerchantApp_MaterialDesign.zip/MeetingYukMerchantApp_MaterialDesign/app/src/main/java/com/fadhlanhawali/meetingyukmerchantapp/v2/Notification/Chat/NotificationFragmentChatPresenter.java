package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.Chat;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.widget.Toast;

import androidx.lifecycle.LiveData;

import com.fadhlanhawali.meetingyukmerchantapp.v2.API.ChatAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.ChatInterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.GetChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.GetListRoomChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetUnreadChatCount.GetUnreadChatCountResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ListRoomChatDao;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationContract;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationFragmentChatPresenter implements NotificationContract.pChat {

    private Context mContext;
    private NotificationContract.vChat mView;
    private ChatInterfaceAPI interfaceAPI;
    private ListRoomChatDao listRoomChatDao;

    @Override
    public void initP() {
        mView.initV();
    }

    public NotificationFragmentChatPresenter(Context context, NotificationContract.vChat view, ListRoomChatDao listRoomChatDao) {
       this.mContext = context;
       this.mView = view;
       this.listRoomChatDao = listRoomChatDao;
    }

    @Override
    public void getListRoomChat(String idMerchant) {
        interfaceAPI = ChatAPIUtils.getChatService();
        interfaceAPI.getListRoomChat(idMerchant).enqueue(new Callback<GetListRoomChatResponseModel>() {
            @Override
            public void onResponse(Call<GetListRoomChatResponseModel> call, Response<GetListRoomChatResponseModel> response) {
                if(response.isSuccessful()){
                    Log.d("URL LIST ROOM : ",call.request().url().toString() + idMerchant);
                    mView.onGetListRoomChatResult(true,response.code(),response.body());
                }else {
                    Log.d("URL LIST ROOM : ","Error : " + call.request().url().toString() + idMerchant);
                    mView.onGetListRoomChatResult(false,response.code(),null);
                }

            }

            @Override
            public void onFailure(Call<GetListRoomChatResponseModel> call, Throwable t) {
                Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void dbGetListRoomChat() {
        mView.onDBGetListRoomChatResult(this.listRoomChatDao.getListRoomChat());
    }

    @Override
    public void dbInsertListRoomChat(GetListRoomChatResponseModel getListRoomChatResponseModel) {
//        this.listRoomChatDao.deleteAll();
        List<DataItem> listRoomChat = getListRoomChatResponseModel.getData();
        for (int i = 0;i<listRoomChat.size();i++){
//            this.listRoomChatDao.insertRoomChat(listRoomChat.get(i));
            this.listRoomChatDao.insertRoomChat(listRoomChat.get(i));
        }
    }

    @Override
    public void checkConnectivity() {
        ConnectivityManager cm =
                (ConnectivityManager)mContext.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

        mView.onCheckConnectivity(isConnected);
    }

}
