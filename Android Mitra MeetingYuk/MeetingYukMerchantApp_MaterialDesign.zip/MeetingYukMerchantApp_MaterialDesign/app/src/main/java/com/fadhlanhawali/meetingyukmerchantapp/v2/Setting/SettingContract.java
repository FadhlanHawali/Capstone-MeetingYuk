package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting;

import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.UploadFileServiceModel.UploadFileServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.GetAdmin.GetAdminResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.EditProfile.EditProfileRequest;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import okhttp3.MultipartBody;

public interface SettingContract {

    interface vSetting{
        void initV();
        void onResult(Boolean result);
        void onGetAdminResult(GetAdminResponseModel getAdminResponseModel, Boolean result, int code);
        void onDeleteAdminResult(GeneralResponseModel generalResponseModel, Boolean result, int code);
        void onUploadFileResult(Boolean result, int code, UploadFileServiceResponseModel uploadFileServiceResponseModel);
        void onEditProfileResult(GeneralResponseModel generalResponseModel, Boolean result, int code);
    }

    interface pSetting{
        void initP();
        void doGetSession (SessionManager sessionManager);
        void getAdminList(String token);
        void deleteAdmin(String token, String adminEmail);
        void doUploadFile(MultipartBody.Part body);
        void doEditProfile(EditProfileRequest editProfileRequest, String token);
    }
}
