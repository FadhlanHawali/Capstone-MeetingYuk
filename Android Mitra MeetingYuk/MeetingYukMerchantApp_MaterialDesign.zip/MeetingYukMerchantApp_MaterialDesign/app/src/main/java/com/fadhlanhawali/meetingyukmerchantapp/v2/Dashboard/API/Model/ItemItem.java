package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model;

import android.os.Parcel;
import android.os.Parcelable;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class ItemItem implements Parcelable {

	@SerializedName("id_order")
	private String idOrder;

	@SerializedName("total_price")
	private int totalPrice;

	@SerializedName("service_name")
	private String serviceName;

	@SerializedName("price")
	private int price;

	@SerializedName("qty")
	private int qty;

	@SerializedName("id")
	private String id;

	@SerializedName("id_service")
	private String idService;

	public void setIdOrder(String idOrder){
		this.idOrder = idOrder;
	}

	public String getIdOrder(){
		return idOrder;
	}

	public void setTotalPrice(int totalPrice){
		this.totalPrice = totalPrice;
	}

	public int getTotalPrice(){
		return totalPrice;
	}

	public void setServiceName(String serviceName){
		this.serviceName = serviceName;
	}

	public String getServiceName(){
		return serviceName;
	}

	public void setPrice(int price){
		this.price = price;
	}

	public int getPrice(){
		return price;
	}

	public void setQty(int qty){
		this.qty = qty;
	}

	public int getQty(){
		return qty;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setIdService(String idService){
		this.idService = idService;
	}

	public String getIdService(){
		return idService;
	}

	@Override
 	public String toString(){
		return 
			"ItemItem{" + 
			"id_order = '" + idOrder + '\'' + 
			",total_price = '" + totalPrice + '\'' + 
			",service_name = '" + serviceName + '\'' + 
			",price = '" + price + '\'' + 
			",qty = '" + qty + '\'' + 
			",id = '" + id + '\'' + 
			",id_service = '" + idService + '\'' + 
			"}";
		}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.idOrder);
		dest.writeInt(this.totalPrice);
		dest.writeString(this.serviceName);
		dest.writeInt(this.price);
		dest.writeInt(this.qty);
		dest.writeString(this.id);
		dest.writeString(this.idService);
	}

	public ItemItem() {
	}

	protected ItemItem(Parcel in) {
		this.idOrder = in.readString();
		this.totalPrice = in.readInt();
		this.serviceName = in.readString();
		this.price = in.readInt();
		this.qty = in.readInt();
		this.id = in.readString();
		this.idService = in.readString();
	}

	public static final Parcelable.Creator<ItemItem> CREATOR = new Parcelable.Creator<ItemItem>() {
		@Override
		public ItemItem createFromParcel(Parcel source) {
			return new ItemItem(source);
		}

		@Override
		public ItemItem[] newArray(int size) {
			return new ItemItem[size];
		}
	};
}