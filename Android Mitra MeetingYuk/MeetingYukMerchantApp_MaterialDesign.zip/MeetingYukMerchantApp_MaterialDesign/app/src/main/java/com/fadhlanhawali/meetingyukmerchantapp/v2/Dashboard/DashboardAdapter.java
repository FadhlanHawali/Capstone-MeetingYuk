package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ConvertDate;
import com.fadhlanhawali.meetingyukmerchantapp.R;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterResponseModel.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Order.OrderActivity;

import java.util.ArrayList;
import java.util.List;

public class DashboardAdapter extends RecyclerView.Adapter<DashboardAdapter.MyViewHolder> {

    private Context mContext;
    private List<DataItem> orderList;
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtTime,txtNamaPeminjam,txtOrdeStatus;
        ImageView imageView;
        public MyViewHolder(final View view) {
            super(view);
            txtNamaPeminjam = view.findViewById(R.id.txtNamaPeminjam);
            txtTime = view.findViewById(R.id.time);
            imageView = view.findViewById(R.id.image);
            txtOrdeStatus = view.findViewById(R.id.txtOrderStatus);
        }

    }

    public DashboardAdapter(Context mContext) {
        this.mContext = mContext;
        this.orderList = new ArrayList<>();
    }

    public void setOrderList(List<DataItem> orderList) {
        this.orderList = orderList;
        notifyDataSetChanged();
    }

    @Override
    public DashboardAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_konfirmasi_ruanganv2, parent, false);

        return new DashboardAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final DashboardAdapter.MyViewHolder holder, final int position) {
        ConvertDate convertDate = new ConvertDate();
        holder.txtTime.setText(convertDate.convertComplete(orderList.get(position).getTimeStart()));
        holder.txtNamaPeminjam.setText(orderList.get(position).getContact().getName());
        checkStatus(orderList.get(position).getStatus(),holder.txtOrdeStatus);
        Glide.with(mContext).load(orderList.get(position).getMeetingPhoto()).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(holder.imageView);
        Log.d("Tanggal ORDER :",orderList.get(position).getId() + " " + convertDate.convertComplete(orderList.get(position).getTimeStart()));
        holder.itemView.setOnClickListener(v -> {
            Intent i = new Intent(mContext, OrderActivity.class);
            i.putExtra("idOrder",orderList.get(position).getId());
            mContext.startActivity(i);
        });

    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    private void checkStatus(String status,TextView textView){
        int color = 0;
        String statusFinal = "";
        if(status.equals(BuildConfig.ORDER_STATUS_WAITING)){
            statusFinal = "Menunggu Konfirmasi";
            color = mContext.getResources().getColor(R.color.order_status_waiting);
        }else if(status.equals(BuildConfig.ORDER_STATUS_ACCEPTED)){
            statusFinal = "Pesanan Disetujui";
            color = mContext.getResources().getColor(R.color.order_status_accepted);
        }else if(status.equals(BuildConfig.ORDER_STATUS_REJECTED)){
            statusFinal = "Pesanan Ditolak";
            color = mContext.getResources().getColor(R.color.order_status_rejected);
        }else if(status.equals(BuildConfig.ORDER_STATUS_PAYMENT_PROCESS)){
            statusFinal = "Proses Pembayaran";
            color = mContext.getResources().getColor(R.color.order_status_payment_process);
        }else if(status.equals(BuildConfig.ORDER_STATUS_PAYMENT_SUCCESS)){
            statusFinal = "Pembayaran Berhasil";
            color = mContext.getResources().getColor(R.color.order_status_payment_success);
        }else if(status.equals(BuildConfig.ORDER_STATUS_PAYMENT_FAILED)){
            statusFinal = "Pembayaran Gagal";
            color = mContext.getResources().getColor(R.color.order_status_payment_failed);
        }else if(status.equals(BuildConfig.ORDER_STATUS_PAYMENT_EXPIRED)){
            statusFinal = "Pembayaran Kadaluarsa";
            color = mContext.getResources().getColor(R.color.order_status_payment_expired);
        }else if(status.equals(BuildConfig.ORDER_STATUS_FINISH_SUCCESS)){
            statusFinal = "Pesanan Selesai";
            color = mContext.getResources().getColor(R.color.order_status_finish_success);
        }else if(status.equals(BuildConfig.ORDER_STATUS_FINISH_REFUND)){
            statusFinal = "Pengembalian Uang";
            color = mContext.getResources().getColor(R.color.order_status_finish_refund);
        }else if(status.equals(BuildConfig.ORDER_STATUS_CANCEL_BY_USER)){
            statusFinal = "Dibatalkan Pemesan";
            color = mContext.getResources().getColor(R.color.order_status_cancel_by_user);
        }
        textView.setText(statusFinal);
        textView.setTextColor(color);
    }

}


