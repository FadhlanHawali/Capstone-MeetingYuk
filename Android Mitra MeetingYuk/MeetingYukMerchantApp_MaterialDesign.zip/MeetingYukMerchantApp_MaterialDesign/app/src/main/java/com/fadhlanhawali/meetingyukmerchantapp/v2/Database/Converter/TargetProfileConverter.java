package com.fadhlanhawali.meetingyukmerchantapp.v2.Database.Converter;

import androidx.room.TypeConverter;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.TargetProfile;
import com.google.gson.Gson;

import java.io.Serializable;

public class TargetProfileConverter implements Serializable {

    @TypeConverter
    public static String targetProfileToString(com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.TargetProfile targetProfile){

        return new Gson().toJson(targetProfile);
    }

    @TypeConverter
    public static com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.TargetProfile stringToTargetProfile (String targetProfile){

        return new Gson().fromJson(targetProfile, TargetProfile.class);
    }
}
