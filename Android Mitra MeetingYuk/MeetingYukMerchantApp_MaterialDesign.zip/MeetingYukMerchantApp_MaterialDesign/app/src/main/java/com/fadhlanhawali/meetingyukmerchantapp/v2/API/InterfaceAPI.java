package com.fadhlanhawali.meetingyukmerchantapp.v2.API;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Order.Model.OrderDetailResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.UploadFileServiceModel.UploadFileServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.AddAdmin.AddAdminRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.AddAdmin.AddAdminResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.GetAdmin.GetAdminResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.EditProfile.EditProfileRequest;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.Model.SignUpRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.Model.SignUpResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface InterfaceAPI {

    //TODO PINDAHIN KESINI SEMUA

    @Multipart
    @POST(BuildConfig.UPLOAD_FILE)
    Call<UploadFileServiceResponseModel> uploadFileService(@Part MultipartBody.Part image);

    @GET(BuildConfig.ACCEPT_ORDER)
    Call<OrderResponseModel> acceptOrder(@Header("x-meeting-token") String token, @Path(value = "idMeeting", encoded = true) String orderId);

    @GET(BuildConfig.DECLINE_ORDER)
    Call<OrderResponseModel> declineOrder(@Header("x-meeting-token") String token, @Path(value = "idMeeting", encoded = true) String orderId);

    @GET(BuildConfig.GET_ORDER_DETAIL)
    Call<OrderDetailResponse> detailOrder (@Header("x-meeting-token") String token, @Path(value="idOrder",encoded = true) String idOrder);

    @POST(BuildConfig.SIGNUP)
    Call<SignUpResponseModel> signUp(@Header("x-meeting-token") String token, @Body SignUpRequestModel signUpRequestModel);

    @GET(BuildConfig.GET_ADMIN)
    Call<GetAdminResponseModel> getAdmin (@Header("x-meeting-token") String token);

    @POST(BuildConfig.ADD_ADMIN)
    Call<AddAdminResponseModel> addAdmin (@Header("x-meeting-token") String token, @Body AddAdminRequestModel addAdminRequestModel);

    @GET(BuildConfig.DELETE_ADMIN)
    Call<GeneralResponseModel> deleteAdmin (@Header("x-meeting-token")String token, @Path(value = "adminEmail",encoded = true)String admonEmail);

    @POST(BuildConfig.EDIT_PROFILE)
    Call<GeneralResponseModel> editProfile (@Header("x-meeting-token") String token, @Body EditProfileRequest editProfileRequest);

    @GET(BuildConfig.PUSH_FIREBASE_TOKEN)
    Call<GeneralResponseModel> pushToken (@Header("x-meeting-token") String token, @Path(value = "token", encoded = true) String firebaseToken);

    @GET(BuildConfig.GET_SERVICE_LIST)
    Call<ListServiceResponse> getServiceList(@Header("x-meeting-token") String token);

}
