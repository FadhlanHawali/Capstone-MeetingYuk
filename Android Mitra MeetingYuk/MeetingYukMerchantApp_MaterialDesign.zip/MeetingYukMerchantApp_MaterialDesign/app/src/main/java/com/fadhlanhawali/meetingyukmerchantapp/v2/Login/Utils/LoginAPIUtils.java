package com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Utils;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.ILoginAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.RetrofitClient;

public class LoginAPIUtils {
    public LoginAPIUtils() {
    }

    public static ILoginAPI getAPIService() {
        return RetrofitClient.getClient(BuildConfig.API_BASE_URL).create(ILoginAPI.class);
    }
}
