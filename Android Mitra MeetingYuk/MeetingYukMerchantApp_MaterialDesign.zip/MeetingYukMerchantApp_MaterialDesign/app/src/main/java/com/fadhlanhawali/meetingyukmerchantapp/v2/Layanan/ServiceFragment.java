package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.GetServiceCategory.ServiceCategoryActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewDialog;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewTools;

import java.util.ArrayList;
import java.util.HashMap;

public class ServiceFragment extends Fragment implements ServiceContract.vListService {

    private String TAG = ServiceFragment.class.getSimpleName();
    private ArrayList<DataItem> listRuangan = new ArrayList<>();
    ServiceAdapter serviceAdapter;
    private RecyclerView recyclerView;

    private ServiceContract.pListService mPresenter;
    LinearLayout linearLayoutBtnAdd;
    SessionManager session;
    ProgressBar progressBar;
    HashMap<String, String> user;
    ViewDialog viewDialog;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_add_service, container, false);
        recyclerView = v.findViewById(R.id.listRuanganView);
        mPresenter = new ServicePresenter(getContext(), this);
        session = new SessionManager(getActivity());
        user = session.getUserDetails();
        mPresenter.initP();
        initToolbar();

//        v.findViewById(R.id.btnAddService).setOnClickListener(view -> {
//            Intent i = new Intent(getContext(), ServiceCategoryActivity.class);
//            startActivity(i);
//        });

        return v;
    }

    private void initToolbar() {
        ViewTools.setSystemBarColor(getActivity(), android.R.color.white);
        ViewTools.setSystemBarLight(getActivity());
    }


    @Override
    public void onStart() {
        super.onStart();
        viewDialog = new ViewDialog(getActivity());
        viewDialog.showDialog();
        mPresenter.getServiceList(user.get(SessionManager.KEY_TOKEN));
    }

    @Override
    public void initV() {
        serviceAdapter = new ServiceAdapter(getContext(),"EDIT_SERVICE");
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getContext(), 3);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(serviceAdapter);
    }

    @Override
    public void onClearText() {
        InputMethodManager inputManager = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
    }

    @Override
    public void onResult(Boolean result, int code, ListServiceResponse listServiceResponse) {
        Log.d("List Service : ",listServiceResponse.toString());
        viewDialog.hideDialog();
        serviceAdapter.setServiceList(listServiceResponse.getData());
    }

}
