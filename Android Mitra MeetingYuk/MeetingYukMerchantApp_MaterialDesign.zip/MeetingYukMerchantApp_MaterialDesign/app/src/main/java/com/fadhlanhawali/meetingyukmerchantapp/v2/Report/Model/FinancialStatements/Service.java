package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Service{

	@SerializedName("unit")
	private String unit;

	@SerializedName("quantity")
	private int quantity;

	@SerializedName("price")
	private int price;

	@SerializedName("icon")
	private Icon icon;

	@SerializedName("available")
	private boolean available;

	@SerializedName("name")
	private String name;

	@SerializedName("id_merchant")
	private String idMerchant;

	@SerializedName("description")
	private String description;

	@SerializedName("id")
	private String id;

	@SerializedName("photos")
	private List<PhotosItem> photos;

	public void setUnit(String unit){
		this.unit = unit;
	}

	public String getUnit(){
		return unit;
	}

	public void setQuantity(int quantity){
		this.quantity = quantity;
	}

	public int getQuantity(){
		return quantity;
	}

	public void setPrice(int price){
		this.price = price;
	}

	public int getPrice(){
		return price;
	}

	public void setIcon(Icon icon){
		this.icon = icon;
	}

	public Icon getIcon(){
		return icon;
	}

	public void setAvailable(boolean available){
		this.available = available;
	}

	public boolean isAvailable(){
		return available;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setIdMerchant(String idMerchant){
		this.idMerchant = idMerchant;
	}

	public String getIdMerchant(){
		return idMerchant;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return description;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setPhotos(List<PhotosItem> photos){
		this.photos = photos;
	}

	public List<PhotosItem> getPhotos(){
		return photos;
	}

	@Override
 	public String toString(){
		return 
			"Service{" + 
			"unit = '" + unit + '\'' + 
			",quantity = '" + quantity + '\'' + 
			",price = '" + price + '\'' + 
			",icon = '" + icon + '\'' + 
			",available = '" + available + '\'' + 
			",name = '" + name + '\'' + 
			",id_merchant = '" + idMerchant + '\'' + 
			",description = '" + description + '\'' + 
			",id = '" + id + '\'' + 
			",photos = '" + photos + '\'' + 
			"}";
		}
}