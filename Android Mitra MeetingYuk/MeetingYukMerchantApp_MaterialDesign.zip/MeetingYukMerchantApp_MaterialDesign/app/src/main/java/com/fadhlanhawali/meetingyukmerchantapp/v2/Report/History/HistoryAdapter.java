package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.History;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ConvertDate;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.DataItem;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.MyViewHolder> {

    private Context mContext;
    private List<DataItem> withdrawHistoryList;

    int row_index = -1;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txtBankAccountNameNumber, txtBankAccount, txtWithdrawStatus, txtDate, txtBankAmount;

        LinearLayout linearLayout;
        public MyViewHolder(final View view) {
            super(view);
            txtBankAccountNameNumber = view.findViewById(R.id.txtBankAccountNameNumber);
            txtBankAccount = view.findViewById(R.id.txtBankAccountName);
            txtWithdrawStatus = view.findViewById(R.id.txtWithdrawStatus);
            txtDate = view.findViewById(R.id.txtDate);
            txtBankAmount = view.findViewById(R.id.txtBankAmount);
        }

    }

    public HistoryAdapter(Context mContext, List<DataItem> withdrawHistoryList ) {
        this.mContext = mContext;
        this.withdrawHistoryList = withdrawHistoryList;
    }

    @Override
    public HistoryAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_payment_history, parent, false);

        return new HistoryAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final HistoryAdapter.MyViewHolder holder, final int position) {
        final DataItem withdrawHistory = withdrawHistoryList.get(position);

        String bankAccountNameNumber = withdrawHistory.getBankAccount().getBankName() + "/" + withdrawHistory.getBankAccount().getAccountNumber();
        holder.txtBankAccountNameNumber.setText(bankAccountNameNumber);
        holder.txtBankAccount.setText(withdrawHistory.getBankAccount().getAccountName());
        holder.txtWithdrawStatus.setText(withdrawHistory.getStatus());
        ConvertDate convertDate = new ConvertDate();
        String date = convertDate.convertComplete(withdrawHistory.getCreatedAt());
        holder.txtDate.setText(date);
        holder.txtBankAmount.setText(String.valueOf(withdrawHistory.getWithdrawAmount()));

    }

    @Override
    public int getItemCount() {
        return withdrawHistoryList.size();
    }
}