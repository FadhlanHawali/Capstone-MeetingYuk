package com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class GeneralResponseModel{

	@SerializedName("success")
	private boolean success;

	public void setSuccess(boolean success){
		this.success = success;
	}

	public boolean isSuccess(){
		return success;
	}

	@Override
 	public String toString(){
		return 
			"GeneralResponseModel{" + 
			"success = '" + success + '\'' + 
			"}";
		}
}