package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer;

import android.content.Context;

import com.fadhlanhawali.meetingyukmerchantapp.v2.API.APIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.InterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.AddAdmin.AddAdminRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.AddAdmin.AddAdminResponseModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminPresenter implements  AdminContract.pAdmin {

    private final Context mContext;
    AdminContract.vAdmin mView;
    private InterfaceAPI serviceAPI;
    @Override
    public void initP() {
        mView.initV();
    }

    public AdminPresenter(Context mContext, AdminContract.vAdmin mView) {
        this.mContext = mContext;
        this.mView = mView;
    }

    @Override
    public void doAddAdmin(AddAdminRequestModel addAdminRequestModel, String token) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.addAdmin(token, addAdminRequestModel).enqueue(new Callback<AddAdminResponseModel>() {
            @Override
            public void onResponse(Call<AddAdminResponseModel> call, Response<AddAdminResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onAddAdminResult(response.body(),true,response.code());
                }else {
                    mView.onAddAdminResult(null,false,response.code());
                }
            }

            @Override
            public void onFailure(Call<AddAdminResponseModel> call, Throwable t) {

            }
        });
    }

}
