package com.fadhlanhawali.meetingyukmerchantapp.v2.Order.Model;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class DataItem{

	@SerializedName("item")
	private List<ItemItem> item;

	@SerializedName("order")
	private Order order;

	public void setItem(List<ItemItem> item){
		this.item = item;
	}

	public List<ItemItem> getItem(){
		return item;
	}

	public void setOrder(Order order){
		this.order = order;
	}

	public Order getOrder(){
		return order;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"item = '" + item + '\'' + 
			",order = '" + order + '\'' + 
			"}";
		}
}