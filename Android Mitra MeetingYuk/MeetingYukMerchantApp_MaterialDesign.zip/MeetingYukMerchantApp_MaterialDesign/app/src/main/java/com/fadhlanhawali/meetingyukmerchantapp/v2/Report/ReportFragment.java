package com.fadhlanhawali.meetingyukmerchantapp.v2.Report;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.History.HistoryActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements.GetFinancialStatementsModelResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.GetSaldoMitraResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Withdraw.WithdrawActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewDialog;

import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;

public class ReportFragment extends Fragment implements  ReportContract.vSaldoMitra{

    private RecyclerView recyclerView;
    HashMap<String,String> user;
    ReportContract.pSaldoMitra mPresenter;
    Button btnHistory,btnWithdraw;
    SessionManager sessionManager;
    TextView txtSaldoMitra, txtOrderCount, txtOrderProfit,txtReportPeriodDesc,txtReportPeriod, tvReportWeekly, tvReportMonthly, tvReportQuarterly, tvReportYearly;
    ReportAdapter reportAdapter;
    ViewDialog viewDialog;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_report, container, false);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        recyclerView = v.findViewById(R.id.recyclerView);
        sessionManager = new SessionManager(getContext());
        user = sessionManager.getUserDetails();
        btnHistory = v.findViewById(R.id.btnHistory);
        btnWithdraw = v.findViewById(R.id.btnWithdraw);
        txtSaldoMitra = v.findViewById(R.id.txtSaldoMitra);
        txtOrderCount = v.findViewById(R.id.txtOrderCount);
        txtOrderProfit = v.findViewById(R.id.txtOrderProfit);
        txtReportPeriod = v.findViewById(R.id.txtReportPeriod);
        txtReportPeriodDesc = v.findViewById(R.id.txtReportPeriodDesc);
        tvReportWeekly = v.findViewById(R.id.tvReportWeekly);
        tvReportMonthly = v.findViewById(R.id.tvReportMonthly);
        tvReportQuarterly = v.findViewById(R.id.tvReportQuarterly);
        tvReportYearly = v.findViewById(R.id.tvReportYearly);
        mPresenter = new ReportPresenter(getActivity(),this);
        mPresenter.initP();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getActivity().getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        }
        return v;
    }

    @Override
    public void initV() {
        viewDialog = new ViewDialog(getActivity());
        viewDialog.showDialog();
        mPresenter.doGetFinancialStatements(user.get(SessionManager.KEY_TOKEN),"week");
        mPresenter.doGetSaldoMitraResult(user.get(SessionManager.KEY_TOKEN));
        btnHistory.setOnClickListener(view -> {
            Intent i = new Intent(getContext(), HistoryActivity.class);
            startActivity(i);
        });
        btnWithdraw.setOnClickListener(view -> {
            Intent i = new Intent(getContext(), WithdrawActivity.class);
            startActivity(i);
        });
        txtReportPeriod.setText("Report Minggu Ini");
        txtReportPeriodDesc.setText("Penghasilan Minggu Ini");
        tvReportWeekly.setOnClickListener(view -> {
            tvReportWeekly.setTextColor(Color.WHITE);
            tvReportWeekly.setBackgroundResource(R.drawable.color_gradient_1);
            setWhiteColor(new TextView[]{tvReportMonthly,tvReportYearly,tvReportQuarterly});
            txtReportPeriod.setText("Report Minggu Ini");
            txtReportPeriodDesc.setText("Penghasilan Minggu Ini");
            mPresenter.doGetFinancialStatements(user.get(SessionManager.KEY_TOKEN),"week");
        });
        tvReportMonthly.setOnClickListener(view -> {
            tvReportMonthly.setTextColor(Color.WHITE);
            tvReportMonthly.setBackgroundResource(R.drawable.color_gradient_1);
            setWhiteColor(new TextView[]{tvReportQuarterly,tvReportYearly,tvReportWeekly});
            txtReportPeriod.setText("Report 1 Bulan Ini");
            txtReportPeriodDesc.setText("Penghasilan Bulan Ini");
            mPresenter.doGetFinancialStatements(user.get(SessionManager.KEY_TOKEN),"month");
        });
        tvReportQuarterly.setOnClickListener(view -> {
            tvReportQuarterly.setTextColor(Color.WHITE);
            tvReportQuarterly.setBackgroundResource(R.drawable.color_gradient_1);
            setWhiteColor(new TextView[]{tvReportWeekly,tvReportYearly,tvReportMonthly});
            txtReportPeriod.setText("Report 4 Bulan Ini");
            txtReportPeriodDesc.setText("Penghasilan 4 Bulan Ini");
            mPresenter.doGetFinancialStatements(user.get(SessionManager.KEY_TOKEN),"quarter");
        });
        tvReportYearly.setOnClickListener(view -> {
            tvReportYearly.setTextColor(Color.WHITE);
            tvReportYearly.setBackgroundResource(R.drawable.color_gradient_1);
            setWhiteColor(new TextView[]{tvReportMonthly,tvReportWeekly,tvReportQuarterly});
            txtReportPeriod.setText("Report 1 Tahun Ini");
            txtReportPeriodDesc.setText("Penghasilan 1 Tahun Ini");
            mPresenter.doGetFinancialStatements(user.get(SessionManager.KEY_TOKEN),"year");
        });

        reportAdapter = new ReportAdapter(getContext());
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getContext(),1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(reportAdapter);
    }

    private void setWhiteColor(TextView[] fields){
        for (TextView field : fields) {
            field.setTextColor(Color.parseColor("#32063b40"));
            field.setBackgroundColor(Color.WHITE);
        }
    }

    @Override
    public void onSaldoMitraResult(Boolean result, int code, GetSaldoMitraResponse getSaldoMitraResponse) {
        if (result){

            Locale locale = new Locale("id","ID");
            NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);
            txtSaldoMitra.setText(currencyFormatter.format(getSaldoMitraResponse.getData()));
        }
    }

    @Override
    public void onFinancialStatementsResult(Boolean result, int code, GetFinancialStatementsModelResponse getFinancialStatementsModelResponse) {
        if(result){
            viewDialog.hideDialog();
            Locale locale = new Locale("id","ID");
            NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);
            int orderCount = getFinancialStatementsModelResponse.getData().getOrders().size();
            int orderProfit = getFinancialStatementsModelResponse.getData().getTotalProfit();
            txtOrderCount.setText(String.valueOf(orderCount));
            txtOrderProfit.setText(currencyFormatter.format(orderProfit));

            reportAdapter.setTopServicesItemList(getFinancialStatementsModelResponse.getData().getTopServices());

        }

    }
}