package com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Profile{

	@SerializedName("nama_pemilik")
	private String namaPemilik;

	@SerializedName("fcm")
	private String fcm;

	@SerializedName("url_foto")
	private String urlFoto;

	@SerializedName("str_alamat")
	private String strAlamat;

	@SerializedName("id")
	private String id;

	@SerializedName("nama_tempat")
	private String namaTempat;

	@SerializedName("email")
	private String email;

	@SerializedName("no_telepon")
	private String noTelepon;

	@SerializedName("alamat")
	private Alamat alamat;

	public void setNamaPemilik(String namaPemilik){
		this.namaPemilik = namaPemilik;
	}

	public String getNamaPemilik(){
		return namaPemilik;
	}

	public void setFcm(String fcm){
		this.fcm = fcm;
	}

	public String getFcm(){
		return fcm;
	}

	public void setUrlFoto(String urlFoto){
		this.urlFoto = urlFoto;
	}

	public String getUrlFoto(){
		return urlFoto;
	}

	public void setStrAlamat(String strAlamat){
		this.strAlamat = strAlamat;
	}

	public String getStrAlamat(){
		return strAlamat;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setNamaTempat(String namaTempat){
		this.namaTempat = namaTempat;
	}

	public String getNamaTempat(){
		return namaTempat;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

	public void setNoTelepon(String noTelepon){
		this.noTelepon = noTelepon;
	}

	public String getNoTelepon(){
		return noTelepon;
	}

	public void setAlamat(Alamat alamat){
		this.alamat = alamat;
	}

	public Alamat getAlamat(){
		return alamat;
	}

	@Override
 	public String toString(){
		return 
			"Profile{" + 
			"nama_pemilik = '" + namaPemilik + '\'' + 
			",fcm = '" + fcm + '\'' + 
			",url_foto = '" + urlFoto + '\'' + 
			",str_alamat = '" + strAlamat + '\'' + 
			",id = '" + id + '\'' + 
			",nama_tempat = '" + namaTempat + '\'' + 
			",email = '" + email + '\'' + 
			",no_telepon = '" + noTelepon + '\'' + 
			",alamat = '" + alamat + '\'' + 
			"}";
		}
}