package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationCenter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ConvertDate;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Order.OrderActivity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class NotificationFragmentCenterAdapter extends RecyclerView.Adapter<NotificationFragmentCenterAdapter.MyViewHolder> {

    private Context mContext;
    private List<DataItem> konfirmasiRuanganList;
    public TextView txtNamaPeminjam,txtTime;
    public ImageView imageView;
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView idRequest;


        public MyViewHolder(final View view) {
            super(view);
            txtNamaPeminjam = view.findViewById(R.id.txtNamaPeminjam);
            txtTime = view.findViewById(R.id.time);
            imageView = view.findViewById(R.id.image);
        }

    }

    public NotificationFragmentCenterAdapter(Context mContext, List<DataItem> konfirmasiRuanganList) {
        this.mContext = mContext;
        this.konfirmasiRuanganList = konfirmasiRuanganList;
    }

    @Override
    public NotificationFragmentCenterAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_list_order, parent, false);

        return new NotificationFragmentCenterAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final NotificationFragmentCenterAdapter.MyViewHolder holder, final int position) {
        ConvertDate convertDate = new ConvertDate();
//        Long time = ruangan.getData().get(position).getOrder().getOrderDate();
        txtTime.setText(convertDate.convertComplete(konfirmasiRuanganList.get(position).getOrder().getTimeStart()));
        txtNamaPeminjam.setText(konfirmasiRuanganList.get(position).getOrder().getContact().getName());
//        Toast.makeText(mContext,"URL Foto: " + konfirmasiRuanganList.get(position).getOrder().getMeetingPhoto(), Toast.LENGTH_SHORT).show();
        Glide.with(mContext).load(konfirmasiRuanganList.get(position).getOrder().getMeetingPhoto()).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imageView);
//        holder.idRequest.setText(ruangan.getId());
//        Glide.with(mContext).load(konfirmasiRuanganList.get(position).getUrlImage()).into(imageView);
//
//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(mContext, DetailPeminjamActivity.class);
//                i.putExtra("id",holder.idRequest.getText().toString());
//                i.putExtra("nama",namaPeminjam.getText().toString());
//                i.putExtra("time",time.getText().toString());
//                i.putExtra("completeDate",ruangan.getCompleteDate().toString());
//                mContext.startActivity(i);
//            }
//        });


        if (!konfirmasiRuanganList.get(position).getOrder().getStatus().equals("accepted")){
            holder.itemView.setOnClickListener(v -> {
                Toast.makeText(mContext, "Can be Clicked", Toast.LENGTH_SHORT).show();
                List<DataItem> cobo = new ArrayList<DataItem>();
                Bundle bundle = new Bundle();
                Intent i = new Intent(mContext, OrderActivity.class);
                i.putExtra("order", (Serializable) konfirmasiRuanganList);
                mContext.startActivity(i);
            });
        } else {
            holder.itemView.setOnClickListener(v -> {
                Toast.makeText(mContext, "Can't be Clicked", Toast.LENGTH_SHORT).show();
            });
        }

    }

    @Override
    public int getItemCount() {
        return konfirmasiRuanganList.size();
    }

}


