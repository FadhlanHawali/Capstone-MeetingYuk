package com.fadhlanhawali.meetingyukmerchantapp;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.AddOrder.AddOrderActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.GetServiceCategory.ServiceCategoryActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;

import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.DashboardFragment;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationFragment;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.ReportFragment;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.ServiceFragment;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.SettingFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.vanniktech.emoji.EmojiManager;
import com.vanniktech.emoji.google.GoogleEmojiProvider;

import java.util.HashMap;
import java.util.List;

public class  MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {


    MenuItem settings;
    SessionManager session;
    FloatingActionButton fab;
    static String[] permissions = new String[]{
            Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //loading the default fragment
        loadFragment(new com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.DashboardFragment());

        EmojiManager.install(new GoogleEmojiProvider());
        //getting bottom navigation view and attaching the listener
        BottomNavigationView navigation = findViewById(R.id.navigation);
        BottomNavigationViewHelper.disableShiftMode(navigation);
        navigation.setOnNavigationItemSelectedListener(this);

        fab = findViewById(R.id.fab);
        navigation.setSelectedItemId(R.id.navigation_dashboard);

        session = new SessionManager(this);
        showPermissionDialog();
    }

    private void showPermissionDialog(){
        Dexter.withActivity(this).withPermissions(permissions)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                        }
                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            showSettingsDialog();
                        }
                    }
                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).withErrorListener(error -> showErrorDialog())
                .onSameThread()
                .check();
    }
    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.message_need_permission));
        builder.setMessage(getString(R.string.message_grant_permission));
        builder.setPositiveButton(getString(R.string.label_setting), (dialog, which) -> {
            dialog.cancel();
            openSettings();
        });
        builder.setNegativeButton(getString(R.string.cancel), (dialog, which) -> dialog.cancel());
        builder.show();
    }

    public void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    public void showErrorDialog() {
        Toast.makeText(getApplicationContext(), getString(R.string.error_message), Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;

        switch (item.getItemId()) {
            case R.id.navigation_dashboard:
                fab.setVisibility(View.VISIBLE);
                fab.setOnClickListener(view -> {
                    Intent i = new Intent(getApplicationContext(), AddOrderActivity.class);
                    startActivity(i);
                });
                fragment = new DashboardFragment();
                break;

            case R.id.navigation_edit:
                fab.setVisibility(View.VISIBLE);
                fab.setOnClickListener(view -> {
                    Intent i = new Intent(getApplicationContext(), ServiceCategoryActivity.class);
                    startActivity(i);
                });
                fragment = new ServiceFragment();
                break;

            case R.id.navigation_history:
                fab.setVisibility(View.GONE);
                fragment = new ReportFragment();
                break;

            case R.id.navigation_settings:
                fab.setVisibility(View.GONE);
                HashMap<String, String> user = session.getUserDetails();
                item.setTitle(user.get(SessionManager.KEY_NAMAPEMILIK));
                fragment = new SettingFragment();
                break;

            case R.id.navigation_notification:
                fab.setVisibility(View.GONE);
                fragment = new NotificationFragment();
                break;
        }

        return loadFragment(fragment);
    }

    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}
