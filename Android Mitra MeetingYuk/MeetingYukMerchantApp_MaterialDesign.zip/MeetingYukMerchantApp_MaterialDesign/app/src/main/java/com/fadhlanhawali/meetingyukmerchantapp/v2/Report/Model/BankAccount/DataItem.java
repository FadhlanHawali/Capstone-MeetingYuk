package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class DataItem{

	@SerializedName("account_number")
	private String accountNumber;

	@SerializedName("user_id")
	private String userId;

	@SerializedName("account_name")
	private String accountName;

	@SerializedName("bank_name")
	private String bankName;

	@SerializedName("_id")
	private String _id;

	@SerializedName("id")
	private String id;

	public void setAccountNumber(String accountNumber){
		this.accountNumber = accountNumber;
	}

	public String getAccountNumber(){
		return accountNumber;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return userId;
	}

	public void setAccountName(String accountName){
		this.accountName = accountName;
	}

	public String getAccountName(){
		return accountName;
	}

	public void setBankName(String bankName){
		this.bankName = bankName;
	}

	public String getBankName(){
		return bankName;
	}

	public void set_Id(String _id){
		this._id = _id;
	}

	public String get_Id(){
		return _id;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"account_number = '" + accountNumber + '\'' + 
			",user_id = '" + userId + '\'' + 
			",account_name = '" + accountName + '\'' + 
			",bank_name = '" + bankName + '\'' + 
			",_id = '" + id + '\'' + 
			",id = '" + id + '\'' + 
			"}";
		}
}