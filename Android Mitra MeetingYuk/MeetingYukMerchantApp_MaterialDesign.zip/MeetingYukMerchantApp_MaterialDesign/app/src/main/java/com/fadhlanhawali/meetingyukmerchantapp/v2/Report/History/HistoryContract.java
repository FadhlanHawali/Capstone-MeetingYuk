package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.History;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoHistoryResponseModel;

public interface HistoryContract {

    interface vHistoryWithdraw{
        void initV();
        void onWithdrawHistoryResult(Boolean result, int code, WithdrawSaldoHistoryResponseModel withdrawSaldoHistoryResponseModel);
    }

    interface pHistoryWithdraw{
        void initP();
        void getWithdrawHistory (String token);
    }


}
