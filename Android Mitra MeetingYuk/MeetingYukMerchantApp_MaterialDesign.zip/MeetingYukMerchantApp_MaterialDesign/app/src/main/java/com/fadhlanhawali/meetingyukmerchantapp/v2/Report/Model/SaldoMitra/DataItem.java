package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class DataItem{

	@SerializedName("withdraw_fee")
	private int withdrawFee;

	@SerializedName("withdraw_amount")
	private int withdrawAmount;

	@SerializedName("user_id")
	private String userId;

	@SerializedName("created_at")
	private long createdAt;

	@SerializedName("_id")
	private String _id;

	@SerializedName("id")
	private String id;

	@SerializedName("bank_account")
	private BankAccount bankAccount;

	@SerializedName("status")
	private String status;

	public void setWithdrawFee(int withdrawFee){
		this.withdrawFee = withdrawFee;
	}

	public int getWithdrawFee(){
		return withdrawFee;
	}

	public void setWithdrawAmount(int withdrawAmount){
		this.withdrawAmount = withdrawAmount;
	}

	public int getWithdrawAmount(){
		return withdrawAmount;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return userId;
	}

	public void setCreatedAt(long createdAt){
		this.createdAt = createdAt;
	}

	public long getCreatedAt(){
		return createdAt;
	}

	public void set_Id(String _id){
		this._id = _id;
	}

	public String get_Id(){
		return _id;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setBankAccount(BankAccount bankAccount){
		this.bankAccount = bankAccount;
	}

	public BankAccount getBankAccount(){
		return bankAccount;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"withdraw_fee = '" + withdrawFee + '\'' + 
			",withdraw_amount = '" + withdrawAmount + '\'' + 
			",user_id = '" + userId + '\'' + 
			",created_at = '" + createdAt + '\'' + 
			",_id = '" + id + '\'' + 
			",id = '" + id + '\'' + 
			",bank_account = '" + bankAccount + '\'' + 
			",status = '" + status + '\'' + 
			"}";
		}
}