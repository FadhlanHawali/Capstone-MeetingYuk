package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class DataItem implements Serializable, Parcelable {

	@SerializedName("item")
	private List<ItemItem> item;

	@SerializedName("order")
	private Order order;

	public void setItem(List<ItemItem> item){
		this.item = item;
	}

	public List<ItemItem> getItem(){
		return item;
	}

	public void setOrder(Order order){
		this.order = order;
	}

	public Order getOrder(){
		return order;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"item = '" + item + '\'' + 
			",order = '" + order + '\'' + 
			"}";
		}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeList(this.item);
		dest.writeParcelable(this.order, flags);
	}

	public DataItem() {
	}

	protected DataItem(Parcel in) {
		this.item = new ArrayList<ItemItem>();
		in.readList(this.item, ItemItem.class.getClassLoader());
		this.order = in.readParcelable(Order.class.getClassLoader());
	}

	public static final Parcelable.Creator<DataItem> CREATOR = new Parcelable.Creator<DataItem>() {
		@Override
		public DataItem createFromParcel(Parcel source) {
			return new DataItem(source);
		}

		@Override
		public DataItem[] newArray(int size) {
			return new DataItem[size];
		}
	};
}