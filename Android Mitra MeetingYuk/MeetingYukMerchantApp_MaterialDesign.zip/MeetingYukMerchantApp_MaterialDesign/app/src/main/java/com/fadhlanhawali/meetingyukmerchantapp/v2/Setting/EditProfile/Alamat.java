package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.EditProfile;

import com.google.gson.annotations.SerializedName;

public class Alamat{

	@SerializedName("lng")
	private double lng;

	@SerializedName("lat")
	private double lat;

	public void setLng(double lng){
		this.lng = lng;
	}

	public double getLng(){
		return lng;
	}

	public void setLat(double lat){
		this.lat = lat;
	}

	public double getLat(){
		return lat;
	}

	public Alamat(double lng, double lat) {
		this.lng = lng;
		this.lat = lat;
	}

	@Override
 	public String toString(){
		return 
			"Alamat{" + 
			"lng = '" + lng + '\'' + 
			",lat = '" + lat + '\'' + 
			"}";
		}
}