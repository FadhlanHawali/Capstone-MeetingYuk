package com.fadhlanhawali.meetingyukmerchantapp.v2.Order;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Order.Model.ItemItem;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.MyViewHolder> {

    private Context mContext;
    private List<ItemItem> serviceList;
    public TextView txtQuantity,txtLayanan,txtTotalHarga, txtHarga;
    public ImageView imgIconService;
    public class MyViewHolder extends RecyclerView.ViewHolder {

        public MyViewHolder(final View view) {
            super(view);
            txtHarga = view.findViewById(R.id.txtHarga);
            txtTotalHarga = view.findViewById(R.id.txtTotalHarga);
            txtLayanan = view.findViewById(R.id.txtLayanan);
            txtQuantity = view.findViewById(R.id.txtQuantity);
            imgIconService = view.findViewById(R.id.imgIconService);
        }

    }

    public OrderAdapter(Context mContext) {
        this.mContext = mContext;
        serviceList = new ArrayList<>();
    }

    public void setOrderList(List<ItemItem> serviceList) {
        this.serviceList = serviceList;
        notifyDataSetChanged();
    }

    @Override
    public OrderAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_detail_pesanan, parent, false);

        return new OrderAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final OrderAdapter.MyViewHolder holder, final int position) {
        txtHarga.setText(String.valueOf(serviceList.get(position).getPrice()));
        txtTotalHarga.setText(String.valueOf(serviceList.get(position).getTotalPrice()));

        String unit = "";
        if(serviceList.get(position).getUnit().equals("hour")){
            unit = "Jam";
        }else if(serviceList.get(position).getUnit().equals("packet")){
            unit = "Paket";
        }
        String qty = NumberFormat.getInstance().format(serviceList.get(position).getQty()) + " " + unit;
        txtQuantity.setText(qty);
        txtLayanan.setText(serviceList.get(position).getServiceName());
        Glide.with(mContext).load(serviceList.get(position).getItemIcon()).
                apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).
                into(imgIconService);

//        ConvertDate convertDate = new ConvertDate();
//        txtTime.setText(convertDate.convertComplete(orderList.get(position).getTimeStart()));
//        txtNamaPeminjam.setText(orderList.get(position).getContact().getName());
//        Glide.with(mContext).load(orderList.get(position).getMeetingPhoto()).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imageView);
//
//        holder.itemView.setOnClickListener(v -> {
//            Intent i = new Intent(mContext, OrderActivity.class);
//            i.putExtra("idOrder",orderList.get(position).getId());
//            mContext.startActivity(i);
//        });

    }

    @Override
    public int getItemCount() {
        return serviceList.size();
    }

}


