package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class ItemItem{

	@SerializedName("unit")
	private String unit;

	@SerializedName("id_order")
	private String idOrder;

	@SerializedName("total_price")
	private int totalPrice;

	@SerializedName("service_name")
	private String serviceName;

	@SerializedName("price")
	private int price;

	@SerializedName("qty")
	private double qty;

	@SerializedName("id")
	private String id;

	@SerializedName("item_icon")
	private String itemIcon;

	@SerializedName("id_service")
	private String idService;

	public void setUnit(String unit){
		this.unit = unit;
	}

	public String getUnit(){
		return unit;
	}

	public void setIdOrder(String idOrder){
		this.idOrder = idOrder;
	}

	public String getIdOrder(){
		return idOrder;
	}

	public void setTotalPrice(int totalPrice){
		this.totalPrice = totalPrice;
	}

	public int getTotalPrice(){
		return totalPrice;
	}

	public void setServiceName(String serviceName){
		this.serviceName = serviceName;
	}

	public String getServiceName(){
		return serviceName;
	}

	public void setPrice(int price){
		this.price = price;
	}

	public int getPrice(){
		return price;
	}

	public void setQty(double qty){
		this.qty = qty;
	}

	public double getQty(){
		return qty;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setItemIcon(String itemIcon){
		this.itemIcon = itemIcon;
	}

	public String getItemIcon(){
		return itemIcon;
	}

	public void setIdService(String idService){
		this.idService = idService;
	}

	public String getIdService(){
		return idService;
	}

	@Override
 	public String toString(){
		return 
			"ItemItem{" + 
			"unit = '" + unit + '\'' + 
			",id_order = '" + idOrder + '\'' + 
			",total_price = '" + totalPrice + '\'' + 
			",service_name = '" + serviceName + '\'' + 
			",price = '" + price + '\'' + 
			",qty = '" + qty + '\'' + 
			",id = '" + id + '\'' + 
			",item_icon = '" + itemIcon + '\'' + 
			",id_service = '" + idService + '\'' + 
			"}";
		}
}