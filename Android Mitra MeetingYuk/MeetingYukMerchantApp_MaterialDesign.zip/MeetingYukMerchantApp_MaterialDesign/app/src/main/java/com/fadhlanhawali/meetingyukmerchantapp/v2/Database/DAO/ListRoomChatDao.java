package com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem;

import java.util.List;

import static androidx.room.OnConflictStrategy.IGNORE;
import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface ListRoomChatDao {

    @Query("SELECT * FROM list_room_chat")
    List<DataItem> getListRoomChat();

    @Insert(onConflict = REPLACE)
    void insertRoomChat(DataItem listRoomChat);

//    @Insert(onConflict = REPLACE)
//    void insertRoomChatReplace(DataItem listRoomChat);

//    @Update(onConflict = IGNORE)
//    void updateRoomChat(DataItem listRoomChat);

    @Query("DELETE FROM list_room_chat")
    void deleteAll();

    @Query("SELECT * FROM list_room_chat Where id=:id")
    DataItem findRoom(String id);

    @Delete
    void deleteRoom(DataItem listRoomChat);
}
