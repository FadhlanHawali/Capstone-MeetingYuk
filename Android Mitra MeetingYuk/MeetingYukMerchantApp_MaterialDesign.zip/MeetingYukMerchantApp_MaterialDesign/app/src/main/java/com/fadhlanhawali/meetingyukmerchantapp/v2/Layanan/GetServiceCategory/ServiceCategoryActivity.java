package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.GetServiceCategory;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.AddService.AddServiceActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.CategoryServiceModel.CategoryServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.ServiceContract;

import java.util.HashMap;

public class ServiceCategoryActivity extends AppCompatActivity implements ServiceContract.vGetServiceCategory {

    ServiceContract.pGetServiceCategory mPresenter;
    SessionManager sessionManager;
    HashMap<String, String> user;
    RecyclerView recyclerView;
    TextView txtJumlahLayanan;
    ServiceCategoryAdapter serviceCategoryAdapter;
    Button btnLanjutkan, btnBatal;
    private static final String FLAG_ADD_SERVICE = "ADD_SERVICE";

    private String idCategory = "",category = "", url = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_category);
        mPresenter = new ServiceCategoryPresenter(this,this);
        sessionManager = new SessionManager(getApplicationContext());
        user = sessionManager.getUserDetails();
        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver,
                new IntentFilter("service"));
        mPresenter.initP();
    }

    @Override
    public void initV() {
        recyclerView = findViewById(R.id.recyclerView);
        btnBatal = findViewById(R.id.btnBatal);
        btnLanjutkan = findViewById(R.id.btnLanjutkan);
        txtJumlahLayanan = findViewById(R.id.txtJumlahLayanan);
        mPresenter.getServiceCategory(user.get(SessionManager.KEY_TOKEN));
        mPresenter.getCountService(user.get(SessionManager.KEY_TOKEN));
        btnLanjutkan.setOnClickListener(v -> {
            if(!category.equals("")){
//                Toast.makeText(ServiceCategoryActivity.this,"Id : " + idCategory + "category : " + category  ,Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), AddServiceActivity.class);
                i.putExtra("flag",FLAG_ADD_SERVICE);
                i.putExtra("serviceCategoryId",idCategory);
                i.putExtra("serviceCategoryText",category);
                i.putExtra("serviceCategoryUrl",url);
                startActivity(i);
                finish();
            }else{
                Toast.makeText(ServiceCategoryActivity.this,"Pilih kategori terlebih dahulu !" ,Toast.LENGTH_SHORT).show();
            }


        });
    }

    @Override
    public void onResult(Boolean result, int code, CategoryServiceResponseModel categoryServiceResponseModel) {
        serviceCategoryAdapter = new ServiceCategoryAdapter(this, categoryServiceResponseModel.getData());
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getApplicationContext(), 3);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(serviceCategoryAdapter);
    }

    @Override
    public void setCategory(String idCategory, String category, String url) {
        this.idCategory = idCategory;
        this.category = category;
        this.url = url;
    }

    @Override
    public void onResultCount(Boolean result, int code, int count) {
        txtJumlahLayanan.setText(String.valueOf(count));
    }

    public BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String serviceCategoryId = intent.getStringExtra("serviceCategoryId");
            String serviceCategoryText = intent.getStringExtra("serviceCategoryText");
            String serviceCategoryUrl = intent.getStringExtra("serviceCategoryUrl");
            setCategory(serviceCategoryId, serviceCategoryText,serviceCategoryUrl);
        }
    };
}
