package com.fadhlanhawali.meetingyukmerchantapp.v2.Report;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements.GetFinancialStatementsModelResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.GetSaldoMitraResponse;

interface ReportContract {
    interface vSaldoMitra{
        void initV();
        void onSaldoMitraResult(Boolean result, int code, GetSaldoMitraResponse getSaldoMitraResponse);
        void onFinancialStatementsResult(Boolean result, int code, GetFinancialStatementsModelResponse getFinancialStatementsModelResponse);
    }
    interface pSaldoMitra{
        void initP();
        void doGetSaldoMitraResult(String token);
        void doGetFinancialStatements(String token, String period);
    }
}
