package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetUnreadChatCount;

public class GetUnreadChatCountResponse {

    String idRoom;
    int count;

    public GetUnreadChatCountResponse(String idRoom, int count) {
        this.idRoom = idRoom;
        this.count = count;
    }

    public String getIdRoom() {
        return idRoom;
    }

    public void setIdRoom(String idRoom) {
        this.idRoom = idRoom;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
