package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan;

import android.content.Context;
import android.content.Intent;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.NetworkImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.AddService.AddServiceActivity;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.DataItem;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ServiceAdapter extends RecyclerView.Adapter<ServiceAdapter.MyViewHolder> {

    private Context mContext;
    private String flag;
    private List<DataItem> serviceList = new ArrayList<>();
    private TextView namaRuangan,namaRuanganAddOrder;


    public ImageView imageRuangan;
    private static final String FLAG_ADD_ORDER = "ADD_ORDER";
    private static final String FLAG_EDIT_SERVICE = "EDIT_SERVICE";

    int row_index = -1;
    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private SparseBooleanArray selectedItems = new SparseBooleanArray();
        Button btAddService;
        private RelativeLayout rlAddOrder;
        private TextView tvQty;
        private LinearLayout llCounter;
        private ImageView ivDecrease,ivIncrease;
        public MyViewHolder(final View view) {
            super(view);
            view.setOnClickListener(this);
            namaRuangan = view.findViewById(R.id.txtNamaRuangan);
            imageRuangan = view.findViewById(R.id.imageRuangan);
            namaRuanganAddOrder = view.findViewById(R.id.txtNamaRuanganAddOrder);
            tvQty = view.findViewById(R.id.tvQty);
            rlAddOrder = view.findViewById(R.id.rlAddOrder);
            llCounter = view.findViewById(R.id.llCounter);
            btAddService = view.findViewById(R.id.btAddService);
            ivDecrease = view.findViewById(R.id.btDecrease);
            ivIncrease = view.findViewById(R.id.btIncrease);

            if(flag .equals(FLAG_ADD_ORDER)){
                namaRuangan.setVisibility(View.GONE);
                namaRuanganAddOrder.setVisibility(View.VISIBLE);
                rlAddOrder.setVisibility(View.VISIBLE);
            }else {
                namaRuangan.setVisibility(View.VISIBLE);
                namaRuanganAddOrder.setVisibility(View.GONE);
                rlAddOrder.setVisibility(View.GONE);
            }
        }

        @Override
        public void onClick(View view) {
            if(flag.equals(FLAG_ADD_ORDER)){
//                if (selectedItems.get(getAdapterPosition(), false)) {
//                    selectedItems.delete(getAdapterPosition());
//                    view.setSelected(false);
//                }
//                else {
//                    selectedItems.put(getAdapterPosition(), true);
//                    view.setSelected(true);
//                }
            }
        }
    }


    public ServiceAdapter(Context mContext, String flag) {
        this.mContext = mContext;
        this.flag = flag;
    }

    public void setServiceList(List<DataItem> serviceList) {
        this.serviceList = serviceList;
        notifyDataSetChanged();
    }

    @Override
    public ServiceAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_list_ruangan, parent, false);


        return new ServiceAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ServiceAdapter.MyViewHolder holder, final int position) {
        final DataItem service = serviceList.get(position);
        namaRuangan.setText(service.getName());
        namaRuanganAddOrder.setText(service.getName());

        holder.btAddService.setOnClickListener(view -> {
            holder.btAddService.setVisibility(View.INVISIBLE);
            holder.llCounter.setVisibility(View.VISIBLE);
            service.setFlagSelected(1);
        });

        holder.ivIncrease.setOnClickListener(view -> {
            service.setQtyOrder(service.getQtyOrder() + 1);
            holder.tvQty.setText(String.valueOf(service.getQtyOrder()));
            service.setFlagSelected(1);
        });

        holder.ivDecrease.setOnClickListener(view -> {
            service.setQtyOrder(service.getQtyOrder() - 1);
            if(service.getQtyOrder() == 0){
                service.setQtyOrder(1);
                holder.llCounter.setVisibility(View.GONE);
                holder.btAddService.setVisibility(View.VISIBLE);
                service.setFlagSelected(0);
            }else {
                holder.tvQty.setText(String.valueOf(service.getQtyOrder()));
            }

        });

        Glide.with(mContext).load(service.getPhotos().get(0).getUrl()).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imageRuangan);
        if (flag.equals(FLAG_EDIT_SERVICE)){
            holder.itemView.setOnClickListener(v -> {
                Intent i = new Intent(mContext, AddServiceActivity.class);
                i.putExtra("flag",FLAG_EDIT_SERVICE);
                i.putExtra("service", (Serializable) serviceList);
                i.putExtra("serviceCategoryId",serviceList.get(position).getIcon().getId());
                i.putExtra("serviceCategoryUrl",serviceList.get(position).getIcon().getUrl());
                i.putExtra("index",position);
                Log.d("FLAG",FLAG_EDIT_SERVICE);
                mContext.startActivity(i);
            });
        } else if (flag.equals(FLAG_ADD_ORDER)){
//            holder.itemView.setOnClickListener(view -> {
//                if(service.getFlagSelected() == 0)
//                {
////                    holder.itemView.setBackgroundResource(R.drawable.fasilitas_background);
//                    service.setFlagSelected(1);
//                }
//                else if(service.getFlagSelected()==1)
//                {
////                    holder.itemView.setBackgroundColor(Color.TRANSPARENT);
//                    service.setFlagSelected(0);
//                }
//
//            });


        }

    }

    @Override
    public int getItemCount() {
        return serviceList.size();
    }

    public List<DataItem> getSelectedService(){
        List<DataItem> selectedService = new ArrayList<>();
        for(int i = 0;i<serviceList.size();i++){
            if(serviceList.get(i).getFlagSelected() == 1){
                selectedService.add(serviceList.get(i));
            }
        }

        return selectedService;
    }
}