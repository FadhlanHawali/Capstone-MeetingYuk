package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.Chat.NotificationFragmentChat;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationCenter.NotificationFragmentCenter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationCenter.NotificationFragmentCenterAdapter;

import java.util.HashMap;


public class NotificationFragment extends Fragment implements NotificationContract.vNotification{

    TextView txtMessage;
    NotificationContract.pNotification mPresenter;
    NotificationFragmentCenterAdapter notificationFragmentCenterAdapter;
    RecyclerView recyclerView;
    SessionManager sessionManager;
    HashMap<String,String> user;

    LinearLayout button1,button2;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_notification, container, false);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
//        txtMessage = v.findViewById(R.id.txtMessage);
//        recyclerView = v.findViewById(R.id.recyclerViewNotification);
//        mPresenter = new NotificationPresenter(getContext(),this);
//        sessionManager = new SessionManager(getActivity());
//        user = sessionManager.getUserDetails();
//        getActivity().getWindow().setStatusBarColor(getResources().getColor(R.color.dashboard));
//        Toast.makeText(getContext(), "Token : " + user.get(SessionManager.KEY_TOKEN), Toast.LENGTH_SHORT).show();
//        mPresenter.initP();
        loadFragment(new NotificationFragmentChat());
        button1 = v.findViewById(R.id.button1);
        button2 = v.findViewById(R.id.button2);

        button1.setOnClickListener(view -> {
            Fragment fragment = null;
            fragment = new NotificationFragmentChat();
            loadFragment(fragment);
        });

        button2.setOnClickListener(view -> {
            Fragment fragment = null;
            fragment = new NotificationFragmentCenter();
            loadFragment(fragment);
        });
        return v;
    }

    @Override
    public void initV() {
//        mPresenter.getWaitingOrder(user.get(SessionManager.KEY_TOKEN));
    }

    @Override
    public void onResult(Boolean result, int code, OrderResponseModel orderResponseModel) {
//        Log.d("Response Notification: ", orderResponseModel.toString());
//        requestRuanganAdapterv3 = new RequestRuanganAdapterv3(getContext(),orderResponseModel.getData());
//        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getContext(), 1);
//        recyclerView.setLayoutManager(mLayoutManager);
//        recyclerView.setItemAnimator(new DefaultItemAnimator());
//        recyclerView.setAdapter(requestRuanganAdapterv3);
//
//        if(orderResponseModel.getData().size() == 0){
//            txtMessage.setText("Belum Ada Pesanan");
//        }else {
//            txtMessage.setText("Konfirmasi Pesanan Anda");
//        }
    }

    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
           getChildFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

}

