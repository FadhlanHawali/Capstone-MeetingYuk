package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.Chat;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ConvertDate;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.ChatActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetUnreadChatCount.GetUnreadChatCountResponse;


import java.util.ArrayList;
import java.util.List;

public class NotificationChatAdapter extends RecyclerView.Adapter<NotificationChatAdapter.MyViewHolder> {

    private Context mContext;
    private List<DataItem> chatRoomList;
    private List<GetUnreadChatCountResponse> unreadChatCount;
    ConvertDate convertDate = new ConvertDate();
    private String idMerchant;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtUsername, txtLastChat, txtLastMessageTimestamp,txtUnreadChatCount;
        public ImageView imgProfile;
        public LinearLayout linearLayoutChat;
        public MyViewHolder(final View view) {
            super(view);
            txtUsername = view.findViewById(R.id.txtUsername);
            txtLastMessageTimestamp = view.findViewById(R.id.txtlastMessageTimestamp);
            txtLastChat = view.findViewById(R.id.txtLastChat);
            txtUnreadChatCount = view.findViewById(R.id.txtUnreadCount);
            imgProfile = view.findViewById(R.id.imgProfile);
            linearLayoutChat = view.findViewById(R.id.linearLayoutChat);
        }

    }

    public NotificationChatAdapter(Context mContext, String idMerchant) {
        this.mContext = mContext;
        this.idMerchant = idMerchant;
        chatRoomList = new ArrayList<>();
        unreadChatCount = new ArrayList<>();
    }

    @Override
    public NotificationChatAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_list_chat, parent, false);

        return new NotificationChatAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final NotificationChatAdapter.MyViewHolder holder, final int position) {
        if(chatRoomList.size() != 0){
            holder.txtUsername.setText(chatRoomList.get(position).getTargetProfile().getName());
            holder.txtLastChat.setText(chatRoomList.get(position).getLastMessageText());
            if(chatRoomList.get(position).getUnreadMessage() != 0){
                holder.txtUnreadChatCount.setText(String.valueOf(chatRoomList.get(position).getUnreadMessage()));
            }else {
                holder.txtUnreadChatCount.setVisibility(View.INVISIBLE);
            }
            holder.txtLastMessageTimestamp.setText(convertDate.convertTime(chatRoomList.get(position).getLastMessageTimestamp()));
//        holder.txtUnreadChatCount.setText(unreadChatCount.get(position).getCount());
            Glide.with(mContext).load("https://" + chatRoomList.get(position).getTargetProfile().getProfileUrl()).
                    apply(new RequestOptions().centerCrop().placeholder(R.drawable.ic_person)).into(holder.imgProfile);
            holder.linearLayoutChat.setOnClickListener(view -> {
                String[] member = chatRoomList.get(position).getMember().split(",");
                Intent i = new Intent(mContext, ChatActivity.class);
                i.putExtra("idRoom", chatRoomList.get(position).getId());
                i.putExtra("toUserId", toUserId(member));
                i.putExtra("senderName",chatRoomList.get(position).getTargetProfile().getName());
//            i.putExtra("service", (Serializable) ruanganList);
//            i.putExtra("index",position);
                mContext.startActivity(i);
            });
        }

    }

    @Override
    public int getItemCount() {
        return chatRoomList.size();
    }

    public void setChatRoomList(List<DataItem> chatRoomList) {
        this.chatRoomList = chatRoomList;
        notifyDataSetChanged();
    }

    public void setUnreadChatCount(List<GetUnreadChatCountResponse> unreadChatCount) {
        this.unreadChatCount = unreadChatCount;
        notifyDataSetChanged();
    }

    public void setIdMerchant(String idMerchant) {
        this.idMerchant = idMerchant;
    }

    private String toUserId(String[] member){
        for (String s : member) {
            Log.d("Member : ",s);
            Log.d("Member Merchant : " , idMerchant);
            if (!s.equals(idMerchant)) {
                return s;
            }
        }
        return "";
    }

}


