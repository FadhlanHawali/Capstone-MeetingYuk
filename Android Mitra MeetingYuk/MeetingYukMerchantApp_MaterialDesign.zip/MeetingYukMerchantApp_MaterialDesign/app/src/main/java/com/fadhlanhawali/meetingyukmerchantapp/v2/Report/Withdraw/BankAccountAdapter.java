package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Withdraw;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.DataItem;

import java.util.List;

public class BankAccountAdapter extends RecyclerView.Adapter<BankAccountAdapter.MyViewHolder> {

    private Context mContext;
    private List<DataItem> bankAccountList;

    int row_index = -1;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtBankAccount, txtBankAccountName, txtBankAccountNumber;
        LinearLayout linearLayout;
        public MyViewHolder(final View view) {
            super(view);
            txtBankAccount = view.findViewById(R.id.txtBankAccount);
            txtBankAccountName = view.findViewById(R.id.txtBankAccountName);
            txtBankAccountNumber = view.findViewById(R.id.txtBankAccountNumber);
            linearLayout = view.findViewById(R.id.linearLayout);
        }

    }


    public BankAccountAdapter(Context mContext, List<DataItem> bankAccountList ) {
        this.mContext = mContext;
        this.bankAccountList = bankAccountList;
    }

    @Override
    public BankAccountAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_payment_withdraw, parent, false);

        return new BankAccountAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final BankAccountAdapter.MyViewHolder holder, final int position) {
        final DataItem bankAccount = bankAccountList.get(position);
        holder.txtBankAccount.setText(bankAccount.getBankName());
        holder.txtBankAccountName.setText(bankAccount.getAccountName());
        holder.txtBankAccountNumber.setText(bankAccount.getAccountNumber());

        holder.linearLayout.setOnClickListener(view -> {
            row_index = position;
            notifyDataSetChanged();
        });

        if(row_index==position){
            Intent intent = new Intent("withdrawService");
            //            intent.putExtra("quantity",Integer.parseInt(quantity.getText().toString()));
            intent.putExtra("bankNumberWithdrawId",bankAccount.getId());
            LocalBroadcastManager.getInstance(mContext).sendBroadcast(intent);

            holder.txtBankAccount.setTextColor(ContextCompat.getColor(mContext,R.color.white));
            holder.txtBankAccountNumber.setTextColor(ContextCompat.getColor(mContext,R.color.white));
            holder.txtBankAccountName.setTextColor(ContextCompat.getColor(mContext,R.color.white));
            holder.linearLayout.setBackground(mContext.getDrawable(R.drawable.color_gradient_1));
        }
        else
        {
            holder.txtBankAccount.setTextColor(Color.parseColor("#000000"));
            holder.txtBankAccountNumber.setTextColor(Color.parseColor("#000000"));
            holder.txtBankAccountName.setTextColor(Color.parseColor("#000000"));
            holder.linearLayout.setBackgroundColor(Color.parseColor("#ffffff"));
        }
    }

    @Override
    public int getItemCount() {
        return bankAccountList.size();
    }
}