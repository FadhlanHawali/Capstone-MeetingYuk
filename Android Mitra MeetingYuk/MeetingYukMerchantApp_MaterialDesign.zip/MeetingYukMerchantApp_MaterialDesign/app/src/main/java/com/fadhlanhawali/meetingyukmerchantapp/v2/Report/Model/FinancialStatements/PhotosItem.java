package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class PhotosItem{

	@SerializedName("_id")
	private String id;

	@SerializedName("url")
	private String url;

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setUrl(String url){
		this.url = url;
	}

	public String getUrl(){
		return url;
	}

	@Override
 	public String toString(){
		return 
			"PhotosItem{" + 
			"_id = '" + id + '\'' + 
			",url = '" + url + '\'' + 
			"}";
		}
}