package com.fadhlanhawali.meetingyukmerchantapp.v2.Order;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.OnProgressListener;
import com.downloader.OnStartOrResumeListener;
import com.downloader.PRDownloader;
import com.downloader.PRDownloaderConfig;
import com.downloader.Progress;
import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.ChatActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.GetListRoomChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.AppDatabase;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ListRoomChatDao;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Order.Model.ItemItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ConvertDate;
import com.fadhlanhawali.meetingyukmerchantapp.MainActivity;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Order.Model.Order;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Order.Model.OrderDetailResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewDialog;

import java.util.HashMap;
import java.util.List;

public class OrderActivity extends AppCompatActivity implements OrderContract.vStatusOrder{

    OrderContract.pStatusOrder mPresenter;
    Button btnAccept, btnDecline;
    Intent i;
    SessionManager sessionManager;
    HashMap<String, String> user;
    RecyclerView recyclerView;
    ImageView imgOrderMeeting,ivCall,ivChat,ivInvoice,ivNavigateBack;
    TextView txtOrderMeeting,
            txtOrderStartHour,
            txtOrderEndHour,
            txtOrderStartDay,
            txtTotalHarga,
            txtOrderStatus,
            tvUserContact;
    ConvertDate convertDate;
    OrderAdapter orderAdapter;
    ViewDialog viewDialog;
    Order order;
    OrderDetailResponse orderDetailResponse;
    ListRoomChatDao listRoomChatDao;
    private AppDatabase mdB;
    private String idRoom, userId, userContact = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_pesanan);
        i = getIntent();
        mdB = AppDatabase.getDatabase(this);
        listRoomChatDao = mdB.listRoomChatDao();

        mPresenter = new OrderPresenter(this, this,listRoomChatDao);
        sessionManager = new SessionManager(getApplicationContext());
        user = sessionManager.getUserDetails();
        convertDate = new ConvertDate();
        mPresenter.initP();
    }

    @Override
    public void initV() {
        viewDialog = new ViewDialog(this);
        recyclerView = findViewById(R.id.recyclerView);
        btnAccept = findViewById(R.id.btnKonfirmasi);
        btnDecline = findViewById(R.id.btnTolakKonfirmasi);
        txtOrderMeeting = findViewById(R.id.txtOrderMeetingName);
        txtOrderStartDay = findViewById(R.id.txtOrderStartDay);
        txtOrderStartHour = findViewById(R.id.txtOrderStartHour);
        txtOrderEndHour = findViewById(R.id.txtOrderEndHour);
        tvUserContact = findViewById(R.id.tvUserContact);
        imgOrderMeeting = findViewById(R.id.imgOrderMeeting);
        ivNavigateBack = findViewById(R.id.ivNavigateBack);
        ivCall = findViewById(R.id.ivCall);
        ivChat = findViewById(R.id.ivChat);
        ivInvoice = findViewById(R.id.ivInvoice);
        txtTotalHarga = findViewById(R.id.txtTotalHarga);
        txtOrderStatus = findViewById(R.id.txtOrderStatus);

        orderAdapter = new OrderAdapter(this);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this,1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(orderAdapter);

        PRDownloaderConfig config = PRDownloaderConfig.newBuilder()
                .setDatabaseEnabled(true)
                .setReadTimeout(30_000)
                .setConnectTimeout(30_000)
                .build();

        PRDownloader.initialize(getApplicationContext(), config);

        String idOrder = i.getStringExtra("idOrder");

        ivInvoice.setOnClickListener(view -> {
            Toast.makeText(this, "Download sedang berjalan", Toast.LENGTH_SHORT).show();
            String myPdfUrl = "https://api.meetingyuk.com/merchant/order/invoice/"+idOrder+"/token/"+user.get(SessionManager.KEY_TOKEN)+"/invoice.pdf";
            Uri uri = Uri.parse(myPdfUrl);
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE | DownloadManager.Request.NETWORK_WIFI);  // Tell on which network you want to download file.
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);  // This will show notification on top when downloading the file.
            request.setTitle("Invoice-MeetingYukMerchant-"+idOrder+".pdf"); // Title for notification.
            request.setVisibleInDownloadsUi(true);
            request.setDescription("Invoice-MeetingYukMerchant-"+idOrder+".pdf");
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Invoice-MeetingYukMerchant-"+idOrder+".pdf");  // Storage directory path
            ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(request); // This will start downloading

        });


//        ArrayList<DataItem> dataItems = i.getParcelableArrayListExtra("order");
//        onViewOrder(dataItems);

//        Toast.makeText(this, "ID ORDER : " + idOrder, Toast.LENGTH_SHORT).show();
        viewDialog.showDialog();
        mPresenter.doGetDetailOrder(user.get(SessionManager.KEY_TOKEN),idOrder);


        btnAccept.setOnClickListener(v ->
                mPresenter.doAcceptOrder(user.get(SessionManager.KEY_TOKEN),idOrder)
        );
        btnDecline.setOnClickListener(v ->
                mPresenter.doDeclineOrder(user.get(SessionManager.KEY_TOKEN), idOrder)
        );

        ivNavigateBack.setOnClickListener(view -> {
            finish();
        });
    }

    @Override
    public void onDetailOrderResult(Boolean result, int code, OrderDetailResponse orderDetailResponse) {
        if (result){
            viewDialog.hideDialog();
            String strOrderStartDay, strOrderStartHour, strOrderEndHour, strRangeDate;
            this.orderDetailResponse = orderDetailResponse;
            order = orderDetailResponse.getData().get(0).getOrder();
            strOrderStartDay = convertDate.convertComplete(order.getTimeStart());
            strOrderStartHour = convertDate.convertTime(order.getTimeStart());
            strOrderEndHour = convertDate.convertTime(order.getTimeEnd());
            strRangeDate = convertDate.converRangeDate(order.getOrderDate());

//            Toast.makeText(this, "Result : "  + orderDetailResponse, Toast.LENGTH_SHORT).show();
            Glide.with(this).load(order.getMeetingPhoto()).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imgOrderMeeting);
            txtOrderStartDay.setText(strOrderStartDay);
            txtOrderStartHour.setText(strOrderStartHour);
            txtOrderEndHour.setText(strOrderEndHour);
            txtOrderMeeting.setText(order.getMeetingName());
            txtTotalHarga.setText(String.valueOf(order.getCost()));
            checkStatus(order.getStatus(),txtOrderStatus);
            userId = order.getContact().getIdUser();
            userContact = order.getContact().getName();
            tvUserContact.setText(userContact);

            if(order.getContact().getIdUser().equals(user.get(SessionManager.KEY_IDMERCHANT))){
                ivChat.setVisibility(View.INVISIBLE);
                ivCall.setVisibility(View.INVISIBLE);
            }

            ivCall.setOnClickListener(view -> {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + order.getContact().getPhoneNumber()));
                startActivity(intent);
            });

            ivChat.setOnClickListener(view -> {
                viewDialog.showDialog();
                mPresenter.initChatRoom(new InitChatRoomRequestModel(
                        user.get(SessionManager.KEY_IDMERCHANT),
                        userId
                ));
            });

//            Log.d("Item Icon URL : ", orderDetailResponse.getData().get(0).getItem().get(0).getItemIcon());

            mPresenter.getServiceList(user.get(SessionManager.KEY_TOKEN));

        }else {
            viewDialog.hideDialog();
            Toast.makeText(this, "Terjadi kesalahan, silahkan coba lagi ! "+ code, Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    @Override
    public void onAcceptOrderResult(Boolean result, int code) {
        if (result){
            Intent i = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(i);
        }else {
            Toast.makeText(this, "Error : " + code, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onInitChatRoom(Boolean result, int code, InitChatRoomResponseModel initChatRoomResponseModel) {
        if(result){
            this.idRoom = initChatRoomResponseModel.getData().getId();
            mPresenter.getListRoomChat(user.get(SessionManager.KEY_IDMERCHANT));
        }else {
            viewDialog.hideDialog();
            Toast.makeText(this, "Terjadi kesalahan, silahkan coba lagi !", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDeclineOrderResult(Boolean result, int code) {
        if (result){
            Intent i = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(i);
        }else {
            Toast.makeText(this, "Error : " + code, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onGetListRoomChatResult(Boolean result, int code, GetListRoomChatResponseModel getListRoomChatResponseModel) {
        mPresenter.dbInsertListRoomChat(getListRoomChatResponseModel);
        viewDialog.hideDialog();
        Intent i = new Intent(this, ChatActivity.class);
        i.putExtra("idRoom", idRoom);
        i.putExtra("toUserId", userId);
        i.putExtra("senderName",userContact);
        startActivity(i);
    }

    @Override
    public void onGetServiceListResult(Boolean result, int code, ListServiceResponse listServiceResponse) {
        List<ItemItem> item = urlServiceIconChanger(listServiceResponse,orderDetailResponse.getData().get(0).getItem());
        orderAdapter.setOrderList(item);
    }

    private List<ItemItem> urlServiceIconChanger(ListServiceResponse listServiceResponse, List<ItemItem> serviceItems){

        HashMap<String,String> serviceIconUrl = new HashMap<>();
        for(int i = 0;i<listServiceResponse.getData().size();i++){
            Log.d("List Service : ", listServiceResponse.getData().get(i).getId());
            serviceIconUrl.put(listServiceResponse.getData().get(i).getId(),listServiceResponse.getData().get(i).getPhotos().get(0).getUrl());
        }

        for(int i = 0;i<serviceItems.size();i++){
            Log.d("Service Items : ", serviceIconUrl.get(serviceItems.get(i).getIdService()));
            serviceItems.get(i).setItemIcon(serviceIconUrl.get(serviceItems.get(i).getIdService()));
        }

        return serviceItems;
    }

    private void checkStatus(String status, TextView textView){
        int color = 0;
        String statusFinal = "";
        if(status.equals(BuildConfig.ORDER_STATUS_WAITING)){
            statusFinal = "Menunggu Konfirmasi";
            color = getResources().getColor(R.color.order_status_waiting);
        }else if(status.equals(BuildConfig.ORDER_STATUS_ACCEPTED)){
            statusFinal = "Pesanan Disetujui";
            color = getResources().getColor(R.color.order_status_accepted);
        }else if(status.equals(BuildConfig.ORDER_STATUS_REJECTED)){
            statusFinal = "Pesanan Ditolak";
            color = getResources().getColor(R.color.order_status_rejected);
        }else if(status.equals(BuildConfig.ORDER_STATUS_PAYMENT_PROCESS)){
            statusFinal = "Proses Pembayaran";
            color = getResources().getColor(R.color.order_status_payment_process);
        }else if(status.equals(BuildConfig.ORDER_STATUS_PAYMENT_SUCCESS)){
            statusFinal = "Pembayaran Berhasil";
            color = getResources().getColor(R.color.order_status_payment_success);
        }else if(status.equals(BuildConfig.ORDER_STATUS_PAYMENT_FAILED)){
            statusFinal = "Pembayaran Gagal";
            color = getResources().getColor(R.color.order_status_payment_failed);
        }else if(status.equals(BuildConfig.ORDER_STATUS_PAYMENT_EXPIRED)){
            statusFinal = "Pembayaran Kadaluarsa";
            color = getResources().getColor(R.color.order_status_payment_expired);
        }else if(status.equals(BuildConfig.ORDER_STATUS_FINISH_SUCCESS)){
            statusFinal = "Pesanan Selesai";
            color = getResources().getColor(R.color.order_status_finish_success);
        }else if(status.equals(BuildConfig.ORDER_STATUS_FINISH_REFUND)){
            statusFinal = "Pengembalian Uang";
            color = getResources().getColor(R.color.order_status_finish_refund);
        }else if(status.equals(BuildConfig.ORDER_STATUS_CANCEL_BY_USER)){
            statusFinal = "Dibatalkan Pemesan";
            color = getResources().getColor(R.color.order_status_cancel_by_user);
        }
        textView.setText(statusFinal);
        textView.setTextColor(color);
    }

}
