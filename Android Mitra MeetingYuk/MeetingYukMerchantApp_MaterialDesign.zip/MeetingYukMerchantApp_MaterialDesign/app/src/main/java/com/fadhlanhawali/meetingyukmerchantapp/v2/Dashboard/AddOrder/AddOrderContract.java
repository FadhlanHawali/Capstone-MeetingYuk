package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.AddOrder;

import com.fadhlanhawali.meetingyukmerchantapp.v2.BasePresenter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.BaseView;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.AddOrderRequest.AddOrderRequest;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.ServiceAdapter;

public class AddOrderContract {
    interface View extends BaseView {
        void initV();

        void onGetServiceList(Boolean result, int code, ListServiceResponse listServiceResponse);

        void onAddOrder(Boolean result, int code);
    }

    interface Presenter extends BasePresenter {
        void initP();

        void addOrder(String token, AddOrderRequest addOrderRequest);

        void getServiceList(String token);
    }

}
