package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting;

import android.content.Context;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.APIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.InterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.UploadFileServiceModel.UploadFileServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.GetAdmin.GetAdminResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.EditProfile.EditProfileRequest;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SettingPresenter implements SettingContract.pSetting {
    private final Context mContext;
    SettingContract.vSetting mView;
    private InterfaceAPI serviceAPI;

    public SettingPresenter(Context context, SettingContract.vSetting mView) {
        this.mContext = context;
        this.mView = mView;
    }
    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void doGetSession(SessionManager sessionManager) {
        
    }

    @Override
    public void getAdminList(String token) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.getAdmin(token).enqueue(new Callback<GetAdminResponseModel>() {
            @Override
            public void onResponse(Call<GetAdminResponseModel> call, Response<GetAdminResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onGetAdminResult(response.body(),true,response.code());
                }else {
                    mView.onGetAdminResult(response.body(), false,response.code());
                }
            }

            @Override
            public void onFailure(Call<GetAdminResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void deleteAdmin(String token, String adminEmail) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.deleteAdmin(token, adminEmail).enqueue(new Callback<GeneralResponseModel>() {
            @Override
            public void onResponse(Call<GeneralResponseModel> call, Response<GeneralResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onDeleteAdminResult(response.body(),true,response.code());
                }else {
                    mView.onDeleteAdminResult(null,false,response.code());
                }
            }

            @Override
            public void onFailure(Call<GeneralResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void doUploadFile(MultipartBody.Part body) {
        serviceAPI = APIUtils.getAPIService();
        serviceAPI.uploadFileService(body).enqueue(new Callback<UploadFileServiceResponseModel>() {
            @Override
            public void onResponse(Call<UploadFileServiceResponseModel> call, Response<UploadFileServiceResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onUploadFileResult(true, response.code(), response.body());
                }else {
                    mView.onUploadFileResult(false, response.code(), response.body());
                }
            }

            @Override
            public void onFailure(Call<UploadFileServiceResponseModel> call, Throwable t) {
                Toast.makeText(mContext,"ERROR : " + t.getMessage(),Toast.LENGTH_SHORT).show();
                mView.onUploadFileResult(false,0,null);
            }
        });
    }

    @Override
    public void doEditProfile(EditProfileRequest editProfileRequest, String token) {
        serviceAPI =APIUtils.getAPIService();
        serviceAPI.editProfile(token, editProfileRequest).enqueue(new Callback<GeneralResponseModel>() {
            @Override
            public void onResponse(Call<GeneralResponseModel> call, Response<GeneralResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onEditProfileResult(response.body(),true,response.code());
                }else {
                    mView.onEditProfileResult(null,false,response.code());
                }
            }

            @Override
            public void onFailure(Call<GeneralResponseModel> call, Throwable t) {
                mView.onEditProfileResult(null,false,0);
            }
        });
    }
}
