package com.fadhlanhawali.meetingyukmerchantapp.v2;

import android.view.View;

public interface BasePresenter {

    void checkConnectivity();
}
