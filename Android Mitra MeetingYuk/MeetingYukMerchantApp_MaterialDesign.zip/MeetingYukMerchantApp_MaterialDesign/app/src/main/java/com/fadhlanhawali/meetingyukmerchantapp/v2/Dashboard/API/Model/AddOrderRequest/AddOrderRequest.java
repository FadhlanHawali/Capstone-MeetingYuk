package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.AddOrderRequest;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class AddOrderRequest{

	@SerializedName("item")
	private List<ItemItem> item;

	@SerializedName("time_start")
	private long timeStart;

	@SerializedName("time_end")
	private long timeEnd;

	@SerializedName("meeting_name")
	private String meetingName;

	public AddOrderRequest(List<ItemItem> item, long timeStart, long timeEnd, String meetingName) {
		this.item = item;
		this.timeStart = timeStart;
		this.timeEnd = timeEnd;
		this.meetingName = meetingName;
	}

	public void setItem(List<ItemItem> item){
		this.item = item;
	}

	public List<ItemItem> getItem(){
		return item;
	}

	public void setTimeStart(long timeStart){
		this.timeStart = timeStart;
	}

	public long getTimeStart(){
		return timeStart;
	}

	public void setTimeEnd(long timeEnd){
		this.timeEnd = timeEnd;
	}

	public long getTimeEnd(){
		return timeEnd;
	}

	public void setMeetingName(String meetingName){
		this.meetingName = meetingName;
	}

	public String getMeetingName(){
		return meetingName;
	}

	@Override
 	public String toString(){
		return 
			"AddOrderRequest{" + 
			"item = '" + item + '\'' + 
			",time_start = '" + timeStart + '\'' + 
			",time_end = '" + timeEnd + '\'' + 
			",meeting_name = '" + meetingName + '\'' + 
			"}";
		}
}