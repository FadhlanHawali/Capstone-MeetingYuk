package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Data{

	@SerializedName("member")
	private String member;

	@SerializedName("lastMessageTimestamp")
	private long lastMessageTimestamp;

	@SerializedName("lastMessageText")
	private String lastMessageText;

	@SerializedName("_id")
	private String id;

	@SerializedName("lastMessageId")
	private String lastMessageId;

	@SerializedName("roomType")
	private String roomType;

	public void setMember(String member){
		this.member = member;
	}

	public String getMember(){
		return member;
	}

	public void setLastMessageTimestamp(long lastMessageTimestamp){
		this.lastMessageTimestamp = lastMessageTimestamp;
	}

	public long getLastMessageTimestamp(){
		return lastMessageTimestamp;
	}

	public void setLastMessageText(String lastMessageText){
		this.lastMessageText = lastMessageText;
	}

	public String getLastMessageText(){
		return lastMessageText;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setLastMessageId(String lastMessageId){
		this.lastMessageId = lastMessageId;
	}

	public String getLastMessageId(){
		return lastMessageId;
	}

	public void setRoomType(String roomType){
		this.roomType = roomType;
	}

	public String getRoomType(){
		return roomType;
	}

	@Override
 	public String toString(){
		return 
			"Data{" + 
			"member = '" + member + '\'' + 
			",lastMessageTimestamp = '" + lastMessageTimestamp + '\'' + 
			",lastMessageText = '" + lastMessageText + '\'' + 
			",_id = '" + id + '\'' + 
			",lastMessageId = '" + lastMessageId + '\'' + 
			",roomType = '" + roomType + '\'' + 
			"}";
		}
}