package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.UploadFileServiceModel;

public class Data{
	private String url;

	public void setUrl(String url){
		this.url = url;
	}

	public String getUrl(){
		return url;
	}

	@Override
 	public String toString(){
		return 
			"Data{" + 
			"url = '" + url + '\'' + 
			"}";
		}
}
