package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ConvertDate;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem;

import java.util.ArrayList;
import java.util.List;

public class ChatAdapterv2 extends RecyclerView.Adapter {
    private static final int VIEW_TYPE_MESSAGE_SENT = 1;
    private static final int VIEW_TYPE_MESSAGE_RECEIVED = 2;
    private static final String CHAT_TYPE_TEXT = "text";

    private Context mContext;
    private List<DataItem> mMessageList = new ArrayList<>();
    private String idMerchant;

    public ChatAdapterv2(Context context, String idMerchant) {
        mContext = context;
        this.idMerchant = idMerchant;
    }

    @Override
    public int getItemCount() {
        return mMessageList.size();
    }

    // Determines the appropriate ViewType according to the sender of the message.
    @Override
    public int getItemViewType(int position) {
        String fromUserId = mMessageList.get(position).getFromUserId();
        if(isMyMessage(idMerchant,fromUserId)){
            return VIEW_TYPE_MESSAGE_SENT;
        }else {
            return VIEW_TYPE_MESSAGE_RECEIVED;
        }

    }

    // Inflates the appropriate layout according to the ViewType.
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;

        if (viewType == VIEW_TYPE_MESSAGE_SENT) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_message_sent, parent, false);
            return new SentMessageHolder(view);
        } else if (viewType == VIEW_TYPE_MESSAGE_RECEIVED) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_message_received, parent, false);
            return new ReceivedMessageHolder(view);
        }

        return null;
    }

    // Passes the message object to a ViewHolder so that the contents can be bound to UI.
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_MESSAGE_SENT:
                ((SentMessageHolder) holder).bind(mMessageList.get(position));
                break;
            case VIEW_TYPE_MESSAGE_RECEIVED:
                ((ReceivedMessageHolder) holder).bind(mMessageList.get(position));
        }
    }

    private class SentMessageHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText;
        ConvertDate convertDate = new ConvertDate();

        SentMessageHolder(View itemView) {
            super(itemView);

            messageText = itemView.findViewById(R.id.text_message_body);
            timeText = itemView.findViewById(R.id.text_message_time);
        }


        void bind(DataItem mChat) {
            messageText.setText(mChat.getText());
            // Format the stored timestamp into a readable String using method.
            timeText.setText(convertDate.convertTime(mChat.getTimestamp()));
        }
    }

    private class ReceivedMessageHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText, nameText;
        ImageView profileImage;
        ConvertDate convertDate = new ConvertDate();

        ReceivedMessageHolder(View itemView) {
            super(itemView);

            messageText = itemView.findViewById(R.id.text_message_body);
            timeText = itemView.findViewById(R.id.text_message_time);
            nameText = itemView.findViewById(R.id.text_message_name);
            profileImage = itemView.findViewById(R.id.image_message_profile);
        }

        void bind(DataItem mChat) {
            messageText.setText(mChat.getText());

            // Format the stored timestamp into a readable String using method.
            timeText.setText(convertDate.convertTime(mChat.getTimestamp()));

            nameText.setText(mChat.getFromName());
            Glide.with(mContext).load("https://" + mChat.getFromUserAvatarUrl()).apply(new RequestOptions().centerCrop().placeholder(R.drawable.ic_person)).into(profileImage);
        }
    }

    boolean isMyMessage(String idMerchant, String fromUserId){

        Log.d("STATUS IS MY MESSAGE : ", String.valueOf(idMerchant.equals(fromUserId)));
        return idMerchant.equals(fromUserId);
    }

    public void setmMessageList(List<DataItem> mMessageList) {
        this.mMessageList = mMessageList;
        notifyDataSetChanged();
    }

    public List<DataItem> getmMessageList() {
        return mMessageList;
    }
}
