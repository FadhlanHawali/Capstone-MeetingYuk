package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class InitChatRoomResponseModel {

	@SerializedName("data")
	private Data data;

	@SerializedName("success")
	private boolean success;

	public void setData(Data data){
		this.data = data;
	}

	public Data getData(){
		return data;
	}

	public void setSuccess(boolean success){
		this.success = success;
	}

	public boolean isSuccess(){
		return success;
	}

	@Override
 	public String toString(){
		return 
			"InitChatRoomResponseModel{" +
			"data = '" + data + '\'' + 
			",success = '" + success + '\'' + 
			"}";
		}
}