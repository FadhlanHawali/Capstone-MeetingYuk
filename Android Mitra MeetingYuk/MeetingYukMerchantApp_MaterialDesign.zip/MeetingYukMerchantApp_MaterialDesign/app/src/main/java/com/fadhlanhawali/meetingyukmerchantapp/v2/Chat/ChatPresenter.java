package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.fadhlanhawali.meetingyukmerchantapp.v2.API.ChatAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.ChatInterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.GetChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.Data;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat.SendChatRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat.SendChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ChatDao;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatPresenter implements ChatContract.pChat {

    ChatInterfaceAPI interfaceAPI;
    ChatContract.vChat mView;
    Context mContext;
    ChatDao chatDao;

    public ChatPresenter(ChatContract.vChat mView, Context mContext, ChatDao chatDao) {
        this.mView = mView;
        this.mContext = mContext;
        this.chatDao = chatDao;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void initChatRoom(InitChatRoomRequestModel initChatRoomRequestModel) {
        interfaceAPI = ChatAPIUtils.getChatService();
        interfaceAPI.initChatRoom(initChatRoomRequestModel).enqueue(new Callback<InitChatRoomResponseModel>() {
            @Override
            public void onResponse(Call<InitChatRoomResponseModel> call, Response<InitChatRoomResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onInitChatRoom(true,response.code(),response.body());
                }else {
                    mView.onInitChatRoom(false,response.code(),response.body());
                }
            }

            @Override
            public void onFailure(Call<InitChatRoomResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void getChatLatest(String idRoom, String idUser) {
        interfaceAPI = ChatAPIUtils.getChatService();
        interfaceAPI.getChatLatest(idRoom,idUser).enqueue(new Callback<GetChatResponseModel>() {
            @Override
            public void onResponse(Call<GetChatResponseModel> call, Response<GetChatResponseModel> response) {
                if(response.isSuccessful()){
                   mView.onGetChatLatest(true,response.code(),response.body());
                }else {
                    mView.onGetChatLatest(false,response.code(),null);
                }
            }

            @Override
            public void onFailure(Call<GetChatResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void sendChat(SendChatRequestModel sendChatRequestModel) {
        interfaceAPI = ChatAPIUtils.getChatService();
        interfaceAPI.sendChat(sendChatRequestModel).enqueue(new Callback<SendChatResponseModel>() {
            @Override
            public void onResponse(Call<SendChatResponseModel> call, Response<SendChatResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onSendChatResponse(true, response.code(), response.body());
                }else {
                    mView.onSendChatResponse(false, response.code(), null);
                }
            }

            @Override
            public void onFailure(Call<SendChatResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void getChatBefore(String timestamp, String idRoom) {
        interfaceAPI = ChatAPIUtils.getChatService();
        interfaceAPI.getChatBeforeTimestamp(timestamp, idRoom).enqueue(new Callback<GetChatResponseModel>() {
            @Override
            public void onResponse(Call<GetChatResponseModel> call, Response<GetChatResponseModel> response) {
                Log.d("GET CHAT URL",call.request().url().toString());
                if(response.isSuccessful()){
                    mView.onGetChatBefore(true,response.code(), response.body());
                }else {
                    mView.onGetChatBefore(false,response.code(),response.body());
                }
            }

            @Override
            public void onFailure(Call<GetChatResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void readChat(String idMessage, String idUser) {
        interfaceAPI = ChatAPIUtils.getChatService();
        interfaceAPI.readChat(idMessage, idUser).enqueue(new Callback<GeneralResponseModel>() {
            @Override
            public void onResponse(Call<GeneralResponseModel> call, Response<GeneralResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onReadChatResponse(true, response.code(), response.body());
                }else {
                    mView.onReadChatResponse(false,response.code(), response.body());
                }
            }

            @Override
            public void onFailure(Call<GeneralResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void checkConnectivity() {
        ConnectivityManager cm =
                (ConnectivityManager)mContext.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

        mView.onCheckConnectivity(isConnected);
    }

    @Override
    public void dbInsertChat(SendChatRequestModel sendChatRequestModel) {
        chatDao.insertChat(new DataItem(
                sendChatRequestModel.getIdRoom(),
                sendChatRequestModel.getFromUserId(),
                "",
                sendChatRequestModel.getReferenceType(),
                sendChatRequestModel.getType(),
                "",
                sendChatRequestModel.getReferencedMessageId(),
                sendChatRequestModel.getMode(),
                0,
                "",
                "",
                sendChatRequestModel.getFileUrl(),
                sendChatRequestModel.isSendStatus(),
                sendChatRequestModel.getText(),
                "",
                System.currentTimeMillis()


        ));
    }

    @Override
    public void dbGetChat(String idRoom) {
        mView.onDBGetChat(chatDao.getChat(idRoom));
    }



    @Override
    public void dbInsertChatAll(GetChatResponseModel getChatResponseModel) {
        List<DataItem> chatResponse = getChatResponseModel.getData();
        for (int i = 0; i<chatResponse.size();i++){
            chatDao.insertChat(chatResponse.get(i));
        }
    }

    @Override
    public void dbDeleteChatAll() {
        chatDao.deleteAllChat();
    }
}
