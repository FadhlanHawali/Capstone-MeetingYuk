package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.AddAdmin.AddAdminRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.AddAdmin.AddAdminResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.GetAdmin.GetAdminResponseModel;

public interface AdminContract {
    interface vAdmin{
        void initV();
        void onAddAdminResult(AddAdminResponseModel addAdminResponseModel, Boolean result, int code);
    }

    interface pAdmin{
        void initP();
        void doAddAdmin(AddAdminRequestModel addAdminRequestModel, String token);

    }
}
