package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class WithdrawSaldoRequestModel{

	@SerializedName("bank_account_id")
	private String bankAccountId;

	@SerializedName("amount")
	private int amount;

	public void setBankAccountId(String bankAccountId){
		this.bankAccountId = bankAccountId;
	}

	public String getBankAccountId(){
		return bankAccountId;
	}

	public void setAmount(int amount){
		this.amount = amount;
	}

	public int getAmount(){
		return amount;
	}

	public WithdrawSaldoRequestModel(String bankAccountId, int amount) {
		this.bankAccountId = bankAccountId;
		this.amount = amount;
	}

	@Override
 	public String toString(){
		return 
			"WithdrawSaldoRequestModel{" + 
			"bank_account_id = '" + bankAccountId + '\'' + 
			",amount = '" + amount + '\'' + 
			"}";
		}
}