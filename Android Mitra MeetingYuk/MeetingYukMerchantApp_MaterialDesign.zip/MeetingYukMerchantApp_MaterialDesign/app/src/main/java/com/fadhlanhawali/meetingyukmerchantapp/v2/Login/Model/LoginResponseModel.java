package com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class LoginResponseModel{

	@SerializedName("data")
	private Data data;

	@SerializedName("success")
	private boolean success;

	@SerializedName("process_time")
	private String processTime;

	public void setData(Data data){
		this.data = data;
	}

	public Data getData(){
		return data;
	}

	public void setSuccess(boolean success){
		this.success = success;
	}

	public boolean isSuccess(){
		return success;
	}

	public void setProcessTime(String processTime){
		this.processTime = processTime;
	}

	public String getProcessTime(){
		return processTime;
	}

	@Override
 	public String toString(){
		return 
			"LoginResponseModel{" + 
			"data = '" + data + '\'' + 
			",success = '" + success + '\'' + 
			",process_time = '" + processTime + '\'' + 
			"}";
		}
}