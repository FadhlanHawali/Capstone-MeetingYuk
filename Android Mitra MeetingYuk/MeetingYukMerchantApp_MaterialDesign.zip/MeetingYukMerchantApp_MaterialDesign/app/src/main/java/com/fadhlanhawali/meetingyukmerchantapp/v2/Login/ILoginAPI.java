package com.fadhlanhawali.meetingyukmerchantapp.v2.Login;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginResponseModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ILoginAPI {
    @POST(BuildConfig.LOGIN_V2)
    Call<LoginResponseModel> loginPost(@Body LoginRequestModel loginRequestModel);


}
