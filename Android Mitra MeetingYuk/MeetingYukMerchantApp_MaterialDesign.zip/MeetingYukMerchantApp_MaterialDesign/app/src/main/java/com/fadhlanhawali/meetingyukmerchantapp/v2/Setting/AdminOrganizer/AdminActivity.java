package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer;

import android.Manifest;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.AddAdmin.AddAdminRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.AddAdmin.AddAdminResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.GetAdmin.GetAdminResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.Model.SignUpRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.SignupContract;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.SignupPresenter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Camera.CameraContract;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Camera.CameraPresenter;

import java.util.HashMap;

public class AdminActivity extends AppCompatActivity implements AdminContract.vAdmin {

    private AdminContract.pAdmin mPresenter;
    EditText etEmail, etPassword;
    Button btnAddAdmin;
    HashMap<String,String> user;
    SessionManager session;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_admin);
        mPresenter = new AdminPresenter(this,this);
        mPresenter.initP();

    }

    @Override
    public void initV() {
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnAddAdmin = findViewById(R.id.btnAddAdmin);
        session = new SessionManager(this);
        user = session.getUserDetails();

        btnAddAdmin.setOnClickListener(view -> {
            AddAdminRequestModel addAdminRequestModel = new AddAdminRequestModel(
                    etPassword.getText().toString(), etEmail.getText().toString()

            );
            mPresenter.doAddAdmin(addAdminRequestModel,user.get(SessionManager.KEY_TOKEN));
        });
    }

    @Override
    public void onAddAdminResult(AddAdminResponseModel addAdminResponseModel, Boolean result, int code) {
        if (result){
            Toast.makeText(this, "Sukses menambahkan admin !", Toast.LENGTH_SHORT).show();
            finish();
        }else {
            Toast.makeText(this, "Data yang anda masukkan tidak sesuai !", Toast.LENGTH_SHORT).show();
        }
    }

}
