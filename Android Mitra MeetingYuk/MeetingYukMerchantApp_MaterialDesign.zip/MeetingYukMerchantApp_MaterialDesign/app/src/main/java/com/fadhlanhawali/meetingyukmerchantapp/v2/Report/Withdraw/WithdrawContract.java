package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Withdraw;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.GetBankAccountResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoResponseModel;

public interface WithdrawContract {

    interface vWtihdraw{
        void initV();
        void onWithdrawResult(Boolean result, int code, WithdrawSaldoResponseModel withdrawSaldoResponseModel);
        void onBankAccountListResult(Boolean result, int coide, GetBankAccountResponseModel getBankAccountResponseModel);
    }

    interface pWithdraw{
        void initP();
        void doWithdraw(String token, WithdrawSaldoRequestModel withdrawSaldoRequestModel);
        void getBankAccountList (String token);
    }


}
