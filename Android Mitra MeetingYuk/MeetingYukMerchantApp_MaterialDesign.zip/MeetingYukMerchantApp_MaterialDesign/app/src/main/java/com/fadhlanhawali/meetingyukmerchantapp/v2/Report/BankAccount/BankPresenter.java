package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.BankAccount;

import android.content.Context;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.IReportAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Utils.ReportAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.AddBankAccountRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.AddBankAccountResponseModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BankPresenter implements BankContract.pBankAccount{

    private final Context mContext;
    private BankContract.vBankAccount mView;
    private IReportAPI reportAPI;

    public BankPresenter(Context context, BankContract.vBankAccount mView) {
        this.mContext = context;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void addBankAccount(String token, AddBankAccountRequestModel addBankAccountRequestModel) {
        reportAPI = ReportAPIUtils.getAPIService();
        reportAPI.addBankAccount(token,addBankAccountRequestModel).enqueue(new Callback<AddBankAccountResponseModel>() {
            @Override
            public void onResponse(Call<AddBankAccountResponseModel> call, Response<AddBankAccountResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onResultAddBankAccount(true, response.code(), response.body());
                } else {
                    mView.onResultAddBankAccount(false, response.code(),response.body());
                }
            }

            @Override
            public void onFailure(Call<AddBankAccountResponseModel> call, Throwable t) {

            }
        });
    }
}
