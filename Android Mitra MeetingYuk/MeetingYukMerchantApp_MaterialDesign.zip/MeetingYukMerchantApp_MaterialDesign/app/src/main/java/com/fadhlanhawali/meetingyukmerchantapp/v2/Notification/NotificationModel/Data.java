package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Data{

	@SerializedName("weburl")
	private String weburl;

	@SerializedName("param_data")
	private String paramData;

	@SerializedName("event")
	private String event;

	public void setWeburl(String weburl){
		this.weburl = weburl;
	}

	public String getWeburl(){
		return weburl;
	}

	public void setParamData(String paramData){
		this.paramData = paramData;
	}

	public String getParamData(){
		return paramData;
	}

	public void setEvent(String event){
		this.event = event;
	}

	public String getEvent(){
		return event;
	}

	@Override
 	public String toString(){
		return 
			"Data{" + 
			"weburl = '" + weburl + '\'' + 
			",param_data = '" + paramData + '\'' + 
			",event = '" + event + '\'' + 
			"}";
		}
}