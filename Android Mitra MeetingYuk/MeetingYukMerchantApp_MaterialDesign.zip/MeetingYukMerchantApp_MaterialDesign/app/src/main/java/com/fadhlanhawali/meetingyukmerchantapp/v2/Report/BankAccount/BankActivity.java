package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.BankAccount;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.AddBankAccountRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.AddBankAccountResponseModel;

import java.util.HashMap;

public class BankActivity extends AppCompatActivity implements BankContract.vBankAccount{

    SessionManager sessionManager;
    BankPresenter mPresenter;
    EditText etBankName,etBankAccountName,etBankAccountNumber;
    HashMap<String, String> user;
    Button btnSimpan;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bank);
        mPresenter = new BankPresenter(this,this);
        mPresenter.initP();
    }

    @Override
    public void initV() {
        sessionManager = new SessionManager(this);
        user = sessionManager.getUserDetails();
        etBankName = findViewById(R.id.etBankName);
        etBankAccountName = findViewById(R.id.etBankAccountName);
        etBankAccountNumber = findViewById(R.id.etBankAccountNumber);
        btnSimpan = findViewById(R.id.btnSimpan);
        btnSimpan.setOnClickListener(v -> {
            AddBankAccountRequestModel addBankAccountRequestModel =
                    new AddBankAccountRequestModel(
                            etBankName.getText().toString(),
                            etBankAccountName.getText().toString(),
                            etBankAccountNumber.getText().toString());
            mPresenter.addBankAccount(user.get(SessionManager.KEY_TOKEN),addBankAccountRequestModel);
        });
    }

    @Override
    public void onResultAddBankAccount(Boolean result, int code, AddBankAccountResponseModel addBankAccountResponseModel) {
        if (result){
            finish();
            Toast.makeText(this, "Sukses Menambah Akun !", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Data anda belum lengkap !", Toast.LENGTH_SHORT).show();
        }
    }
}