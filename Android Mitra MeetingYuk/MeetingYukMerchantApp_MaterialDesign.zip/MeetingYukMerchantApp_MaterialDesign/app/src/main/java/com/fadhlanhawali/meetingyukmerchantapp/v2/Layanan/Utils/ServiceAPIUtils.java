package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.Utils;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.RetrofitClient;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.IServiceAPI;

public class ServiceAPIUtils {
    public ServiceAPIUtils() {
    }

    public static IServiceAPI getAPIService() {
        return RetrofitClient.getClient(BuildConfig.API_BASE_URL).create(IServiceAPI.class);
    }
}
