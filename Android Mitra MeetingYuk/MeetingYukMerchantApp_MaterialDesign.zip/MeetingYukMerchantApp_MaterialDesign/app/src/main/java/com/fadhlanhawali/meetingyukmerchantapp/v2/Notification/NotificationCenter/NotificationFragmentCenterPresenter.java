package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationCenter;

import android.content.Context;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.IDashboardAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.Utils.DashboardAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.ILoginAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.LoginContract;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Notification.NotificationContract;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationFragmentCenterPresenter implements NotificationContract.pNotification {
    private final Context mContext;
    NotificationContract.vNotification mView;
    private IDashboardAPI dashboardAPI;
    SessionManager session;

    public NotificationFragmentCenterPresenter(Context context, NotificationContract.vNotification mView) {
        this.mContext = context;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void getWaitingOrder(String token) {
        dashboardAPI = DashboardAPIUtils.getAPIService();
        dashboardAPI.getOrderWaiting(token).enqueue(new Callback<OrderResponseModel>() {
            @Override
            public void onResponse(Call<OrderResponseModel> call, Response<OrderResponseModel> response) {
                if (response.isSuccessful()){
                    mView.onResult(true,response.code(),response.body());
                }else {
                    mView.onResult(false,response.code(),response.body());
                }
            }

            @Override
            public void onFailure(Call<OrderResponseModel> call, Throwable t) {

            }
        });
    }
}
