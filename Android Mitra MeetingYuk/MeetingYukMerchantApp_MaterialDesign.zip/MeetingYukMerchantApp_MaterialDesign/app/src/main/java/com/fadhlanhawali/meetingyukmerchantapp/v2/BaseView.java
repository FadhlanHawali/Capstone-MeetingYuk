package com.fadhlanhawali.meetingyukmerchantapp.v2;

import android.view.View;

public interface BaseView {

    void onCheckConnectivity(Boolean isConnected);
}
