package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan;

import android.content.Context;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.IServiceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.Utils.ServiceAPIUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ServicePresenter implements ServiceContract.pListService {

    private final Context mContext;
    ServiceContract.vListService mView;
    private IServiceAPI serviceAPI;

    public ServicePresenter(Context mContext, ServiceContract.vListService mView) {
        this.mContext = mContext;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void clear() {

    }

    @Override
    public void getServiceList(String token) {

        serviceAPI = ServiceAPIUtils.getAPIService();
//        String token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Indpc251QG1haWwuY29tIiwiaWQiOiJtZXItQ0NoZC1WZ0dtIiwiaWF0IjoxNTYxMTY0OTE0LCJleHAiOjE1NjM3NTY5MTR9.Vzbe1R1lScXCfZECAn0Cd5gSAaoSQqytSrUYXTYL48Y";
        serviceAPI.getServiceList(token).enqueue(new Callback<ListServiceResponse>() {
            @Override
            public void onResponse(Call<ListServiceResponse> call, Response<ListServiceResponse> response) {
                if (response.isSuccessful()) {
                    //dialog.create().dismiss();
                    mView.onResult(true,response.code(), response.body());
//                    Toast.makeText(mContext, "TOKEN : " + response.body(), Toast.LENGTH_SHORT).show();
                    // todo display the data instead of just a toast
                }
                else if (response.code() == 400){
                    //dialog.create().dismiss();
                    mView.onResult(false,response.code(), response.body());
                    Toast.makeText(mContext, "ERROR : " + response.body(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ListServiceResponse> call, Throwable t) {
                System.out.println("ERROR : " + t.getMessage());
                Toast.makeText(mContext, "ERROR : "+ t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }



}
