package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.AddOrderRequest;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class ItemItem{

	@SerializedName("qty")
	private int qty;

	@SerializedName("id_service")
	private String idService;

	public ItemItem(int qty, String idService) {
		this.qty = qty;
		this.idService = idService;
	}

	public void setQty(int qty){
		this.qty = qty;
	}

	public int getQty(){
		return qty;
	}

	public void setIdService(String idService){
		this.idService = idService;
	}

	public String getIdService(){
		return idService;
	}

	@Override
 	public String toString(){
		return 
			"ItemItem{" + 
			"qty = '" + qty + '\'' + 
			",id_service = '" + idService + '\'' + 
			"}";
		}
}