package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.Utils;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.IDashboardAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.RetrofitClient;

public class DashboardAPIUtils {
    public DashboardAPIUtils() {
    }

    public static IDashboardAPI getAPIService() {
        return RetrofitClient.getClient(BuildConfig.API_BASE_URL).create(IDashboardAPI.class);
    }
}
