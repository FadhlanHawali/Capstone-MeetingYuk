package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterResponseModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class DataItem{

	@SerializedName("meeting_photo")
	private String meetingPhoto;

	@SerializedName("cost")
	private int cost;

	@SerializedName("time_start")
	private long timeStart;

	@SerializedName("payment_status")
	private boolean paymentStatus;

	@SerializedName("id_meeting")
	private String idMeeting;

	@SerializedName("id_merchant")
	private String idMerchant;

	@SerializedName("order_date")
	private long orderDate;

	@SerializedName("contact")
	private Contact contact;

	@SerializedName("__v")
	private int V;

	@SerializedName("guest")
	private int guest;

	@SerializedName("_id")
	private String _id;

	@SerializedName("id")
	private String id;

	@SerializedName("meeting_name")
	private String meetingName;

	@SerializedName("time_end")
	private long timeEnd;

	@SerializedName("status")
	private String status;

	public void setMeetingPhoto(String meetingPhoto){
		this.meetingPhoto = meetingPhoto;
	}

	public String getMeetingPhoto(){
		return meetingPhoto;
	}

	public void setCost(int cost){
		this.cost = cost;
	}

	public int getCost(){
		return cost;
	}

	public void setTimeStart(long timeStart){
		this.timeStart = timeStart;
	}

	public long getTimeStart(){
		return timeStart;
	}

	public void setPaymentStatus(boolean paymentStatus){
		this.paymentStatus = paymentStatus;
	}

	public boolean isPaymentStatus(){
		return paymentStatus;
	}

	public void setIdMeeting(String idMeeting){
		this.idMeeting = idMeeting;
	}

	public String getIdMeeting(){
		return idMeeting;
	}

	public void setIdMerchant(String idMerchant){
		this.idMerchant = idMerchant;
	}

	public String getIdMerchant(){
		return idMerchant;
	}

	public void setOrderDate(long orderDate){
		this.orderDate = orderDate;
	}

	public long getOrderDate(){
		return orderDate;
	}

	public void setContact(Contact contact){
		this.contact = contact;
	}

	public Contact getContact(){
		return contact;
	}

	public void setV(int V){
		this.V = V;
	}

	public int getV(){
		return V;
	}

	public void setGuest(int guest){
		this.guest = guest;
	}

	public int getGuest(){
		return guest;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setMeetingName(String meetingName){
		this.meetingName = meetingName;
	}

	public String getMeetingName(){
		return meetingName;
	}

	public void setTimeEnd(long timeEnd){
		this.timeEnd = timeEnd;
	}

	public long getTimeEnd(){
		return timeEnd;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"meeting_photo = '" + meetingPhoto + '\'' + 
			",cost = '" + cost + '\'' + 
			",time_start = '" + timeStart + '\'' + 
			",payment_status = '" + paymentStatus + '\'' + 
			",id_meeting = '" + idMeeting + '\'' + 
			",id_merchant = '" + idMerchant + '\'' + 
			",order_date = '" + orderDate + '\'' + 
			",contact = '" + contact + '\'' + 
			",__v = '" + V + '\'' + 
			",guest = '" + guest + '\'' + 
			",_id = '" + id + '\'' + 
			",meeting_name = '" + meetingName + '\'' + 
			",time_end = '" + timeEnd + '\'' + 
			",id = '" + id + '\'' + 
			",status = '" + status + '\'' + 
			"}";
		}
}