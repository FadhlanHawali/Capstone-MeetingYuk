package com.fadhlanhawali.meetingyukmerchantapp.v2.Login;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.MainActivity;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.Profile;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Utils.LoginAPIUtils;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginPresenter implements LoginContract.Presenter {
    private final Context mContext;
    LoginContract.View mView;
    private ILoginAPI loginAPI;
    SessionManager session;

    public LoginPresenter(Context context, LoginContract.View mView) {
        this.mContext = context;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void doLogin(final LoginRequestModel loginRequestModel, final SessionManager sessionManager) {
        Log.d("STATUS JALAN : ", "JALAN");
        loginAPI = LoginAPIUtils.getAPIService();
        loginAPI.loginPost(loginRequestModel).enqueue(new Callback<LoginResponseModel>() {
            @Override
            public void onResponse(Call<LoginResponseModel> call, Response<LoginResponseModel> response) {
                if (response.isSuccessful()) {
                    mView.onLoginResult(true, response.code(), response.body());

                }else {
                    mView.onLoginResult(false, response.code(),response.body());
                }
            }

            @Override
            public void onFailure(Call<LoginResponseModel> call, Throwable t) {
                mView.onLoginResult(false,0,null);
            }
        });
    }

    @Override
    public void setProgressBarVisiblity(int visiblity) {

    }

}
