package com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;


import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem;

import java.util.List;

import static androidx.room.OnConflictStrategy.IGNORE;

@Dao
public interface ChatDao {

    @Query("SELECT * FROM chat WHERE idRoom=:idRoom ORDER BY timestamp ASC")
    List<DataItem> getChat(String idRoom);

    @Insert(onConflict = IGNORE)
    void insertChat(DataItem chat);

    @Query("DELETE FROM chat")
    void deleteAllChat();

//    @Query("SELECT * FROM chat WHERE id=:idChat")
//    Chat findChat(String idRoom);

    @Delete
    void deleteChat(DataItem chat);

}
