package com.fadhlanhawali.meetingyukmerchantapp.v2.Login;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.fadhlanhawali.meetingyukmerchantapp.MainActivity;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.Profile;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.SignupActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewDialog;

public class LoginActivity extends AppCompatActivity implements LoginContract.View {

    private LoginContract.Presenter mPresenter;
    private RecyclerView recyclerview;
    private TextView txtEmail,txtPassword;
    private ProgressBar progressBar;
    private LoginRequestModel loginRequestModel;

    LayoutInflater inflater;
    ViewDialog viewDialog;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mPresenter = new LoginPresenter(this, this);
        loginRequestModel = new LoginRequestModel();
        mPresenter.initP();
    }

    @Override
    public void initV() {
        viewDialog = new ViewDialog(this);
        txtEmail = findViewById(R.id.txtEmail);
        txtPassword = findViewById(R.id.txtPassword);
        progressBar = findViewById(R.id.pbHeaderProgress);

        findViewById(R.id.login).setOnClickListener(v -> {
            final String email = txtEmail.getText().toString();
            final String password = txtPassword.getText().toString();
            loginRequestModel.setEmail(email);
            loginRequestModel.setPassword(password);
            inflater = getLayoutInflater();
            sessionManager = new SessionManager(getApplicationContext());
            Log.d("LOGIN REQ", loginRequestModel.toString());
            mPresenter.doLogin(loginRequestModel,sessionManager);
            viewDialog.showDialog();
        });
        findViewById(R.id.signUp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), SignupActivity.class);
                startActivity(i);
            }
        });
    }



    @Override
    public void onLoginResult(Boolean result, int code, LoginResponseModel loginResponseModel) {
        if (result){
            viewDialog.hideDialog();
            Profile profile = loginResponseModel.getData().getProfile();
            String urlPhoto = profile.getUrlFoto();
            if (!urlPhoto.contains("https://")){
                urlPhoto = "https://" + urlPhoto;
            }
            sessionManager.createLoginSession(profile.getNamaTempat(),profile.getNamaPemilik(),
                    profile.getEmail(),urlPhoto,
                    profile.getStrAlamat(), profile.getNoTelepon(),
                    loginResponseModel.getData().getToken(),
                    profile.getId(),loginResponseModel.getData().getAccess(),
                    String.valueOf(profile.getAlamat().getCoordinates().get(1)),
                    String.valueOf(profile.getAlamat().getCoordinates().get(0)))
                    ;
            Intent i = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(i);
            finish();
        }else if(code == 0) {
            viewDialog.hideDialog();
            Toast.makeText(this, "Terjadi kesalahan, silahkan coba lagi !", Toast.LENGTH_SHORT).show();
        }else{
            viewDialog.hideDialog();
            Toast.makeText(this, "Email / password yang anda masukkan salah !", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onSetProgressBarVisibility(int visibility) {

    }
}
