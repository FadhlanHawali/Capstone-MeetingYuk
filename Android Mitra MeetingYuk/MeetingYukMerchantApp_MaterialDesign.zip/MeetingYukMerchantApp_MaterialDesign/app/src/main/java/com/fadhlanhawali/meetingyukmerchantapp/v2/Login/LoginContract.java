package com.fadhlanhawali.meetingyukmerchantapp.v2.Login;

import android.app.AlertDialog;
import android.content.Context;

import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.Model.LoginResponseModel;

public interface LoginContract {
    interface View{
        void initV();
        void onLoginResult(Boolean result, int code, LoginResponseModel loginResponseModel);
        void onSetProgressBarVisibility(int visibility);
    }

    interface Presenter{
        void initP();
        void doLogin(LoginRequestModel loginRequestModel, SessionManager sessionManager);
        void setProgressBarVisiblity(int visiblity);
    }
}
