package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class DataItem implements Serializable, Parcelable {

	@SerializedName("unit")
	private String unit;

	@SerializedName("quantity")
	private int quantity;

	@SerializedName("price")
	private int price;

	@SerializedName("icon")
	private Icon icon;

	@SerializedName("available")
	private boolean available;

	@SerializedName("name")
	private String name;

	@SerializedName("id_merchant")
	private String idMerchant;

	@SerializedName("description")
	private String description;

	@SerializedName("id")
	private String id;

	@SerializedName("photos")
	private List<PhotosItem> photos;

	private int qtyOrder = 1;

	private int flagSelected = 0;

	public int getQtyOrder() {
		return qtyOrder;
	}

	public void setQtyOrder(int qtyOrder) {
		this.qtyOrder = qtyOrder;
	}

	public int getFlagSelected() {
		return flagSelected;
	}

	public void setFlagSelected(int flagSelected) {
		this.flagSelected = flagSelected;
	}

	public void setUnit(String unit){
		this.unit = unit;
	}

	public String getUnit(){
		return unit;
	}

	public void setQuantity(int quantity){
		this.quantity = quantity;
	}

	public int getQuantity(){
		return quantity;
	}

	public void setPrice(int price){
		this.price = price;
	}

	public int getPrice(){
		return price;
	}

	public void setIcon(Icon icon){
		this.icon = icon;
	}

	public Icon getIcon(){
		return icon;
	}

	public void setAvailable(boolean available){
		this.available = available;
	}

	public boolean isAvailable(){
		return available;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setIdMerchant(String idMerchant){
		this.idMerchant = idMerchant;
	}

	public String getIdMerchant(){
		return idMerchant;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return description;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setPhotos(List<PhotosItem> photos){
		this.photos = photos;
	}

	public List<PhotosItem> getPhotos(){
		return photos;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"unit = '" + unit + '\'' + 
			",quantity = '" + quantity + '\'' + 
			",price = '" + price + '\'' + 
			",icon = '" + icon + '\'' + 
			",available = '" + available + '\'' + 
			",name = '" + name + '\'' + 
			",id_merchant = '" + idMerchant + '\'' + 
			",description = '" + description + '\'' + 
			",id = '" + id + '\'' + 
			",photos = '" + photos + '\'' + 
			"}";
		}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.unit);
		dest.writeInt(this.quantity);
		dest.writeInt(this.price);
		dest.writeParcelable(this.icon, flags);
		dest.writeByte(this.available ? (byte) 1 : (byte) 0);
		dest.writeString(this.name);
		dest.writeString(this.idMerchant);
		dest.writeString(this.description);
		dest.writeString(this.id);
		dest.writeList(this.photos);
	}

	public DataItem() {
	}

	protected DataItem(Parcel in) {
		this.unit = in.readString();
		this.quantity = in.readInt();
		this.price = in.readInt();
		this.icon = in.readParcelable(Icon.class.getClassLoader());
		this.available = in.readByte() != 0;
		this.name = in.readString();
		this.idMerchant = in.readString();
		this.description = in.readString();
		this.id = in.readString();
		this.photos = new ArrayList<PhotosItem>();
		in.readList(this.photos, PhotosItem.class.getClassLoader());
	}

	public static final Parcelable.Creator<DataItem> CREATOR = new Parcelable.Creator<DataItem>() {
		@Override
		public DataItem createFromParcel(Parcel source) {
			return new DataItem(source);
		}

		@Override
		public DataItem[] newArray(int size) {
			return new DataItem[size];
		}
	};
}