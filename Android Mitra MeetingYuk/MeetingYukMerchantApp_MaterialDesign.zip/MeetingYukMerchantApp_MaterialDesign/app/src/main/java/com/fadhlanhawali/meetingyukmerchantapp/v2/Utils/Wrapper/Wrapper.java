package com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Wrapper;

import android.content.Context;

public class Wrapper {

    private Context context;
    private Boolean flag;
    private int code;

    public Wrapper(Context context, Boolean flag, int code) {
        this.context = context;
        this.flag = flag;
        this.code = code;
    }

    void WrapAPIError (){

    }

    void WrapAPISuccess (){

    }
}
