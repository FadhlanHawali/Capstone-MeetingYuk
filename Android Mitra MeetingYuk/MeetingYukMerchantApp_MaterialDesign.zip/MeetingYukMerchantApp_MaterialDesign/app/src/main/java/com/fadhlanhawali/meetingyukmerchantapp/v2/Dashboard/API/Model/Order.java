package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model;

import android.os.Parcel;
import android.os.Parcelable;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Order implements Parcelable {

	@SerializedName("meeting_photo")
	private String meetingPhoto;

	@SerializedName("cost")
	private int cost;

	@SerializedName("time_start")
	private long timeStart;

	@SerializedName("payment_status")
	private boolean paymentStatus;

	@SerializedName("id_meeting")
	private String idMeeting;

	@SerializedName("id_merchant")
	private String idMerchant;

	@SerializedName("order_date")
	private long orderDate;

	@SerializedName("contact")
	private Contact contact;

	@SerializedName("guest")
	private int guest;

	@SerializedName("meeting_name")
	private String meetingName;

	@SerializedName("time_end")
	private long timeEnd;

	@SerializedName("id")
	private String id;

	@SerializedName("status")
	private String status;

	public void setMeetingPhoto(String meetingPhoto){
		this.meetingPhoto = meetingPhoto;
	}

	public String getMeetingPhoto(){
		return meetingPhoto;
	}

	public void setCost(int cost){
		this.cost = cost;
	}

	public int getCost(){
		return cost;
	}

	public void setTimeStart(long timeStart){
		this.timeStart = timeStart;
	}

	public long getTimeStart(){
		return timeStart;
	}

	public void setPaymentStatus(boolean paymentStatus){
		this.paymentStatus = paymentStatus;
	}

	public boolean isPaymentStatus(){
		return paymentStatus;
	}

	public void setIdMeeting(String idMeeting){
		this.idMeeting = idMeeting;
	}

	public String getIdMeeting(){
		return idMeeting;
	}

	public void setIdMerchant(String idMerchant){
		this.idMerchant = idMerchant;
	}

	public String getIdMerchant(){
		return idMerchant;
	}

	public void setOrderDate(long orderDate){
		this.orderDate = orderDate;
	}

	public long getOrderDate(){
		return orderDate;
	}

	public void setContact(Contact contact){
		this.contact = contact;
	}

	public Contact getContact(){
		return contact;
	}

	public void setGuest(int guest){
		this.guest = guest;
	}

	public int getGuest(){
		return guest;
	}

	public void setMeetingName(String meetingName){
		this.meetingName = meetingName;
	}

	public String getMeetingName(){
		return meetingName;
	}

	public void setTimeEnd(long timeEnd){
		this.timeEnd = timeEnd;
	}

	public long getTimeEnd(){
		return timeEnd;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}

	@Override
 	public String toString(){
		return 
			"Order{" + 
			"meeting_photo = '" + meetingPhoto + '\'' + 
			",cost = '" + cost + '\'' + 
			",time_start = '" + timeStart + '\'' + 
			",payment_status = '" + paymentStatus + '\'' + 
			",id_meeting = '" + idMeeting + '\'' + 
			",id_merchant = '" + idMerchant + '\'' + 
			",order_date = '" + orderDate + '\'' + 
			",contact = '" + contact + '\'' + 
			",guest = '" + guest + '\'' + 
			",meeting_name = '" + meetingName + '\'' + 
			",time_end = '" + timeEnd + '\'' + 
			",id = '" + id + '\'' + 
			",status = '" + status + '\'' + 
			"}";
		}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.meetingPhoto);
		dest.writeInt(this.cost);
		dest.writeLong(this.timeStart);
		dest.writeByte(this.paymentStatus ? (byte) 1 : (byte) 0);
		dest.writeString(this.idMeeting);
		dest.writeString(this.idMerchant);
		dest.writeLong(this.orderDate);
		dest.writeParcelable(this.contact, flags);
		dest.writeInt(this.guest);
		dest.writeString(this.meetingName);
		dest.writeLong(this.timeEnd);
		dest.writeString(this.id);
		dest.writeString(this.status);
	}

	public Order() {
	}

	protected Order(Parcel in) {
		this.meetingPhoto = in.readString();
		this.cost = in.readInt();
		this.timeStart = in.readLong();
		this.paymentStatus = in.readByte() != 0;
		this.idMeeting = in.readString();
		this.idMerchant = in.readString();
		this.orderDate = in.readLong();
		this.contact = in.readParcelable(Contact.class.getClassLoader());
		this.guest = in.readInt();
		this.meetingName = in.readString();
		this.timeEnd = in.readLong();
		this.id = in.readString();
		this.status = in.readString();
	}

	public static final Parcelable.Creator<Order> CREATOR = new Parcelable.Creator<Order>() {
		@Override
		public Order createFromParcel(Parcel source) {
			return new Order(source);
		}

		@Override
		public Order[] newArray(int size) {
			return new Order[size];
		}
	};
}