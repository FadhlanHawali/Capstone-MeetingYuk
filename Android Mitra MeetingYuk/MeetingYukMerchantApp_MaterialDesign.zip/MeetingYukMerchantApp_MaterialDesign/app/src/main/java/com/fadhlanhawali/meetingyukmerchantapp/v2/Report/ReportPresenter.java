package com.fadhlanhawali.meetingyukmerchantapp.v2.Report;

import android.content.Context;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements.GetFinancialStatementsModelResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.GetSaldoMitraResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Utils.ReportAPIUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReportPresenter implements ReportContract.pSaldoMitra {


    private final Context mContext;
    private ReportContract.vSaldoMitra mView;
    private IReportAPI reportAPI;

    public ReportPresenter(Context context, ReportContract.vSaldoMitra mView) {
        this.mContext = context;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void doGetSaldoMitraResult(String token) {
        reportAPI = ReportAPIUtils.getAPIService();
        reportAPI.getSaldoMitra(token).enqueue(new Callback<GetSaldoMitraResponse>() {
            @Override
            public void onResponse(Call<GetSaldoMitraResponse> call, Response<GetSaldoMitraResponse> response) {
                if (response.isSuccessful()){
                    mView.onSaldoMitraResult(true,response.code(),response.body());
                }else {
                    mView.onSaldoMitraResult(false,response.code(),response.body());
                }
            }
            @Override
            public void onFailure(Call<GetSaldoMitraResponse> call, Throwable t) {

            }
        });

    }

    @Override
    public void doGetFinancialStatements(String token, String period) {
        reportAPI = ReportAPIUtils.getAPIService();
        reportAPI.getFinancialStatements(token, period).enqueue(new Callback<GetFinancialStatementsModelResponse>() {
            @Override
            public void onResponse(Call<GetFinancialStatementsModelResponse> call, Response<GetFinancialStatementsModelResponse> response) {
                if (response.isSuccessful()){
                    mView.onFinancialStatementsResult(true,response.code(),response.body());
                } else {
                    mView.onFinancialStatementsResult(false, response.code(), response.body());
                }
            }

            @Override
            public void onFailure(Call<GetFinancialStatementsModelResponse> call, Throwable t) {

            }
        });
    }
}
