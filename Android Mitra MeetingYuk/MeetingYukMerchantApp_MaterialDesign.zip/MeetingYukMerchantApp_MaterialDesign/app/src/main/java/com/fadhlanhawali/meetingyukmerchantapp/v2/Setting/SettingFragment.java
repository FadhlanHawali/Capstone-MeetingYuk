package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;

import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.UploadFileServiceModel.UploadFileServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.AdminActivity;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.GetAdmin.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.GetAdmin.GetAdminResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.EditProfile.Alamat;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.EditProfile.EditProfileRequest;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Camera.CameraContract;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Camera.CameraPresenter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ViewDialog;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

import static android.app.Activity.RESULT_OK;

public class SettingFragment extends Fragment implements SettingContract.vSetting, CameraContract.View {

    private Button btnLogout, btnAddAdmin,btEditAdmin,btCancel,btDeleteAdmin,btnSimpan;
    private SettingPresenter mPresenter;
    private SessionManager sessionManager;
    private TextView txtUsername, txtAlamat;
    private EditText etEmail, etNomorTelepon, etNamaMerchant, etAlamat;
    private ImageView imgProfile, ivEditMerchant, ivEditAccount, ivSetMap;
    private RelativeLayout rlEditMerchant, rlEditAccount;
    private HashMap<String,String> user;
    private List<DataItem> adminList = new ArrayList<>();
    private RecyclerView recyclerView;
    private SettingAdapter settingAdapter;
    private boolean isEditableMerchant, isEditableAccount, isPhotoChanged, isAlamatChanged = false;
    private ViewDialog viewDialog;

    private Uri photoURI ;
    private CameraPresenter cameraPresenter;
    static final int REQUEST_TAKE_PHOTO = 101;
    static final int REQUEST_GALLERY_PHOTO = 102;
    private static final int PLACE_PICKER_REQUEST = 1000;
    private Double latitude, longitude;
    static String[] permissions = new String[]{
            Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_settingv2, container, false);
        cameraPresenter = new CameraPresenter(this);
        viewDialog = new ViewDialog(getActivity());
        btnLogout = v.findViewById(R.id.btnLogOut);
        btnAddAdmin = v.findViewById(R.id.btnAddAdmin);
        btEditAdmin = v.findViewById(R.id.btnEditAdmin);
        btnSimpan = v.findViewById(R.id.btnSimpan);
        btCancel = v.findViewById(R.id.btnCancel);
        btDeleteAdmin = v.findViewById(R.id.btnDeleteAdmin);
        rlEditAccount = v.findViewById(R.id.rlEditAccount);
        rlEditMerchant = v.findViewById(R.id.rlEditMerchant);
        ivEditAccount = v.findViewById(R.id.ivEditAccount);
        ivEditMerchant = v.findViewById(R.id.ivEditMerchant);
        sessionManager = new SessionManager(getContext());

        getActivity().getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        txtUsername = v.findViewById(R.id.txtUsername);
        txtAlamat = v.findViewById(R.id.txtAlamat);
        etEmail = v.findViewById(R.id.etEmail);
        etNomorTelepon = v.findViewById(R.id.etNomorTelepon);
        etAlamat = v.findViewById(R.id.etAlamat);
        etNamaMerchant = v.findViewById(R.id.etNamaMerchant);
        imgProfile = v.findViewById(R.id.imgProfile);
        ivSetMap = v.findViewById(R.id.ivSetMap);
        recyclerView = v.findViewById(R.id.recyclerView);
        mPresenter = new SettingPresenter(getContext(),this);
        mPresenter.initP();

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sessionManager.logoutUser();
                getActivity().finish();
            }
        });

        settingAdapter = new SettingAdapter(getContext());
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getContext(), 1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(settingAdapter);

        btEditAdmin.setOnClickListener(view -> {
            btEditAdmin.setVisibility(View.GONE);
            btnAddAdmin.setVisibility(View.GONE);
            btCancel.setVisibility(View.VISIBLE);
            btDeleteAdmin.setVisibility(View.VISIBLE);
            settingAdapter.setFlagEdit(1);
        });

        btCancel.setOnClickListener(view -> {
            btEditAdmin.setVisibility(View.VISIBLE);
            btnAddAdmin.setVisibility(View.VISIBLE);
            btCancel.setVisibility(View.GONE);
            btDeleteAdmin.setVisibility(View.GONE);
            settingAdapter.setFlagEdit(0);
        });

        btDeleteAdmin.setOnClickListener(view -> {
            adminList = settingAdapter.getDeleteAdmin();
            for(int i = 0;i<adminList.size();i++){
                mPresenter.deleteAdmin(user.get(SessionManager.KEY_TOKEN),adminList.get(i).getEmail());
            }
            btEditAdmin.setVisibility(View.VISIBLE);
            btnAddAdmin.setVisibility(View.VISIBLE);
            btCancel.setVisibility(View.GONE);
            btDeleteAdmin.setVisibility(View.GONE);
            settingAdapter.setFlagEdit(0);

            Toast.makeText(getContext(), "Delete Admin Success !", Toast.LENGTH_SHORT).show();

            mPresenter.getAdminList(user.get(SessionManager.KEY_TOKEN));
        });

        rlEditMerchant.setOnClickListener(view -> {
            if(!isEditableMerchant){
                isEditableMerchant = true;
                ivEditMerchant.setImageResource(R.drawable.ic_check_white);
                ivSetMap.setVisibility(View.VISIBLE);
                enableEditText(new EditText[]{etNamaMerchant,etAlamat});
            }else {
                isEditableMerchant = false;
                checkMerchantChange();
                ivEditMerchant.setImageResource(R.drawable.ic_edit_white);
                ivSetMap.setVisibility(View.INVISIBLE);
                disableEditText(new EditText[]{etNamaMerchant,etAlamat});
            }
        });

        rlEditAccount.setOnClickListener(view -> {
            if(!isEditableAccount){
                isEditableAccount = true;
                enableEditText(new EditText[]{etEmail,etNomorTelepon});
                ivEditAccount.setImageResource(R.drawable.ic_check_white);

            }else {
                isEditableAccount = false;
                checkAccountChange();
                disableEditText(new EditText[]{etEmail,etNomorTelepon});
                ivEditAccount.setImageResource(R.drawable.ic_edit_white);

            }
        });

        btnSimpan.setOnClickListener(view -> {
            if(isPhotoChanged){
//                Toast.makeText(getContext(), "CLICKED", Toast.LENGTH_SHORT).show();
                if (!cameraPresenter.getUri().equals("")) {
                    String uriPath = cameraPresenter.getUri();
                    File mFile = new File(uriPath);
                    RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"), mFile);
                    MultipartBody.Part body = MultipartBody.Part.createFormData("file",mFile.getName(),requestBody);
                    mPresenter.doUploadFile(body);
                    viewDialog.showDialog();
                }else if(photoURI != null){
                    File mFile = new File(getFilePathForN(photoURI,getContext()));
                    RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"), mFile);
                    MultipartBody.Part body = MultipartBody.Part.createFormData("file",mFile.getName(),requestBody);
                    viewDialog.showDialog();
                    mPresenter.doUploadFile(body);
                }
            }else {
                viewDialog.showDialog();
                if(!isAlamatChanged){
                    longitude = Double.parseDouble(user.get(SessionManager.KEY_LONGITUDE));
                    latitude = Double.parseDouble(user.get(SessionManager.KEY_LATITUDE));
                }
                EditProfileRequest editProfileRequest = new EditProfileRequest(
                       user.get(SessionManager.KEY_NAMAPEMILIK),
                       user.get(SessionManager.KEY_URLFOTO),
                       etAlamat.getText().toString(),
                       etNamaMerchant.getText().toString(),
                        etEmail.getText().toString(),
                        etNomorTelepon.getText().toString(),
                        new Alamat(
                                longitude,
                                latitude
                        )
                );
                mPresenter.doEditProfile(editProfileRequest,user.get(SessionManager.KEY_TOKEN));
            }

        });

        imgProfile.setOnClickListener(view ->
                selectImage()
        );

        ivSetMap.setOnClickListener(view -> {
            placePicker();
        });

        return v;
    }

    private void checkMerchantChange(){
        if(!etNamaMerchant.getText().toString().equals(user.get(SessionManager.KEY_NAMATEMPAT))){
            btnSimpan.setVisibility(View.VISIBLE);
        }

        if(!etAlamat.getText().toString().equals(user.get(SessionManager.KEY_ALAMAT))){
            btnSimpan.setVisibility(View.VISIBLE);
        }
    }

    private void checkAccountChange(){
        if(!etEmail.getText().toString().equals(user.get(SessionManager.KEY_EMAIL))){
            btnSimpan.setVisibility(View.VISIBLE);
        }

        if(!etNomorTelepon.getText().toString().equals(user.get(SessionManager.KEY_TELEPON))){
            btnSimpan.setVisibility(View.VISIBLE);
        }
    }

    private void enableEditText(EditText[] et){
        for (EditText editText : et) {
            editText.setEnabled(true);
            editText.setFocusableInTouchMode(true);
            editText.setFocusable(true);
        }
    }

    private void disableEditText(EditText[] et){
        for (EditText editText : et) {
            editText.setEnabled(false);
            editText.setFocusableInTouchMode(false);
            editText.setFocusable(false);
        }
    }

    @Override
    public void initV() {
        cameraPresenter.setUri("");
        user = sessionManager.getUserDetails();
        fetchProfileData();
        mPresenter.getAdminList(user.get(SessionManager.KEY_TOKEN));
        btnAddAdmin.setOnClickListener(view -> {
            Intent i = new Intent(getContext(), AdminActivity.class);
            startActivity(i);
        });

    }

    private void fetchProfileData(){
        txtUsername.setText(user.get(SessionManager.KEY_NAMAPEMILIK));
        etEmail.setText(user.get(SessionManager.KEY_EMAIL));
        etNomorTelepon.setText(user.get(SessionManager.KEY_TELEPON));
        etNamaMerchant.setText(user.get(SessionManager.KEY_NAMATEMPAT));
        txtAlamat.setText(user.get(SessionManager.KEY_ALAMAT));
        etAlamat.setText(user.get(SessionManager.KEY_ALAMAT));
        Glide.with(getContext()).load(user.get(SessionManager.KEY_URLFOTO)).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imgProfile);
    }

    @Override
    public void onResult(Boolean result) {

    }


    @Override
    public void onGetAdminResult(GetAdminResponseModel getAdminResponseModel, Boolean result, int code) {
        settingAdapter.setAdminList(getAdminResponseModel.getData());
    }

    @Override
    public void onDeleteAdminResult(GeneralResponseModel generalResponseModel, Boolean result, int code) {

    }

    @Override
    public void onUploadFileResult(Boolean result, int code, UploadFileServiceResponseModel uploadFileServiceResponseModel) {
//        Toast.makeText(getContext(), "Masuk on Upload FIle", Toast.LENGTH_SHORT).show();
        if(result){
            if(!isAlamatChanged) {
                latitude = Double.parseDouble(user.get(SessionManager.KEY_LATITUDE));
                longitude = Double.parseDouble(user.get(SessionManager.KEY_LONGITUDE));
            }
            String urlPhoto = uploadFileServiceResponseModel.getData().getUrl();
            if (!urlPhoto.contains("https://")){
                urlPhoto = "https://" + urlPhoto;
            }
            sessionManager.editor.putString(SessionManager.KEY_URLFOTO,urlPhoto);
            sessionManager.editor.commit();
            EditProfileRequest editProfileRequest = new EditProfileRequest(
                    user.get(SessionManager.KEY_NAMAPEMILIK),
                    uploadFileServiceResponseModel.getData().getUrl(),
                    etAlamat.getText().toString(),
                    etNamaMerchant.getText().toString(),
                    etEmail.getText().toString(),
                    etNomorTelepon.getText().toString(),
                    new Alamat(
                            longitude,
                            latitude
                    )
            );
            mPresenter.doEditProfile(editProfileRequest,user.get(SessionManager.KEY_TOKEN));
        }else {
            viewDialog.hideDialog();
            Toast.makeText(getContext(), "Terjadi kesalahan, silahkan coba lagi !", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onEditProfileResult(GeneralResponseModel generalResponseModel, Boolean result, int code) {
        if(result){
            viewDialog.hideDialog();
            sessionManager.editor.putString(SessionManager.KEY_ALAMAT,etAlamat.getText().toString());
            sessionManager.editor.putString(SessionManager.KEY_NAMAPEMILIK,etNamaMerchant.getText().toString());
            sessionManager.editor.putString(SessionManager.KEY_EMAIL,etEmail.getText().toString());
            sessionManager.editor.putString(SessionManager.KEY_TELEPON,etNomorTelepon.getText().toString());
            sessionManager.editor.putString(SessionManager.KEY_LATITUDE,String.valueOf(latitude));
            sessionManager.editor.putString(SessionManager.KEY_LONGITUDE,String.valueOf(longitude));
            sessionManager.editor.commit();
            btnSimpan.setVisibility(View.GONE);
            Toast.makeText(getContext(), "Sukses memperbarui profil !", Toast.LENGTH_SHORT).show();
        }else {
            viewDialog.hideDialog();
            Toast.makeText(getContext(), "Terjadi kesalahan, silahkan coba lagi !", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean checkPermission() {
        for (String mPermission : permissions) {
            int result = ActivityCompat.checkSelfPermission(getContext(), mPermission);
            if (result == PackageManager.PERMISSION_DENIED) return false;
        }
        return true;
    }
    @Override
    public void showPermissionDialog() {
        Dexter.withActivity(getActivity()).withPermissions(permissions)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                        }
                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            showSettingsDialog();
                        }
                    }
                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).withErrorListener(error -> showErrorDialog())
                .onSameThread()
                .check();
    }

    @Override
    public File getFilePath() {
        return getActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
    }

    @Override
    public void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    @Override
    public void startCamera(File file) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            if (file != null) {
                photoURI = FileProvider.getUriForFile(getContext(),
                        BuildConfig.APPLICATION_ID + ".provider", file);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);

            }
        }
    }

    @Override
    public void chooseGallery() {
        Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickPhoto.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(pickPhoto, REQUEST_GALLERY_PHOTO);
    }

    @Override
    public void showNoSpaceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(getString(R.string.error_message_no_more_space));
        builder.setMessage(getString(R.string.error_message_insufficient_space));
        builder.setPositiveButton(getString(R.string.ok), (dialog, which) -> dialog.cancel());
        builder.show();
    }

    @Override
    public int availableDisk() {
        File mFilePath = getFilePath();
        long freeSpace = mFilePath.getFreeSpace();
        return Math.round(freeSpace / 1048576);
    }

    @Override
    public File newFile() {
        Calendar cal = Calendar.getInstance();
        long timeInMillis = cal.getTimeInMillis();
        String mFileName = timeInMillis + ".jpeg";
        File mFilePath = getFilePath();
        try {
            File newFile = new File(mFilePath.getAbsolutePath(), mFileName);
            newFile.createNewFile();
            return newFile;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void showErrorDialog() {
        Toast.makeText(getContext(), getString(R.string.error_message), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void displayImagePreview(String mFilePath) {
//        Toast.makeText(getContext(), "TRIGGERED DISPLAY IMAGE", Toast.LENGTH_SHORT).show();
        Glide.with(getContext()).load(mFilePath).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imgProfile);
    }

    @Override
    public void displayImagePreview(Uri mFileUri) {
//        Toast.makeText(getContext(), "TRIGGERED DISPLAY IMAGE", Toast.LENGTH_SHORT).show();
        Glide.with(getContext()).load(mFileUri).apply(new RequestOptions().centerCrop().placeholder(R.drawable.camera)).into(imgProfile);
    }

    @Override
    public String getRealPathFromUri(Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Images.Media.DATA};
            cursor = getActivity().getContentResolver().query(contentUri, proj, null, null, null);
            assert cursor != null;
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(columnIndex);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        Toast.makeText(getContext(), "TRIGGERED RESULT", Toast.LENGTH_SHORT).show();
        super.onActivityResult(requestCode, resultCode, data);
//        Toast.makeText(getContext(), "TRIGGERED RESULT HASIL" + resultCode, Toast.LENGTH_SHORT).show();


        if (requestCode == REQUEST_TAKE_PHOTO) {
            if (resultCode == RESULT_OK) {
//                Toast.makeText(getContext(), "KAMERA OK " + photoURI.getPath(), Toast.LENGTH_SHORT).show();
                cameraPresenter.showPreview(photoURI);
                btnSimpan.setVisibility(View.VISIBLE);
                isPhotoChanged = true;
            }
        } else if (requestCode == REQUEST_GALLERY_PHOTO) {
            if (resultCode == RESULT_OK) {
                Uri selectedImage = data.getData();
                String mPhotoPath = getRealPathFromUri(selectedImage);
//                Toast.makeText(getContext(), "TRIGGERED RESULT GALERY", Toast.LENGTH_SHORT).show();
                isPhotoChanged = true;
                Log.d("URI IMAGE :", selectedImage.toString());
                Log.d("mPhotoPath : ", mPhotoPath);
                btnSimpan.setVisibility(View.VISIBLE);
                cameraPresenter.setUri(mPhotoPath);
                cameraPresenter.showPreview(mPhotoPath);
            }
        }
        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                isAlamatChanged = true;
                Place place = PlacePicker.getPlace(getContext(),data);
//                String toastMsg = String.format("Place: %s", place.getLatLng());
//                Toast.makeText(this, toastMsg, Toast.LENGTH_LONG).show();
                etAlamat.setText(place.getAddress());
                latitude = place.getLatLng().latitude;
                longitude = place.getLatLng().longitude;
            }
        }
    }

    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(getString(R.string.message_need_permission));
        builder.setMessage(getString(R.string.message_grant_permission));
        builder.setPositiveButton(getString(R.string.label_setting), (dialog, which) -> {
            dialog.cancel();
            openSettings();
        });
        builder.setNegativeButton(getString(R.string.cancel), (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void selectImage() {
        final CharSequence[] items = {getString(R.string.take_photo), getString(R.string.choose_gallery),
                getString(R.string.cancel)};
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setItems(items, (dialog, item) -> {
            if (items[item].equals("Take Photo")) {
                cameraPresenter.cameraClick();
            } else if (items[item].equals("Choose from Gallery")) {
                cameraPresenter.ChooseGalleryClick();
            } else if (items[item].equals("Cancel")) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    public void placePicker()
    {
        PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
        try {
            startActivityForResult(builder.build(getActivity()), PLACE_PICKER_REQUEST);
        } catch (GooglePlayServicesRepairableException e) {
            e.printStackTrace();
        } catch (GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }

    }

    private static String getFilePathForN(Uri uri, Context context) {
        Uri returnUri = uri;
        Cursor returnCursor = context.getContentResolver().query(returnUri, null, null, null, null);
        /*
         * Get the column indexes of the data in the Cursor,
         *     * move to the first row in the Cursor, get the data,
         *     * and display it.
         * */
        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
        returnCursor.moveToFirst();
        String name = (returnCursor.getString(nameIndex));
        String size = (Long.toString(returnCursor.getLong(sizeIndex)));
        File file = new File(context.getFilesDir(), name);
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            FileOutputStream outputStream = new FileOutputStream(file);
            int read = 0;
            int maxBufferSize = 1 * 1024 * 1024;
            int bytesAvailable = inputStream.available();

            //int bufferSize = 1024;
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);

            final byte[] buffers = new byte[bufferSize];
            while ((read = inputStream.read(buffers)) != -1) {
                outputStream.write(buffers, 0, read);
            }
            Log.e("File Size", "Size " + file.length());
            inputStream.close();
            outputStream.close();
            Log.e("File Path", "Path " + file.getPath());
            Log.e("File Size", "Size " + file.length());
        } catch (Exception e) {
            Log.e("Exception", e.getMessage());
        }
        return file.getPath();
    }
}
