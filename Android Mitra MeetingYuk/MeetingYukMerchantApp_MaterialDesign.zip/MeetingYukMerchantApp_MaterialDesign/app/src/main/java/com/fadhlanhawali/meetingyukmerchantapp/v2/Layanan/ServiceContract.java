package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel.AddServiceRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.CategoryServiceModel.CategoryServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.EditServiceModel.EditServiceRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.FileUpload.UploadFileResponseModel;

import okhttp3.MultipartBody;

public interface ServiceContract {
    interface vListService{
        void initV();
        void onClearText();
        void onResult(Boolean result, int code, ListServiceResponse listServiceResponse);
    }

    interface pListService{
        void initP();
        void clear();
        void getServiceList(String token);
    }

    interface vAddService {
        void initV();
        void onAddServiceResult(Boolean result, int code);
        void onEditServiceResult(Boolean result, int code);
        void onDeleteServiceResult(Boolean result, int code);
        void onUploadFileResult(Boolean result, int code, UploadFileResponseModel uploadFileResponseModel);
    }

    interface pAddService{
        void initP();
        void doAddService(AddServiceRequestModel addServiceRequestModel, String token);
        void doEditService(AddServiceRequestModel addServiceRequestModel, String token, String idService);
        void doDeleteServiceResult(String token, String idService);
        void doUploadFile(MultipartBody.Part body);
    }

    interface vEditService{
        void initV();
        void onEditServiceResult(Boolean result, int code);
        void onUploadFileResult(Boolean result, int code, UploadFileResponseModel uploadFileResponseModel);
    }

    interface pEditService{
        void initP();
        void doEditService(AddServiceRequestModel addServiceRequestModel, String token, String idService);
        void doUploadFile(MultipartBody.Part body);
    }

    interface vGetServiceCategory{
        void initV();
        void onResult(Boolean result, int code, CategoryServiceResponseModel categoryServiceResponseModel);
        void setCategory(String idCategory, String Category, String url);
        void onResultCount(Boolean result, int code, int count);
    }

    interface pGetServiceCategory{
        void initP();
        void getServiceCategory(String token);
        void getCountService(String token);
    }
}
