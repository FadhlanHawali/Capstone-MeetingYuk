package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.EditServiceModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class EditServiceResponseModel{

	@SerializedName("success")
	private boolean success;

	public void setSuccess(boolean success){
		this.success = success;
	}

	public boolean isSuccess(){
		return success;
	}

	@Override
 	public String toString(){
		return 
			"EditServiceResponseModel{" + 
			"success = '" + success + '\'' + 
			"}";
		}
}