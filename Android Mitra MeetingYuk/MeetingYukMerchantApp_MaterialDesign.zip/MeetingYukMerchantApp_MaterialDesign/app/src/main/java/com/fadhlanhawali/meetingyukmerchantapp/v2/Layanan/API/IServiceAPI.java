package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel.AddServiceRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.AddServiceModel.AddServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.CategoryServiceModel.CategoryServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.EditServiceModel.EditServiceRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.EditServiceModel.EditServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.FileUpload.UploadFileResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface IServiceAPI {
    @GET(BuildConfig.GET_SERVICE_LIST)
    Call<ListServiceResponse> getServiceList(@Header("x-meeting-token") String token);

    @POST(BuildConfig.ADD_SERVICE)
    Call<AddServiceResponseModel> addService(@Header("x-meeting-token") String token, @Body AddServiceRequestModel addServiceRequestModel);

    @POST(BuildConfig.EDIT_SERVICE)
    Call<EditServiceResponseModel> editService(@Header("x-meeting-token") String token, @Body AddServiceRequestModel addServiceRequestModel, @Path(value = "idService", encoded = true) String orderId);

    @POST(BuildConfig.DELETE_SERVICE)
    Call<GeneralResponseModel> deleteService(@Header("x-meeting-token") String token, @Path(value = "idService", encoded = true) String idService);

    @GET(BuildConfig.GET_SERVICE_CATEGORY)
    Call<CategoryServiceResponseModel> getServiceCategory(@Header("x-meeting-token") String token);

    @Multipart
    @POST(BuildConfig.UPLOAD_FILE)
    Call<UploadFileResponseModel> uploadFileService(@Part MultipartBody.Part image);
}
