package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterRequestModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class OrderFilterRequestModel{

	@SerializedName("timeEnd")
	private TimeEnd timeEnd;

	@SerializedName("timeStart")
	private TimeStart timeStart;

	@SerializedName("idMerchant")
	private String idMerchant;

	@SerializedName("idMeeting")
	private String idMeeting;

	@SerializedName("status")
	private String status;

	public void setTimeEnd(TimeEnd timeEnd){
		this.timeEnd = timeEnd;
	}

	public TimeEnd getTimeEnd(){
		return timeEnd;
	}

	public void setTimeStart(TimeStart timeStart){
		this.timeStart = timeStart;
	}

	public TimeStart getTimeStart(){
		return timeStart;
	}

	public void setIdMerchant(String idMerchant){
		this.idMerchant = idMerchant;
	}

	public String getIdMerchant(){
		return idMerchant;
	}

	public void setIdMeeting(String idMeeting){
		this.idMeeting = idMeeting;
	}

	public String getIdMeeting(){
		return idMeeting;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}

	public OrderFilterRequestModel(TimeEnd timeEnd, TimeStart timeStart, String idMerchant, String idMeeting, String status) {
		this.timeEnd = timeEnd;
		this.timeStart = timeStart;
		this.idMerchant = idMerchant;
		this.idMeeting = idMeeting;
		this.status = status;
	}

	@Override
 	public String toString(){
		return 
			"OrderFilterRequestModel{" + 
			"timeEnd = '" + timeEnd + '\'' + 
			",timeStart = '" + timeStart + '\'' + 
			",idMerchant = '" + idMerchant + '\'' + 
			",idMeeting = '" + idMeeting + '\'' + 
			",status = '" + status + '\'' + 
			"}";
		}
}