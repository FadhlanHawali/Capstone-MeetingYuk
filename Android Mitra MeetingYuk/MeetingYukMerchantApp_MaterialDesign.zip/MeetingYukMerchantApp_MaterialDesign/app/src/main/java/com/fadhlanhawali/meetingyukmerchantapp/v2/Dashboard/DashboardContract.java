package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard;

import android.content.Context;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterRequestModel.OrderFilterRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterResponseModel.OrderFilterResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderResponseModel;

public interface DashboardContract {
    interface vOrderAccepted{
        void initV();
        void onOrderFilter(Boolean result, int code, OrderFilterResponseModel orderFilterResponseModel);
        void onSendToken(Boolean result, int code, String URL);
    }

    interface pOrderAccepted{
        void initP();
        void getOrderFilter (String token, OrderFilterRequestModel orderFilterRequestModel);
        void sendToken (String token, String firebaseToken);
    }
}
