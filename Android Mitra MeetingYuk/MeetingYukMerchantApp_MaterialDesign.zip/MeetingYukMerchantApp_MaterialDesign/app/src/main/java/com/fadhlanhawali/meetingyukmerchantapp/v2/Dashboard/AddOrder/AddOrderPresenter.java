package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.AddOrder;

import android.content.Context;

import com.fadhlanhawali.meetingyukmerchantapp.v2.API.APIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.API.InterfaceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.IDashboardAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.AddOrderRequest.AddOrderRequest;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.Utils.DashboardAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.IServiceAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.Utils.ServiceAPIUtils;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddOrderPresenter implements AddOrderContract.Presenter {

    private Context mContext;
    private AddOrderContract.View mView;
    private IDashboardAPI dashboardAPI;
    private IServiceAPI serviceAPI;

    public AddOrderPresenter(Context mContext, AddOrderContract.View mView) {
        this.mContext = mContext;
        this.mView = mView;
    }

    @Override
    public void initP() {
        mView.initV();
    }

    @Override
    public void addOrder(String token, AddOrderRequest addOrderRequest) {
        dashboardAPI = DashboardAPIUtils.getAPIService();
        dashboardAPI.addOrder(token, addOrderRequest).enqueue(new Callback<GeneralResponseModel>() {
            @Override
            public void onResponse(Call<GeneralResponseModel> call, Response<GeneralResponseModel> response) {
                if(response.isSuccessful()){
                    mView.onAddOrder(true,response.code());
                }else {
                    mView.onAddOrder(false, response.code());
                }
            }

            @Override
            public void onFailure(Call<GeneralResponseModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void getServiceList(String token) {
        serviceAPI = ServiceAPIUtils.getAPIService();
        serviceAPI.getServiceList(token).enqueue(new Callback<ListServiceResponse>() {
            @Override
            public void onResponse(Call<ListServiceResponse> call, Response<ListServiceResponse> response) {
                if(response.isSuccessful()){
                    mView.onGetServiceList(true, response.code(), response.body());
                }else {
                    mView.onGetServiceList(false,response.code(), null);
                }
            }

            @Override
            public void onFailure(Call<ListServiceResponse> call, Throwable t) {

            }
        });
    }

    @Override
    public void checkConnectivity() {

    }
}
