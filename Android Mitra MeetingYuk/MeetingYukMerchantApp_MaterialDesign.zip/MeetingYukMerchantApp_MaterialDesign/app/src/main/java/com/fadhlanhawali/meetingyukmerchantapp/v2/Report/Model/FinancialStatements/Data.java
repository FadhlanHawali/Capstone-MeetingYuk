package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Data{

	@SerializedName("orders")
	private List<OrdersItem> orders;

	@SerializedName("total_profit")
	private int totalProfit;

	@SerializedName("top_services")
	private List<TopServicesItem> topServices;

	public void setOrders(List<OrdersItem> orders){
		this.orders = orders;
	}

	public List<OrdersItem> getOrders(){
		return orders;
	}

	public void setTotalProfit(int totalProfit){
		this.totalProfit = totalProfit;
	}

	public int getTotalProfit(){
		return totalProfit;
	}

	public void setTopServices(List<TopServicesItem> topServices){
		this.topServices = topServices;
	}

	public List<TopServicesItem> getTopServices(){
		return topServices;
	}

	@Override
 	public String toString(){
		return 
			"Data{" + 
			"orders = '" + orders + '\'' + 
			",total_profit = '" + totalProfit + '\'' + 
			",top_services = '" + topServices + '\'' + 
			"}";
		}
}