package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class SendChatRequestModel{

	@SerializedName("mode")
	private String mode;

	@SerializedName("idRoom")
	private String idRoom;

	@SerializedName("fromUserId")
	private String fromUserId;

	@SerializedName("referenceType")
	private String referenceType;

	@SerializedName("fileUrl")
	private String fileUrl;

	@SerializedName("sendStatus")
	private boolean sendStatus;

	@SerializedName("text")
	private String text;

	@SerializedName("type")
	private String type;

	@SerializedName("referencedMessageId")
	private String referencedMessageId;

	public SendChatRequestModel(String mode, String idRoom, String fromUserId, String referenceType, String fileUrl, boolean sendStatus, String text, String type, String referencedMessageId) {
		this.mode = mode;
		this.idRoom = idRoom;
		this.fromUserId = fromUserId;
		this.referenceType = referenceType;
		this.fileUrl = fileUrl;
		this.sendStatus = sendStatus;
		this.text = text;
		this.type = type;
		this.referencedMessageId = referencedMessageId;
	}

	public void setMode(String mode){
		this.mode = mode;
	}

	public String getMode(){
		return mode;
	}

	public void setIdRoom(String idRoom){
		this.idRoom = idRoom;
	}

	public String getIdRoom(){
		return idRoom;
	}

	public void setFromUserId(String fromUserId){
		this.fromUserId = fromUserId;
	}

	public String getFromUserId(){
		return fromUserId;
	}

	public void setReferenceType(String referenceType){
		this.referenceType = referenceType;
	}

	public String getReferenceType(){
		return referenceType;
	}

	public void setFileUrl(String fileUrl){
		this.fileUrl = fileUrl;
	}

	public String getFileUrl(){
		return fileUrl;
	}

	public void setSendStatus(boolean sendStatus){
		this.sendStatus = sendStatus;
	}

	public boolean isSendStatus(){
		return sendStatus;
	}

	public void setText(String text){
		this.text = text;
	}

	public String getText(){
		return text;
	}

	public void setType(String type){
		this.type = type;
	}

	public String getType(){
		return type;
	}

	public void setReferencedMessageId(String referencedMessageId){
		this.referencedMessageId = referencedMessageId;
	}

	public String getReferencedMessageId(){
		return referencedMessageId;
	}

	@Override
 	public String toString(){
		return 
			"SendChatRequestModel{" + 
			"mode = '" + mode + '\'' + 
			",idRoom = '" + idRoom + '\'' + 
			",fromUserId = '" + fromUserId + '\'' + 
			",referenceType = '" + referenceType + '\'' + 
			",fileUrl = '" + fileUrl + '\'' + 
			",sendStatus = '" + sendStatus + '\'' + 
			",text = '" + text + '\'' + 
			",type = '" + type + '\'' + 
			",referencedMessageId = '" + referencedMessageId + '\'' + 
			"}";
		}
}