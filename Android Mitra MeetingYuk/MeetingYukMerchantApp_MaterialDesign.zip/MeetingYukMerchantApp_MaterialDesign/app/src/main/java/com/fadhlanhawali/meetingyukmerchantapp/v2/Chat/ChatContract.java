package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat;

import com.fadhlanhawali.meetingyukmerchantapp.v2.BasePresenter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.BaseView;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.GetChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.InitChatRoom.InitChatRoomResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat.SendChatRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.SendChat.SendChatResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.GeneralModel.GeneralResponseModel;

import java.util.List;

public interface ChatContract {


    interface vChat extends BaseView {
        void initV();

        void onInitChatRoom (Boolean result, int code, InitChatRoomResponseModel initChatRoomResponseModel);

        void onGetChatLatest(Boolean result, int code, GetChatResponseModel getChatResponseModel);

        void onSendChatResponse(Boolean result, int code, SendChatResponseModel sendChatResponseModel);

        void onGetChatBefore(Boolean result, int code, GetChatResponseModel getChatResponseModel);

        void onReadChatResponse (Boolean result, int code, GeneralResponseModel generalResponseModel);

        void onDBGetChat(List<DataItem> listChatResponse);
    }

    interface pChat extends BasePresenter {
        void initP();

        void initChatRoom(InitChatRoomRequestModel initChatRoomRequestModel);

        void getChatLatest(String idRoom, String idUser);

        void sendChat (SendChatRequestModel sendChatRequestModel);

        void readChat (String idMessage, String idUser);

        void getChatBefore(String timestamp,String idRoom);

        void dbInsertChat(SendChatRequestModel sendChatRequestModel);

        void dbGetChat(String idRoom);

        void dbInsertChatAll(GetChatResponseModel getChatResponseModel);

        void dbDeleteChatAll();
    }

}
