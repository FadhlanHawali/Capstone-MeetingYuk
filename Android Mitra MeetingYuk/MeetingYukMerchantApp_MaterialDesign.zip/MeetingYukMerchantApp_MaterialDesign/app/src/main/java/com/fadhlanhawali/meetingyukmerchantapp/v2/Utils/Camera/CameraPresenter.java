package com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.Camera;

import android.net.Uri;

import java.io.File;

public class CameraPresenter implements CameraContract.Presenter {

    private final CameraContract.View view;
    private String uri;
    private Boolean flag;

    public CameraPresenter(CameraContract.View view) {
        this.view = view;
    }


    @Override
    public void cameraClick() {
        if (!view.checkPermission()) {
            view.showPermissionDialog();
            return;
        }
        if (view.availableDisk() <= 5) {
            view.showNoSpaceDialog();
            return;
        }

        File file = view.newFile();

        if (file == null) {
            view.showErrorDialog();
            return;
        }

        view.startCamera(file);
    }

    @Override
    public void ChooseGalleryClick() {
        if (!view.checkPermission()) {
            view.showPermissionDialog();
            return;
        }

        view.chooseGallery();
    }

    @Override
    public void saveImage(Uri uri) {

    }

    @Override
    public void permissionDenied() {
        view.showPermissionDialog();
    }

    @Override
    public void showPreview(String mFilePath) {
        view.displayImagePreview(mFilePath);
    }

    @Override
    public void showPreview(Uri mFileUri) {
        view.displayImagePreview(mFileUri);

    }

    @Override
    public void setFlag(Boolean flag) {
        this.flag = flag;
    }

    @Override
    public Boolean getFlag() {
        return flag;
    }

    @Override
    public void setUri(String uri) {
        this.uri = uri;
    }

    @Override
    public String  getUri() {
        return uri;
    }
}