package com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.CategoryServiceModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class DataItem{

	@SerializedName("id")
	private String id;

	@SerializedName("text")
	private String text;

	@SerializedName("url")
	private String url;

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setText(String text){
		this.text = text;
	}

	public String getText(){
		return text;
	}

	public void setUrl(String url){
		this.url = url;
	}

	public String getUrl(){
		return url;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"id = '" + id + '\'' + 
			",text = '" + text + '\'' + 
			",url = '" + url + '\'' + 
			"}";
		}
}