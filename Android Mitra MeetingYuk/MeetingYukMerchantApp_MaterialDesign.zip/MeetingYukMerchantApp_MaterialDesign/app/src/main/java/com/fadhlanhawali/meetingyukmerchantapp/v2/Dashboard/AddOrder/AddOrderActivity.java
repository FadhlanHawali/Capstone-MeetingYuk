package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.AddOrder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.fadhlanhawali.meetingyukmerchantapp.R;
import com.fadhlanhawali.meetingyukmerchantapp.SessionManager;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.AddOrderRequest.AddOrderRequest;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.AddOrderRequest.ItemItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.ListServiceModel.ListServiceResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.ServiceAdapter;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Utils.ConvertDate;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;


public class AddOrderActivity extends AppCompatActivity implements AddOrderContract.View {

    private ServiceAdapter serviceAdapter;
    private static final String FLAG_ADD_ORDER = "ADD_ORDER";
    private RecyclerView recyclerView;
    AddOrderContract.Presenter mPresenter;
    private Button btAddOrder;
    private TextView tvDate, tvTimeStart, tvTimeEnd;
    private ImageView ivNavigateBack;
    private EditText etMeetingName;
    SessionManager sessionManager;
    HashMap<String,String> user;
    List<DataItem> selectedService = new ArrayList<>();
    List<ItemItem> itemService = new ArrayList<>();
    TimeZone timeZone = TimeZone.getTimeZone("GMT+7");
    Calendar c = Calendar.getInstance(timeZone);
    ConvertDate convertDate = new ConvertDate();

    private int mYear, mMonth, mDay, mHourStart, mMinuteStart, mHourEnd, mMinuteEnd,mHourStartSelected,mMinuteStartSelected,mHourEndSelected,mMinuteEndSelected;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_order);
        mPresenter = new AddOrderPresenter(this,this);
        sessionManager = new SessionManager(this);
        mPresenter.initP();
    }

    @Override
    public void initV() {
        user = sessionManager.getUserDetails();
        tvDate = findViewById(R.id.tvDate);
        tvTimeStart = findViewById(R.id.tvTimeStart);
        tvTimeEnd = findViewById(R.id.tvTimeEnd);
        etMeetingName = findViewById(R.id.etMeetingName);
        ivNavigateBack = findViewById(R.id.ivNavigateBack);

        ivNavigateBack.setOnClickListener(view -> {
            finish();
        });

        tvDate.setOnClickListener(view -> {
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            mYear = year;
                            mMonth = monthOfYear;
                            mDay = dayOfMonth;
                            c.set(Calendar.YEAR,year);
                            c.set(Calendar.MONTH,monthOfYear);
                            c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                            tvDate.setText(convertDate.convertCompleteDate(c.getTime()));
                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        });

        tvTimeStart.setOnClickListener(view -> {
            mHourStart = c.get(Calendar.HOUR_OF_DAY);
            mMinuteStart = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    (view12, hourOfDay, minute) -> {
                        String time;
                        if(String.valueOf(minute).length() == 1 ){
                            time = hourOfDay + ":0" + minute;
                        }else {
                            time = hourOfDay + ":" + minute;
                        }
                        mHourStartSelected = hourOfDay;
                        mMinuteStartSelected = minute;
                        tvTimeStart.setText(time);
                    }, mHourStart, mMinuteStart, true);
            timePickerDialog.show();
        });

        tvTimeEnd.setOnClickListener(view -> {
            mHourEnd = c.get(Calendar.HOUR_OF_DAY);
            mMinuteEnd = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    (view1, hourOfDay, minute) -> {
                        String time;
                        if(String.valueOf(minute).length() == 1 ){
                            time = hourOfDay + ":0" + minute;
                        }else {
                            time = hourOfDay + ":" + minute;
                        }
                        tvTimeEnd.setText(time);
                        mHourEndSelected = hourOfDay;
                        mMinuteEndSelected = minute;
                    }, mHourEnd, mMinuteEnd, true);
            timePickerDialog.show();
        });


        btAddOrder = findViewById(R.id.btAddOrder);
        recyclerView = findViewById(R.id.recyclerView);
        serviceAdapter = new ServiceAdapter(this,FLAG_ADD_ORDER);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(serviceAdapter);

        mPresenter.getServiceList(user.get(SessionManager.KEY_TOKEN));
        btAddOrder.setOnClickListener(view -> {
            selectedService = serviceAdapter.getSelectedService();
            for(int i = 0;i<selectedService.size();i++){
                itemService.add(new ItemItem(
                        selectedService.get(i).getQtyOrder(),selectedService.get(i).getId()
                ));
            }
            AddOrderRequest addOrderRequest = new AddOrderRequest(
                    itemService,
                    getTime(mHourStartSelected,mMinuteStartSelected),
                    getTime(mHourEndSelected,mMinuteEndSelected),
                    etMeetingName.getText().toString()
            );
            Log.d("Request : ", addOrderRequest.toString());
            mPresenter.addOrder(user.get(SessionManager.KEY_TOKEN), addOrderRequest);
        });
    }

    @Override
    public void onGetServiceList(Boolean result, int code, ListServiceResponse listServiceResponse) {
        serviceAdapter.setServiceList(listServiceResponse.getData());
    }

    @Override
    public void onAddOrder(Boolean result, int code) {
        if (result){
            Toast.makeText(this, "Sukses dalam menambahkan pesanan ! ", Toast.LENGTH_SHORT).show();
            finish();
        }else {
            Toast.makeText(this, "Terjadi sebuah kesalahan, silahkan coba lagi ! ", Toast.LENGTH_SHORT).show();
        }
    }


    public long getTime (int mHourEnd, int mMinuteEnd){
        Calendar cal = new GregorianCalendar(mYear,mMonth,mDay);
        cal.set(Calendar.HOUR,mHourEnd);
        cal.set(Calendar.MINUTE,mMinuteEnd);
        Log.d("TIME END : ", cal.getTimeInMillis() + " " + mHourEnd+":"+mMinuteEnd);
        return cal.getTimeInMillis();
    }

    @Override
    public void onCheckConnectivity(Boolean isConnected) {

    }

}
