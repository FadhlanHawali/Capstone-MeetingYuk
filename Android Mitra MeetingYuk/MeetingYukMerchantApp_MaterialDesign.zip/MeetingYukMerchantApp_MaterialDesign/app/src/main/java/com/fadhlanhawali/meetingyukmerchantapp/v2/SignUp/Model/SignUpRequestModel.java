package com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.Model;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class SignUpRequestModel{

	@SerializedName("nama_pemilik")
	private String namaPemilik;

	@SerializedName("url_foto")
	private String urlFoto;

	@SerializedName("password")
	private String password;

	@SerializedName("str_alamat")
	private String strAlamat;

	@SerializedName("nama_tempat")
	private String namaTempat;

	@SerializedName("email")
	private String email;

	@SerializedName("no_telepon")
	private String noTelepon;

	@SerializedName("alamat")
	private Alamat alamat;

	@SerializedName("confirm_password")
	private String confirmPassword;

	public SignUpRequestModel(String namaPemilik, String urlFoto, String password, String strAlamat, String namaTempat, String email, String noTelepon, Alamat alamat, String confirmPassword) {
		this.namaPemilik = namaPemilik;
		this.urlFoto = urlFoto;
		this.password = password;
		this.strAlamat = strAlamat;
		this.namaTempat = namaTempat;
		this.email = email;
		this.noTelepon = noTelepon;
		this.alamat = alamat;
		this.confirmPassword = confirmPassword;
	}

	public void setNamaPemilik(String namaPemilik){
		this.namaPemilik = namaPemilik;
	}

	public String getNamaPemilik(){
		return namaPemilik;
	}

	public void setUrlFoto(String urlFoto){
		this.urlFoto = urlFoto;
	}

	public String getUrlFoto(){
		return urlFoto;
	}

	public void setPassword(String password){
		this.password = password;
	}

	public String getPassword(){
		return password;
	}

	public void setStrAlamat(String strAlamat){
		this.strAlamat = strAlamat;
	}

	public String getStrAlamat(){
		return strAlamat;
	}

	public void setNamaTempat(String namaTempat){
		this.namaTempat = namaTempat;
	}

	public String getNamaTempat(){
		return namaTempat;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

	public void setNoTelepon(String noTelepon){
		this.noTelepon = noTelepon;
	}

	public String getNoTelepon(){
		return noTelepon;
	}

	public void setAlamat(Alamat alamat){
		this.alamat = alamat;
	}

	public Alamat getAlamat(){
		return alamat;
	}

	public void setConfirmPassword(String confirmPassword){
		this.confirmPassword = confirmPassword;
	}

	public String getConfirmPassword(){
		return confirmPassword;
	}

	@Override
 	public String toString(){
		return 
			"SignUpRequestModel{" + 
			"nama_pemilik = '" + namaPemilik + '\'' + 
			",url_foto = '" + urlFoto + '\'' + 
			",password = '" + password + '\'' + 
			",str_alamat = '" + strAlamat + '\'' + 
			",nama_tempat = '" + namaTempat + '\'' + 
			",email = '" + email + '\'' + 
			",no_telepon = '" + noTelepon + '\'' + 
			",alamat = '" + alamat + '\'' + 
			",confirm_password = '" + confirmPassword + '\'' + 
			"}";
		}
}