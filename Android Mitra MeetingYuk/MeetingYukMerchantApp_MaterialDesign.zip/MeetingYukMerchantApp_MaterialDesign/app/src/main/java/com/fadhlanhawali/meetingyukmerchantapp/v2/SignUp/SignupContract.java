package com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp;

import android.app.Activity;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Layanan.API.Model.UploadFileServiceModel.UploadFileServiceResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.SignUp.Model.SignUpRequestModel;

import okhttp3.MultipartBody;

public interface SignupContract {
    interface vSignUp{
        void initV();
        void onSignUpResult(Boolean result, int code);
        void onUploadFileResult(Boolean result, int code, UploadFileServiceResponseModel uploadFileServiceResponseModel);
    }

    interface pSignUp{
        void initP();
        void doSignUp(SignUpRequestModel signUpRequestModel, String token);
        void doUploadFile(MultipartBody.Part body);
        void doPlacePicker(Activity activity, int RequestCode);
    }

}
