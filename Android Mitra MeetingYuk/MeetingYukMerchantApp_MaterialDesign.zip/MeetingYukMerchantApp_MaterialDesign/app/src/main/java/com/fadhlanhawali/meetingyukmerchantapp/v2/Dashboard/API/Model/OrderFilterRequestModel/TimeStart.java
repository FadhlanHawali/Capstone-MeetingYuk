package com.fadhlanhawali.meetingyukmerchantapp.v2.Dashboard.API.Model.OrderFilterRequestModel;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class TimeStart{

	@SerializedName("gte")
	private int gte;

	@SerializedName("lte")
	private int lte;

	public void setGte(int gte){
		this.gte = gte;
	}

	public int getGte(){
		return gte;
	}

	public void setLte(int lte){
		this.lte = lte;
	}

	public int getLte(){
		return lte;
	}

	public TimeStart(int gte, int lte) {
		this.gte = gte;
		this.lte = lte;
	}

	@Override
 	public String toString(){
		return 
			"TimeStart{" + 
			"gte = '" + gte + '\'' + 
			",lte = '" + lte + '\'' + 
			"}";
		}
}