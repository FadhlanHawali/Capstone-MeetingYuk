package com.fadhlanhawali.meetingyukmerchantapp.v2.Notification;

public class NotificationHelper {

    private static final String WITHDRAW_REQUEST_ACCEPTED = "WITHDRAW_REQUEST_ACCEPTED";
    private static final String WITHDRAW_REQUEST_REJECTED = "WITHDRAW_REQUEST_REJECTED";
    private static final String ORDER_CANCELLED_BY_USER = "ORDER_CANCELED_BY_USER";
    private static final String ORDER_PROGRESS = "ORDER_PROGRESS";


}
