package com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Utils;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Login.ILoginAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.IReportAPI;
import com.fadhlanhawali.meetingyukmerchantapp.v2.RetrofitClient;

public class ReportAPIUtils {
    public ReportAPIUtils() {
    }

    public static IReportAPI getAPIService() {
        return RetrofitClient.getClient(BuildConfig.API_BASE_URL).create(IReportAPI.class);
    }
}
