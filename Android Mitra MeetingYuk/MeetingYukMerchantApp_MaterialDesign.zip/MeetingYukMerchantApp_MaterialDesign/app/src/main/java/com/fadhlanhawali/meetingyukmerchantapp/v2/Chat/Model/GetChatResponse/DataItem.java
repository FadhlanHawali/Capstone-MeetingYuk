package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import javax.annotation.Generated;

@Entity(tableName = "chat",foreignKeys = @ForeignKey(
		entity = com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem.class,
		parentColumns = "id",
		childColumns = "idRoom"))
@Generated("com.robohorse.robopojogenerator")
public class DataItem implements Serializable, Parcelable {

	@SerializedName("idRoom")
	@ColumnInfo(index = true)
	private String idRoom;

	@SerializedName("fromUserId")
	private String fromUserId;

	@SerializedName("readBy")
	private String readBy;

	@SerializedName("referenceType")
	private String referenceType;

	@SerializedName("type")
	private String type;

	@SerializedName("toUserId")
	private String toUserId;

	@SerializedName("referencedMessageId")
	private String referencedMessageId;

	@SerializedName("mode")
	private String mode;

	@SerializedName("__v")
	private int v;

	@SerializedName("fromName")
	private String fromName;

	@SerializedName("fromUserAvatarUrl")
	private String fromUserAvatarUrl;

	@SerializedName("fileUrl")
	private String fileUrl;

	@SerializedName("sendStatus")
	private boolean sendStatus;

	@SerializedName("text")
	private String text;

	@SerializedName("_id")
	@PrimaryKey @NonNull
	private String id;

	@SerializedName("timestamp")
	private long timestamp;

	public void setIdRoom(String idRoom){
		this.idRoom = idRoom;
	}

	public String getIdRoom(){
		return idRoom;
	}

	public void setFromUserId(String fromUserId){
		this.fromUserId = fromUserId;
	}

	public String getFromUserId(){
		return fromUserId;
	}

	public void setReadBy(String readBy){
		this.readBy = readBy;
	}

	public String getReadBy(){
		return readBy;
	}

	public void setReferenceType(String referenceType){
		this.referenceType = referenceType;
	}

	public String getReferenceType(){
		return referenceType;
	}

	public void setType(String type){
		this.type = type;
	}

	public String getType(){
		return type;
	}

	public void setToUserId(String toUserId){
		this.toUserId = toUserId;
	}

	public String getToUserId(){
		return toUserId;
	}

	public void setReferencedMessageId(String referencedMessageId){
		this.referencedMessageId = referencedMessageId;
	}

	public String getReferencedMessageId(){
		return referencedMessageId;
	}

	public void setMode(String mode){
		this.mode = mode;
	}

	public String getMode(){
		return mode;
	}

	public void setV(int v){
		this.v = v;
	}

	public int getV(){
		return v;
	}

	public void setFromName(String fromName){
		this.fromName = fromName;
	}

	public String getFromName(){
		return fromName;
	}

	public void setFromUserAvatarUrl(String fromUserAvatarUrl){
		this.fromUserAvatarUrl = fromUserAvatarUrl;
	}

	public String getFromUserAvatarUrl(){
		return fromUserAvatarUrl;
	}

	public void setFileUrl(String fileUrl){
		this.fileUrl = fileUrl;
	}

	public String getFileUrl(){
		return fileUrl;
	}

	public void setSendStatus(boolean sendStatus){
		this.sendStatus = sendStatus;
	}

	public boolean isSendStatus(){
		return sendStatus;
	}

	public void setText(String text){
		this.text = text;
	}

	public String getText(){
		return text;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setTimestamp(long timestamp){
		this.timestamp = timestamp;
	}

	public long getTimestamp(){
		return timestamp;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"idRoom = '" + idRoom + '\'' + 
			",fromUserId = '" + fromUserId + '\'' + 
			",readBy = '" + readBy + '\'' + 
			",referenceType = '" + referenceType + '\'' + 
			",type = '" + type + '\'' + 
			",toUserId = '" + toUserId + '\'' + 
			",referencedMessageId = '" + referencedMessageId + '\'' + 
			",mode = '" + mode + '\'' + 
			",__v = '" + v + '\'' +
			",fromName = '" + fromName + '\'' + 
			",fromUserAvatarUrl = '" + fromUserAvatarUrl + '\'' + 
			",fileUrl = '" + fileUrl + '\'' + 
			",sendStatus = '" + sendStatus + '\'' + 
			",text = '" + text + '\'' + 
			",_id = '" + id + '\'' + 
			",timestamp = '" + timestamp + '\'' + 
			"}";
		}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.fromUserId);
		dest.writeString(this.readBy);
		dest.writeString(this.idRoom);
		dest.writeString(this.referenceType);
		dest.writeString(this.type);
		dest.writeString(this.toUserId);
		dest.writeString(this.referencedMessageId);
		dest.writeString(this.mode);
		dest.writeInt(this.v);
		dest.writeString(this.fromName);
		dest.writeString(this.fromUserAvatarUrl);
		dest.writeString(this.fileUrl);
		dest.writeByte(this.sendStatus ? (byte) 1 : (byte) 0);
		dest.writeString(this.text);
		dest.writeString(this.id);
		dest.writeLong(this.timestamp);
	}

	public DataItem(String idRoom, String fromUserId, String readBy, String referenceType, String type, String toUserId, String referencedMessageId, String mode, int v, String fromName, String fromUserAvatarUrl, String fileUrl, boolean sendStatus, String text, String id, long timestamp) {
		this.idRoom = idRoom;
		this.fromUserId = fromUserId;
		this.readBy = readBy;
		this.referenceType = referenceType;
		this.type = type;
		this.toUserId = toUserId;
		this.referencedMessageId = referencedMessageId;
		this.mode = mode;
		this.v = v;
		this.fromName = fromName;
		this.fromUserAvatarUrl = fromUserAvatarUrl;
		this.fileUrl = fileUrl;
		this.sendStatus = sendStatus;
		this.text = text;
		this.id = id;
		this.timestamp = timestamp;
	}

	protected DataItem(Parcel in) {
		this.fromUserId = in.readString();
		this.readBy = in.readString();
		this.idRoom = in.readString();
		this.referenceType = in.readString();
		this.type = in.readString();
		this.toUserId = in.readString();
		this.referencedMessageId = in.readString();
		this.mode = in.readString();
		this.v = in.readInt();
		this.fromName = in.readString();
		this.fromUserAvatarUrl = in.readString();
		this.fileUrl = in.readString();
		this.sendStatus = in.readByte() != 0;
		this.text = in.readString();
		this.id = in.readString();
		this.timestamp = in.readLong();
	}

	public static final Creator<DataItem> CREATOR = new Creator<DataItem>() {
		@Override
		public DataItem createFromParcel(Parcel source) {
			return new DataItem(source);
		}

		@Override
		public DataItem[] newArray(int size) {
			return new DataItem[size];
		}
	};
}