package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class TargetProfile{

	@SerializedName("profile_url")
	private String profileUrl;

	@SerializedName("name")
	private String name;

	@SerializedName("phone_number")
	private String phoneNumber;

	@SerializedName("email")
	private String email;


	public TargetProfile(String profileUrl, String name, String phoneNumber, String email) {
		this.profileUrl = profileUrl;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.email = email;
	}

	public void setProfileUrl(String profileUrl){
		this.profileUrl = profileUrl;
	}

	public String getProfileUrl(){
		return profileUrl;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setPhoneNumber(String phoneNumber){
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber(){
		return phoneNumber;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

	@Override
 	public String toString(){
		return 
			"TargetProfile{" + 
			"profile_url = '" + profileUrl + '\'' + 
			",name = '" + name + '\'' + 
			",phone_number = '" + phoneNumber + '\'' + 
			",email = '" + email + '\'' + 
			"}";
		}
}