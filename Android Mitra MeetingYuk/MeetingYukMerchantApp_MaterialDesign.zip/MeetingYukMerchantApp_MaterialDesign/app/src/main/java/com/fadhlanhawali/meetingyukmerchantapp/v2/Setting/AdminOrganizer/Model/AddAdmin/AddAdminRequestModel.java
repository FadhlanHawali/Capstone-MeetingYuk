package com.fadhlanhawali.meetingyukmerchantapp.v2.Setting.AdminOrganizer.Model.AddAdmin;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class AddAdminRequestModel{

	@SerializedName("password")
	private String password;

	@SerializedName("email")
	private String email;

	public AddAdminRequestModel(String password, String email) {
		this.password = password;
		this.email = email;
	}

	public void setPassword(String password){
		this.password = password;
	}

	public String getPassword(){
		return password;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

	@Override
 	public String toString(){
		return 
			"AddAdminRequestModel{" + 
			"password = '" + password + '\'' + 
			",email = '" + email + '\'' + 
			"}";
		}
}