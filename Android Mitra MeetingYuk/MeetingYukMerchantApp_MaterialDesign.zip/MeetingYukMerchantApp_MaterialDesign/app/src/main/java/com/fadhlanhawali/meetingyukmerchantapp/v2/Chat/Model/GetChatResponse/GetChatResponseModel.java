package com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class GetChatResponseModel {

	@SerializedName("data")
	private List<DataItem> data;

	@SerializedName("succes")
	private boolean succes;

	public void setData(List<DataItem> data){
		this.data = data;
	}

	public List<DataItem> getData(){
		return data;
	}

	public void setSucces(boolean succes){
		this.succes = succes;
	}

	public boolean isSucces(){
		return succes;
	}

	public GetChatResponseModel(List<DataItem> data, boolean succes) {
		this.data = data;
		this.succes = succes;
	}

	@Override
 	public String toString(){
		return 
			"GetChatResponseModel{" +
			"data = '" + data + '\'' + 
			",succes = '" + succes + '\'' + 
			"}";
		}
}