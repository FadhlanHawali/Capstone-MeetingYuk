package com.fadhlanhawali.meetingyukmerchantapp.v2.Report;

import android.os.Build;

import com.fadhlanhawali.meetingyukmerchantapp.BuildConfig;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.FinancialStatements.GetFinancialStatementsModelResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.GetSaldoMitraResponse;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.AddBankAccountRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.AddBankAccountResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.BankAccount.GetBankAccountResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoHistoryResponseModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoRequestModel;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Report.Model.SaldoMitra.WithdrawSaldoResponseModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface IReportAPI {
    @GET(BuildConfig.GET_SALDO_MITRA)
    Call<GetSaldoMitraResponse> getSaldoMitra(@Header("x-meeting-token") String token);

    @POST(BuildConfig.ADD_BANK_ACCOUNT)
    Call<AddBankAccountResponseModel> addBankAccount(@Header("x-meeting-token") String token, @Body AddBankAccountRequestModel addBankAccountRequestModel);

    @POST(BuildConfig.WITHDRAW_SALDO_MITRA)
    Call<WithdrawSaldoResponseModel> withdrawSaldoMitra(@Header("x-meeting-token") String token, @Body WithdrawSaldoRequestModel withdrawSaldoRequestModel);

    @GET(BuildConfig.GET_WITHDRAW_HISTORY)
    Call<WithdrawSaldoHistoryResponseModel> getWithdrawSaldoHistoryMitra(@Header("x-meeting-token") String token);

    @GET(BuildConfig.GET_BANK_ACCOUNT)
    Call<GetBankAccountResponseModel> getBankAccount(@Header("x-meeting-token") String token);

    @GET(BuildConfig.GET_FINANCIAL_STATEMENTS)
    Call<GetFinancialStatementsModelResponse> getFinancialStatements(@Header("x-meeting-token") String token, @Path(value="period",encoded = true) String period);

}
