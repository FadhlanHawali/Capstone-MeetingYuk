package com.fadhlanhawali.meetingyukmerchantapp.v2.Utils;

import android.app.Activity;
import android.app.Dialog;
import android.view.Window;
import android.widget.ImageView;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.fadhlanhawali.meetingyukmerchantapp.R;

public class ViewDialog {
    Activity activity;
    Dialog dialog;
    //..we need the context else we can not create the dialog so get context in constructor
    public ViewDialog(Activity activity) {
        this.activity = activity;
    }

    public void showDialog() {

        dialog  = new Dialog(activity,R.style.CustomAlertDialog);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        //...set cancelable false so that it's never get hidden
        dialog.setCancelable(false);
        //...that's the layout i told you will inflate later

        dialog.setContentView(R.layout.fragment_loading);

        //...initialize the imageView form infalted layout
        LottieAnimationView animationView = dialog.findViewById(R.id.av_from_code);
        animationView.setAnimation("loading_ring.json");
        animationView.playAnimation();
        animationView.loop(true);

        //...finaly show it
        dialog.show();
    }

    //..also create a method which will hide the dialog when some work is done
    public void hideDialog(){
        dialog.dismiss();
    }
}
