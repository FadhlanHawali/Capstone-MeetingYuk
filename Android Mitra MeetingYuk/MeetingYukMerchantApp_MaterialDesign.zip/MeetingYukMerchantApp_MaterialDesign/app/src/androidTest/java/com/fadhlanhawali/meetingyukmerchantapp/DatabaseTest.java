package com.fadhlanhawali.meetingyukmerchantapp;

import android.content.Context;

import androidx.room.Room;
import androidx.test.InstrumentationRegistry;
import androidx.test.runner.AndroidJUnit4;

import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.DataItem;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.TargetProfile;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.AppDatabase;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ChatDao;
import com.fadhlanhawali.meetingyukmerchantapp.v2.Database.DAO.ListRoomChatDao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.util.List;

import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertThat;

@RunWith(AndroidJUnit4.class)
public class DatabaseTest {

    private ListRoomChatDao listRoomChatDao;
    private ChatDao chatDao;
    private AppDatabase mDb;

    @Before
    public void createDb() {
        Context context = InstrumentationRegistry.getTargetContext();
        mDb = Room.inMemoryDatabaseBuilder(context, AppDatabase.class).build();
        listRoomChatDao = mDb.listRoomChatDao();
        chatDao = mDb.chatDao();
    }

    @Test
    public void writeUserAndReadInList() throws Exception {

        mDb.listRoomChatDao().deleteAll();

        List<DataItem> listRoomChats = mDb.listRoomChatDao().getListRoomChat();
        assertThat(listRoomChats.size(),equalTo(0));

        addListRoomChat(mDb, new TargetProfile(
                "http://",
                "fadhlan",
                "08172",
                "fad@gmail.com"),
                0,
                "fad",
                "halo",
                "1",
                "abc",
                "private");

        addListRoomChat(mDb, new TargetProfile(
                        "http://",
                        "fadhlan",
                        "08172",
                        "fad1@gmail.com"),
                0,
                "fad",
                "halo",
                "2",
                "abc",
                "private");

        listRoomChats = listRoomChatDao.getListRoomChat();
        System.out.println("Halo : " + listRoomChats.get(0).getMember());
        assertThat(listRoomChats.size(),equalTo(2));
        DataItem cobo = mDb.listRoomChatDao().findRoom("2");
        assertThat(cobo.getTargetProfile().getEmail(),equalTo("fad1@gmail.com"));

        mDb.listRoomChatDao().deleteRoom(cobo);
        listRoomChats = listRoomChatDao.getListRoomChat();
        assertThat(listRoomChats.size(),equalTo(1));

        addListRoomChat(mDb, new TargetProfile(
                        "http://",
                        "fadhlan",
                        "08172",
                        "fad1@gmail.com"),
                0,
                "fad",
                "halo",
                "2",
                "abc",
                "private");
        listRoomChats = listRoomChatDao.getListRoomChat();
        assertThat(listRoomChats.size(),equalTo(2));


    }

    @Test
    public void updateListRoom() throws Exception{
        mDb.listRoomChatDao().deleteAll();

        addListRoomChat(mDb, new TargetProfile(
                        "http://",
                        "fadhlan",
                        "08172",
                        "fad@gmail.com"),
                0,
                "fad",
                "halo",
                "1",
                "abc",
                "private");

        addListRoomChat(mDb, new TargetProfile(
                        "http://",
                        "fadhlan",
                        "08172",
                        "fad1@gmail.com"),
                0,
                "fad",
                "halo",
                "2",
                "abc",
                "private");

        List<DataItem> listRoomChats = mDb.listRoomChatDao().getListRoomChat();

        listRoomChats.get(1).setLastMessageText("haloha");

        mDb.listRoomChatDao().insertRoomChatReplace(listRoomChats.get(1));
//        DataItem cobo = mDb.listRoomChatDao().findRoom("2");
//        cobo.setLastMessageText("haloha");
//        mDb.listRoomChatDao().updateRoomChat(cobo);
//
//
//
//        cobo = mDb.listRoomChatDao().findRoom("2");
        addListRoomChat(mDb, new TargetProfile(
                        "http://",
                        "fadhlan",
                        "08172",
                        "fad1@gmail.com"),
                0,
                "fad",
                "halo",
                "3",
                "abc",
                "private");
        listRoomChats = mDb.listRoomChatDao().getListRoomChat();
        for(int i = 0;i<listRoomChats.size();i++){
            mDb.listRoomChatDao().insertRoomChatReplace(listRoomChats.get(i));
        }

        assertThat(listRoomChats.get(1).getLastMessageText(),equalTo("haloha"));
        assertThat(listRoomChats.size(),equalTo(3));
    }

    @Test
    public void wirteChatAndReadInList() throws Exception{
        mDb.chatDao().deleteAllChat();
        List<com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem> listChat = mDb.chatDao().getChat("1");
        assertThat(listChat.size(), equalTo(0));

        addListRoomChat(mDb, new TargetProfile(
                        "http://",
                        "fadhlan",
                        "08172",
                        "fad@gmail.com"),
                0,
                "fad",
                "halo",
                "1",
                "abc",
                "private");
        addChat(mDb,
                "1",
                "fad",
                "fadhaw",
                "as",
                "text",
                "haw",
                "id1",
                "mode",
                0,
                "haw",
                "http://",
                "http://",
                true,
                "halo",
                "id1",
                0
        );

        listChat = mDb.chatDao().getChat("1");
        assertThat(listChat.size(),equalTo(1));
        mDb.chatDao().deleteAllChat();
        listChat = mDb.chatDao().getChat("1");
        assertThat(listChat.size(),equalTo(0));
    }

    @After
    public void closeDb() throws IOException {
        mDb.close();
    }

    private static com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem addChat(AppDatabase db, String idRoom, String fromUserId, String readBy, String referenceType, String type,
                                                                                                           String toUserId, String referencedMessageId, String mode, int _v, String fromName,
                                                                                                           String fromUserAvatarUrl, String fileUrl, boolean sendStatus, String text, String id, long timestamp){

        com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem chat = new com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetChatResponse.DataItem(idRoom, fromUserId, readBy, referenceType, type, toUserId, referencedMessageId, mode, _v, fromName, fromUserAvatarUrl, fileUrl, sendStatus, text, id, timestamp);
        db.chatDao().insertChat(chat);

        return chat;
    }


    private static DataItem addListRoomChat(AppDatabase db, TargetProfile targetProfile, long lastMessageTimestamp, String member, String lastMessageText,
                                                String _id, String lastMessageId, String roomType) {
        DataItem listRoomChat = new DataItem();

        listRoomChat.setTargetProfile(new com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.TargetProfile(
                targetProfile.getProfileUrl(),
                targetProfile.getName(),
                targetProfile.getPhoneNumber(),
                targetProfile.getEmail()
        ));

        listRoomChat.setLastMessageTimestamp(lastMessageTimestamp);
        listRoomChat.setMember(member);
        listRoomChat.setLastMessageText(lastMessageText);
        listRoomChat.setId(_id);
        listRoomChat.setLastMessageId(lastMessageId);
        listRoomChat.setRoomType(roomType);

        db.listRoomChatDao().insertRoomChat(listRoomChat);

        return listRoomChat;
    }

    private static DataItem addListRoomChatReplace(AppDatabase db, TargetProfile targetProfile, long lastMessageTimestamp, String member, String lastMessageText,
                                            String _id, String lastMessageId, String roomType) {
        DataItem listRoomChat = new DataItem();

        listRoomChat.setTargetProfile(new com.fadhlanhawali.meetingyukmerchantapp.v2.Chat.Model.GetListRoomChat.TargetProfile(
                targetProfile.getProfileUrl(),
                targetProfile.getName(),
                targetProfile.getPhoneNumber(),
                targetProfile.getEmail()
        ));

        listRoomChat.setLastMessageTimestamp(lastMessageTimestamp);
        listRoomChat.setMember(member);
        listRoomChat.setLastMessageText(lastMessageText);
        listRoomChat.setId(_id);
        listRoomChat.setLastMessageId(lastMessageId);
        listRoomChat.setRoomType(roomType);

        db.listRoomChatDao().insertRoomChatReplace(listRoomChat);

        return listRoomChat;
    }


}
